// [begin] Jazz functions
// ---------------------------------------------
declare namespace fs {
  class Stats {
    isDirectory(): boolean;
    isFile(): boolean;
    size: number;
  }
  function accessSync(path: string, mode: number): undefined | boolean;
  function access(path: string, callback: (err: any) => undefined): undefined;
  function readFileSync(path: string): undefined | ArrayBuffer;
  function readFile(path: string, callback: (err: any, arraybuffer: ArrayBuffer) => undefined): undefined;
  function statSync(path: string): undefined | Stats;
  function stat(path: string, callback: (err: any, stat: Stats) => undefined): undefined;
}
declare namespace console {
  function log(str: string): void;
}
// [end] Jazz functions
// ---------------------------------------------

declare namespace effect {
  namespace Amaz {
    namespace AmazingManager {
      /**
       * @brief JsAmazingManager init
       * @param arg0 width
       * @param arg1 height
       * @param arg2 config
       * @param arg3 rendererType
       */
      function init(arg0: number, arg1: number, arg2: number, arg3: RendererType): void;

      /**
       * @brief resize the view
       * @param arg0 width
       * @param arg1 height
       */
      function resize(arg0: number, arg1: number): void;

      /**
       * @brief setInputTexture
       * @param arg0 GL textureId or Texture2D
       * @param arg1 width
       * @param arg2 height
       * @param arg3 textureYFlip
       * @param arg4 rtYFlip
       * @param arg5 BuiltInTextureType
       */
      function setInputTexture(arg0: {
        _value: number;
      } | Texture2D, arg1?: number, arg2?: number, arg3?: boolean, arg4?: boolean, arg5?: BuiltInTextureType): void;

      /**
       * @brief setInputTexture
       * @param arg0 GL textureId or Texture2D
       * @param arg1 width
       * @param arg2 height
       * @param arg3 BuiltInTextureType
       */
      function setInputTexture(arg0: number | {
        _value: number;
      } | Texture2D, arg1: number, arg2: number, arg3: BuiltInTextureType): void;

      /**
       * @brief setInputTexture
       * @param arg0 GL textureId or Texture2D
       * @param arg1 BuiltInTextureType
       */
      function setInputTexture(arg0: number | {
        _value: number;
      } | Texture2D, arg1: BuiltInTextureType): void;

      /**
       * @brief setOutputTexture
       * @param arg0 GL textureId or Texture2D
       * @param arg1 width
       * @param arg2 height
       * @param arg3 textureYFlip
       * @param arg4 rtYFlip
       */
      function setOutputTexture(arg0: number | {
        _value: number;
      } | Texture2D, arg1?: number, arg2?: number, arg3?: boolean, arg4?: boolean): void;

      /**
       * @brief update one frame
       * @param arg0 timestamp
       */
      function update(arg0: number): void;

      /**
       * @brief call onPause
       * @param arg0 PAUSE_TYPE eg. AMAZ_PAUSE_TYPE_BGM 0x00000001
       */
      function onPause(arg0: number): void;

      /**
       * @brief call onResume
       * @param arg0 PAUSE_TYPE eg. AMAZ_PAUSE_TYPE_BGM 0x00000001
       */
      function onResume(arg0: number): void;

      /**
       * @brief add a scene to viewer
       * @param arg0 the scene to be added
       * @param arg1 order of the scene when rendering
       */
      function addScene(arg0: Scene, arg1?: number): void;

      /**
       * @brief remove a scene from viewer
       * @param arg0 the scene to be removed
       */
      function removeScene(arg0: Scene): void;

      /**
       * @brief load a scene from resource path
       * @param arg0 path to load the scene
       * @return scene
       */
      function loadScene(arg0: string, arg1?: string[], arg2?: AssetManager): Scene | undefined;

      /**
       * @brief load the prefab from
       * @param arg0 absolute file path or dir of the resource
       * @param arg1 filename of the resource when arg0 is dir
       * @return object
       */
      function loadResource(arg0: string, arg1?: string): AObject | undefined;

      /**
       * @brief set AEAlgorithmResult to Amazer
       * @param arg0 AEAlgorithmResult
       */
      function setAlgorithmResult(arg0: AEAlgorithmResult): void;

      /**
       * @brief clear AEAlgorithmResult from Amazer
       */
      function clearAlgorithmResult(): void;

      /**
       * @brief add listener to Object
       * @param arg0 listen target
       * @param arg1 listener type
       * @param arg2 callback function
       * @param arg3 userdata
       */
      function addListener(arg0: AObject, arg1: number, arg2: (user: object, obj: AObject, type: number) => void, arg3?: object): void;

      /**
       * @brief remove listener from Object
       * @param arg0 listen target
       * @param arg1 listener type
       * @param arg2 callback function
       * @param arg3 userdata
       */
      function removeListener(arg0: AObject, arg1: number, arg2: (user: object, obj: AObject, type: number) => void, arg3?: object): void;

      /**
       * @brief send touch event into amazer
       * @param arg0 pointerId
       * @param arg1 x
       * @param arg2 y
       * @param arg3 force
       * @param arg4 majorRadius
       * @param arg5 type
       * @param arg6 pointerCount
       */
      function onTouchEvent(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number): void;

      /**
       * @brief send touch event into amazer
       * @param arg0 pointerId
       * @param arg1 x
       * @param arg2 y
       * @param arg3 type
       * @param arg4 pointerCount
       */
      function onTouchEvent(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): void;

      /**
       * @brief get singleton from amazer
       * @param arg0 type name of singleton
       */
      function getSingleton(arg0: 'Profiler' | 'Calibrate' | 'Input' | 'BuiltinObject' | 'AppInfo' | 'PrefabManager' | 'AMGAudioModule' | 'DictionaryManager' | 'Algorithm' | 'BingoGPU' | 'NetworkCenter' | 'NetworkCenterWS' | 'EventCenter' | 'AnalyticsManager'): AObject;

      /**
       * @brief invoke object listener
       * @param arg0 object which to invoke
       * @param arg1 evnetType
       * @param arg2 eventInfo
       */
      function invokeCompListener(arg0: AObject, arg1: number, arg2: AObject): void;
    }
    class AlgorithmManager {
      /**
       * @brief constructor
       * @param arg0 use bach if opened
       */
      constructor(arg0?: boolean);

      /**
       * @brief init algorithm
       * @param arg0 width
       * @param arg1 height
       * @param arg2 use syncmode
       */
      public init(arg0: number, arg1: number, arg2?: boolean): void;

      /**
       * @brief execute algorithm
       * @param arg0 texture
       * @param arg1 width
       * @param arg2 height
       * @param arg3 timestamp
       */
      public doExecute(arg0: number | {
        _value: number;
      } | Texture2D, arg1: number, arg2: number, arg3: number): void;

      /**
       * @brief setRequirement
       * @param arg0 array of requirements
       */
      public setRequirement(arg0: [string]): void;

      /**
       * @brief setGraphConfig
       * @param arg0 graphName
       * @param arg1 path
       */
      public setGraphConfig(arg0: string, arg1: string): void;

      /**
       * @brief downloadModel with no callback
       * @param arg0 array of requirements
       * @param arg1 json of models
       * @return JsDownloadStatus
       */
      public downloadModel(arg0: [string], arg1: string): JsDownloadStatus;

      /**
       * @brief downloadModel with no callback
       * @param arg0 array of requirements
       * @param arg1 json of models
       */
      public downloadModel(arg0: [string], arg1: string, arg2: (task: JsDownloadStatus) => void): void;

      /**
       * @brief merge the subgraph given to get main graph config
       * @param arg a Map<subGraphName, subGraphString>
       * @return main AlgorithmConfig.json string
       */
      public static merge(arg: Object): string;
    }
    function LOGE(tag: string, format: string): undefined;
    function LOGW(tag: string, format: string): undefined;
    function LOGS(tag: string, format: string): undefined;
    function LOGI(tag: string, format: string): undefined;
    function LOGD(tag: string, format: string): undefined;
    function LOGV(tag: string, format: string): undefined;
    namespace AmazingUtil {
      function vec2VectorToVec4Vector(arg0: Vec2Vector): Vec4Vector;
      function vec3VectorToVec4Vector(arg0: Vec3Vector): Vec4Vector;
      function vec4VectorToVec2Vector(arg0: Vec4Vector): Vec2Vector;
      function vec4VectorToVec3Vector(arg0: Vec4Vector): Vec3Vector;
      function vec2VectorToVec3Vector(arg0: Vec2Vector): Vec3Vector;
      function vec3VectorToVec2Vector(arg0: Vec3Vector): Vec2Vector;
      function getArrayBuffer(inVector: Int8Vector | Int16Vector | Int32Vector | Int64Vector | UInt8Vector | UInt16Vector | UInt32Vector | FloatVector | DoubleVector | Vec2Vector | Vec3Vector | Vec4Vector | QuatVector | Matrix4x4f | Vector3f | Guid, outBuffer: ArrayBuffer): ArrayBuffer | undefined;
      function getArrayBuffer(inVector: Int8Vector | Int16Vector | Int32Vector | Int64Vector | UInt8Vector | UInt16Vector | UInt32Vector | FloatVector | DoubleVector | Vec2Vector | Vec3Vector | Vec4Vector | QuatVector | Matrix4x4f | Vector3f | Guid, byteOffset?: number, copySize?: number, outBuffer?: ArrayBuffer): ArrayBuffer | undefined;
      function arrayBufferToPrimitiveVector(inBuffer: ArrayBuffer, outVector: Int8Vector | Int16Vector | Int32Vector | Int64Vector | UInt8Vector | UInt16Vector | UInt32Vector | FloatVector | DoubleVector | Vec2Vector | Vec3Vector | Vec4Vector | QuatVector): void;
      function arrayBufferToPrimitiveVector(inBuffer: ArrayBuffer, byteOffset: number, copySize: number, outVector: Int8Vector | Int16Vector | Int32Vector | Int64Vector | UInt8Vector | UInt16Vector | UInt32Vector | FloatVector | DoubleVector | Vec2Vector | Vec3Vector | Vec4Vector | QuatVector): void;
      function flatContainerVariantToObjArray(object: effect.Amaz.Map | effect.Amaz.Vector): effect.Amaz.Vector;
      function externalTextureToAMGTexture2D(tex: number | {
        _value: number;
      } | Texture2D, width: number, height: number, textureYFlip?: boolean, rtYFlip?: boolean): Texture2D | undefined;
      function convertBufferToImage(buffer: ArrayBuffer, width: number, height: number, format?: number): Image;
      function arrayToUInt32Vector(arr: Array<number>): UInt32Vector;
      function guidToPointer(guid: Guid): AObject | null;
      function setWatchValue(key: string, value: Variant): boolean;
      function getWatchValue(key: string): Variant | null;
      function setWatchValueList(obj: Object): boolean;
      function flushCachedWatchValues(): undefined;
    }
    namespace Platform {
      function getAccelValues(): Vector3f;
      function getAccelEulerValues(): Vector2f;
      function getGyroValues(): Vector3f;
      function getFov(): number;
      function name(): string;
      function getDeviceRotation(): Quaternionf;
      function getDeviceOrientation(): number;
      function getCameraToward(): number;
    }
    namespace Hand3DUtil {
      function calRotaionOnYaxis(param1: Vector3f, param2: Vector3f): void;
    }
  }
}
declare namespace effect {
  namespace Amaz {
    type MathVec = Vector2f | Vector3f | Vector4f;
    type MathMat = Matrix3x3f | Matrix4x4f;
    type MathGeo = Rect | Plane | Color | AABB | Quaternionf;
    type MathType = MathVec | MathMat | MathGeo | DynamicBitset;
    type Collective = Amaz.Vector | Amaz.Map;
    type PrimitiveVector = Int8Vector | Int16Vector | Int32Vector | Int64Vector | UInt8Vector | UInt16Vector | UInt32Vector | FloatVector | DoubleVector | StringVector | Vec2Vector | Vec3Vector | Vec4Vector | QuatVector;
    type PrimitiveDataType = MathType | Collective | PrimitiveVector | Guid;
    type Variant = PrimitiveDataType | Object;
    class Ray {
      constructor();
      constructor(min: Vector3f, max: Vector3f);
      public origin: effect.Amaz.Vector3f;
      public direction: effect.Amaz.Vector3f;
      public eq(v: Ray): boolean;
      public equals(v: Ray): boolean;
      public toString(): string;
      public getPoint(v: number): Vector3f;
      public sqrDistToPoint(v: Vector3f): number;
      public static eq(v0: Ray, v1: Ray): boolean;
      public static equals(v0: Ray, v1: Ray): boolean;
    }
    class AABB {
      constructor();
      constructor(min: Vector3f, max: Vector3f);
      public min_x: number;
      public min_y: number;
      public min_z: number;
      public max_x: number;
      public max_y: number;
      public max_z: number;
      public eq(v: AABB): boolean;
      public equals(v: AABB): boolean;
      public toString(): string;
      public expandBy(other: AABB): void;
      public static eq(v0: AABB, v1: AABB): boolean;
      public static equals(v0: AABB, v1: AABB): boolean;
    }
    class Sphere {
      constructor();
      constructor(center: Vector3f, radius: number);
    }
    class Plane {
      constructor();
      constructor(v0: Vector3f, v1: number);
      public eq(v: Plane): boolean;
      public equals(v: Plane): boolean;
      public toString(): string;
      public getNormal(): Vector3f;
      public getD(): number;
      public getDistance(v: Vector3f): number;
      public getDistance(v: Vector4f): number;
      public getSide(v: Vector3f): Plane;
      public getSide(v0: Vector3f, v1: Vector3f): Plane;
      public toVec4(): Vector4f;
      public static eq(v0: Plane, v1: Plane): boolean;
      public static equals(v0: Plane, v1: Plane): boolean;
    }
    class Color {
      constructor();
      constructor(r: number, g: number, b: number);
      constructor(r: number, g: number, b: number, a: number);
      public a: number;
      public r: number;
      public g: number;
      public b: number;
      public eq(v: Color): boolean;
      public equals(v: Color): boolean;
      public toString(): string;
      public copy(): Color;
      public static eq(v0: Color, v1: Color): boolean;
      public static equals(v0: Color, v1: Color): boolean;
    }
    class DynamicBitset {
      constructor();
      constructor(v0: number, v1: number);
      public eq(v: DynamicBitset): boolean;
      public equals(v: DynamicBitset): boolean;
      public toString(): string;
      public test(v: number): boolean;
      public any(): boolean;
      public none(): boolean;
      public reset(v: number): DynamicBitset;
      public set(): void;
      public set(v: number): void;
      public set(v0: number, v1: number): void;
      public static eq(v0: DynamicBitset, v1: DynamicBitset): boolean;
      public static equals(v0: DynamicBitset, v1: DynamicBitset): boolean;
    }
    class Rect {
      constructor();
      constructor(x: number, y: number, width: number, height: number);
      public x: number;
      public y: number;
      public width: number;
      public height: number;
      public eq(v: Rect): boolean;
      public equals(v: Rect): boolean;
      public toString(): string;
      public copy(): Rect;
      public static eq(v0: Rect, v1: Rect): boolean;
      public static equals(v0: Rect, v1: Rect): boolean;
    }
    class Vector2f {
      constructor();
      constructor(x: number, y: number);
      public x: number;
      public y: number;
      public eq(v: Vector2f): boolean;
      public equals(v: Vector2f): boolean;
      public toString(): string;
      public set(x: number, y: number): void;
      public add(v: Vector2f): Vector2f;
      public sub(v: Vector2f): Vector2f;
      public unm(): Vector2f;
      public mul(v: number): Vector2f;
      public div(v: number): Vector2f;

      /**
       * @return self
       */
      public scale(v: Vector2f): Vector2f;
      public dot(v: Vector2f): number;
      /**
       * @return square of magnitude
       */
      public sqrMagnitude(): number;
      /**
       * @return magnitude
       */
      public magnitude(): number;
      /**
       * @return angle in radians
       */
      public angle(v: Vector2f): number;
      public inverse(): Vector2f;
      public normalize(): Vector2f;
      public normalizeFast(): Vector2f;
      public normalizeSafe(): Vector2f;
      public normalizeSafe(defaultV: Vector2f): Vector2f;
      public lerp(v: Vector2f, s: number): Vector2f;
      public lerp(v0: Vector2f, v1: Vector2f, s: number): Vector2f;
      public min(v: Vector2f): Vector2f;
      public max(v: Vector2f): Vector2f;
      /**
       * @param maxDist optional, default is 0.00001
       */
      public compareApproximately(v: Vector2f): boolean;
      public compareApproximately(v: Vector2f, maxDist: number): boolean;
      /**
       * @param epsilon optional
       */
      public isNormalized(): number;
      public abs(): Vector2f;
      public isFinite(): boolean;
      public distance(v: Vector2f): number;
      public copy(): Vector2f;
      public static eq(v0: Vector2f, v1: Vector2f): boolean;
      public static equals(v0: Vector2f, v1: Vector2f): boolean;
      public static add(v0: Vector2f, v1: Vector2f): Vector2f;
      public static sub(v0: Vector2f, v1: Vector2f): Vector2f;
      public static mul(v0: Vector2f, v1: number): Vector2f;
      public static div(v0: Vector2f, v1: number): Vector2f;
    }
    class Vector3f {
      constructor();
      constructor(x: number, y: number);
      constructor(x: number, y: number, z: number);
      public x: number;
      public y: number;
      public z: number;
      public eq(v: Vector3f): boolean;
      public equals(v: Vector3f): boolean;
      public toString(): string;
      public set(x: number, y: number, z: number): void;
      public add(v: Vector3f): Vector3f;
      public sub(v: Vector3f): Vector3f;
      public unm(): Vector3f;
      public mul(v: number): Vector3f;
      public div(v: number): Vector3f;
      public scale(v: Vector3f): Vector3f;
      public dot(v: Vector3f): number;
      /**
       * @return square of magnitude
       */
      public sqrMagnitude(): number;
      /**
       * @return magnitude
       */
      public magnitude(): number;
      public inverse(): Vector3f;
      public normalize(): Vector3f;
      public normalizeFastest(): Vector3f;
      /**
       * @param invOriginalLength optional
       */
      public normalizeRobust(): Vector3f;
      public normalizeRobust(invOriginalLength: number): Vector3f;
      public normalizeSafe(): Vector3f;
      public normalizeSafe(defaultV: Vector3f): Vector3f;
      public lerp(v: Vector3f, s: number): Vector3f;
      public lerp(v0: Vector3f, v1: Vector3f, s: number): Vector3f;
      public min(v0: Vector3f, v1: Vector3f): Vector3f;
      public max(v0: Vector3f, v1: Vector3f): Vector3f;
      /**
       * @param maxDist optional, default is 0.00001
       */
      public compareApproximately(v: Vector3f): boolean;
      public compareApproximately(v: Vector3f, maxDist: number): boolean;
      /**
       * @param epsilon optional
       */
      public isNormalized(): number;
      public abs(): Vector3f;
      public isFinite(): boolean;
      public distance(v: Vector3f): number;
      public cross(v: Vector3f): Vector3f;
      public reflectVector(normalVector: Vector3f): Vector3f;
      public project(v: Vector3f): Vector3f;
      public orthoNormalizeFast(v0: Vector3f, v1: Vector3f): void;
      /**
       * @param v3 optional
       */
      public orthoNormalize(v0: Vector3f, v1: Vector3f): void;
      public orthoNormalVectorFast(): Vector3f;
      public rotateTowards(v0: Vector3f, v1: number, v2: number): Vector3f;
      public rotateTowards(v0: Vector3f, v1: Vector3f, v2: number, v3: number): Vector3f;
      public slerp(v: Vector3f, s: number): Vector3f;
      public moveTowards(v0: Vector3f, v1: number): Vector3f;
      public moveTowards(v0: Vector3f, v1: Vector3f, v2: number): Vector3f;
      public copy(): Vector3f;
      public static eq(v0: Vector3f, v1: Vector3f): boolean;
      public static equals(v0: Vector3f, v1: Vector3f): boolean;
      public static add(v0: Vector3f, v1: Vector3f): Vector3f;
      public static sub(v0: Vector3f, v1: Vector3f): Vector3f;
      public static mul(v0: Vector3f, v1: number): Vector3f;
      public static div(v0: Vector3f, v1: number): Vector3f;
    }
    class Vector4f {
      constructor();
      constructor(x: number, y: number, z: number, w: number);
      public x: number;
      public y: number;
      public z: number;
      public w: number;
      public eq(v: Vector4f): boolean;
      public equals(v: Vector4f): boolean;
      public toString(): string;
      public add(v: Vector4f): Vector4f;
      public sub(v: Vector4f): Vector4f;
      public unm(): Vector4f;
      public mul(v: Vector4f): Vector4f;
      public mul(v: number): Vector4f;
      public div(v: number): Vector4f;
      public set(x: number, y: number, z: number, w: number): void;
      public dot(v: Vector4f): number;
      public lerp(v: Vector4f, s: number): Vector4f;
      public lerp(v0: Vector4f, v1: Vector4f, s: number): Vector4f;
      public copy(): Vector4f;
      public static eq(v0: Vector4f, v1: Vector4f): boolean;
      public static equals(v0: Vector4f, v1: Vector4f): boolean;
      public static add(v0: Vector4f, v1: Vector4f): Vector4f;
      public static sub(v0: Vector4f, v1: Vector4f): Vector4f;
      public static mul(v0: Vector4f, v1: Vector4f): Vector4f;
      public static mul(v0: Vector4f, v1: number): Vector4f;
      public static div(v0: Vector4f, v1: number): Vector4f;
    }
    class Quaternionf {
      constructor();
      constructor(x: number, y: number, z: number, w: number);
      public x: number;
      public y: number;
      public z: number;
      public w: number;
      public eq(v: Quaternionf): boolean;
      public equals(v: Quaternionf): boolean;
      public toString(): string;
      public add(v: Quaternionf): Quaternionf;
      public sub(v: Quaternionf): Quaternionf;
      // public negate(): Quaternionf
      public mul(v: Quaternionf): Quaternionf;
      public unm(): Quaternionf;
      public set(x: number, y: number, z: number, w: number): void;
      public identity(): Quaternionf;
      public inverse(): Quaternionf;
      public eulerToQuaternion(v: Vector3f): Quaternionf;
      public quaternionToEuler(): Vector3f;
      public copy(): Quaternionf;
      public fromToQuaternionSafe(from: Vector3f, to: Vector3f): Quaternionf;
      public lookRotationToQuaternion(viewVec: Vector3f, upVec: Vector3f): Quaternionf;
      public LookRotationToQuaternion(viewVec: Vector3f, upVec: Vector3f): Quaternionf;
      public rotateVectorByQuat(v: Vector3f): Vector3f;
      public slerp(v: Quaternionf, s: number): Quaternionf;
      /**
       * @param angle in radians
       */
      public axisAngleToQuaternion(axis: Vector3f, angle: number): Quaternionf;
      public static eq(v0: Quaternionf, v1: Quaternionf): boolean;
      public static equals(v0: Quaternionf, v1: Quaternionf): boolean;
      public static add(v0: Quaternionf, v1: Quaternionf): Quaternionf;
      public static sub(v0: Quaternionf, v1: Quaternionf): Quaternionf;
      public static mul(q0: Quaternionf, q1: Quaternionf): Quaternionf;
      public static identity(): Quaternionf;
      public static fromToQuaternionSafe(from: Vector3f, to: Vector3f): Quaternionf;
      public static lookRotationToQuaternion(viewVec: Vector3f, upVec: Vector3f): Quaternionf;
      public static rotateVectorByQuat(v0: Quaternionf, v1: Vector3f): Vector3f;
      public static slerp(v0: Quaternionf, v1: Quaternionf, s: number): Quaternionf;
      public static axisAngleToQuaternion(axis: Vector3f, angle: number): Quaternionf;
    }
    class Matrix3x3f {
      constructor();
      constructor(v: Matrix4x4f);
      constructor(m0: number, m1: number, m2: number, m3: number, m4: number, m5: number, m6: number, m7: number, m8: number);
      public eq(v: Matrix3x3f): boolean;
      public equals(v: Matrix3x3f): boolean;
      public toString(): string;
      public mul(m: Matrix3x3f): Matrix3x3f;
      public set(row: number, col: number, val: number): void;
      public get(row: number, col: number): number;
      public getColumn(col: number): Vector3f;
      public multiplyVector3(v: Vector3f): Vector3f;
      public multiplyVector3Transpose(v: Vector3f): Vector3f;
      public multiplyPoint3Transpose(v: Vector3f): Vector3f;
      public getDeterminant(): number;
      /**
       * @return self
       */
      public transpose(): Matrix3x3f;
      public invert(): Matrix3x3f;
      public invertTranspose(): void;
      /**
       * @return self
       */
      public setIdentity(): Matrix3x3f;
      /**
       * @return self
       */
      public setZero(): Matrix3x3f;
      /**
       * @return self
       */
      public setFromToRotation(from: Vector3f, to: Vector3f): Matrix3x3f;
      /**
       * @param angle in radians
       * @return self
       */
      public setAxisAngle(axis: Vector3f, angle: number): Matrix3x3f;
      /**
       * @return self
       */
      public setOrthoNormalBasis(v1: Vector3f, v2: Vector3f, v3: Vector3f): Matrix3x3f;
      /**
       * @return self
       */
      public setOrthoNormalBasisInverse(v1: Vector3f, v2: Vector3f, v3: Vector3f): Matrix3x3f;
      /**
       * @return self
       */
      public setScale(v: Vector3f): Matrix3x3f;
      /**
       * @return self
       */
      public scale(v: Vector3f): Matrix3x3f;
      /**
       * @param epsilon optional
       */
      public isIdentity(): boolean;
      public isIdentity(v: number): boolean;
      public lookRotationToMatrix(viewVec: Vector3f, upVec: Vector3f, outMat: Matrix3x3f): boolean;
      /**
       * @param outVec output
       */
      public matrixToEuler(outVec: Vector3f): boolean;
      public eulerToMatrix(euler: Vector3f, outMat: Matrix3x3f): void;
      public orthoNormalize(): void;
      public static eq(v0: Matrix3x3f, v1: Matrix3x3f): boolean;
      public static equals(v0: Matrix3x3f, v1: Matrix3x3f): boolean;
      public static lookRotationToMatrix(viewVec: Vector3f, upVec: Vector3f, outMat: Matrix3x3f): boolean;
      public static matrixToEuler(v0: Matrix3x3f, outVec: Vector3f): boolean;
      public static eulerToMatrix(euler: Vector3f, outMat: Matrix3x3f): void;
      public static orthoNormalize(v0: Matrix3x3f): void;
    }
    class Matrix4x4f {
      constructor();
      constructor(v: Matrix3x3f);
      constructor(m0: number, m1: number, m2: number, m3: number, m4: number, m5: number, m6: number, m7: number, m8: number, m9: number, m10: number, m11: number, m12: number, m13: number, m14: number, m15: number);
      public eq(v: Matrix4x4f): boolean;
      public equals(v: Matrix4x4f): boolean;
      public toString(): string;
      public mul(m: Matrix4x4f): Matrix4x4f;
      public set(row: number, col: number, val: number): void;
      public get(row: number, col: number): number;
      public getColumn(col: number): Vector4f;
      public multiplyVector3(v: Vector3f): Vector3f;
      public multiplyVector4(v: Vector4f): Vector4f;
      public multiplyPoint3(p: Vector3f): Vector3f;
      public getDeterminant(): number;
      /**
       * @return self
       */
      public transpose(): Matrix4x4f;
      /**
       * @return self
       */
      public invert_Full(): Matrix4x4f;
      /**
       * @return self
       */
      public setIdentity(): Matrix4x4f;
      /**
       * @return self
       */
      public setFromToRotation(from: Vector3f, to: Vector3f): Matrix4x4f;
      /**
       * @return self
       */
      public setOrthoNormalBasis(v1: Vector3f, v2: Vector3f, v3: Vector3f): Matrix4x4f;
      /**
       * @return self
       */
      public setOrthoNormalBasisInverse(v1: Vector3f, v2: Vector3f, v3: Vector3f): Matrix4x4f;
      /**
       * @return self
       */
      public setScale(v: Vector3f): Matrix4x4f;
      /**
       * @return self
       */
      public scale(v: Vector3f): Matrix4x4f;
      /**
       * @param epsilon optional
       */
      public isIdentity(): boolean;
      public isIdentity(epsilon: number): boolean;
      public perspectiveMultiplyVector3(inVec: Vector3f, outVec: Vector3f): boolean;
      public perspectiveMultiplyPoint3(inP: Vector3f, outP: Vector3f): boolean;
      public inverseMultiplyVector3Affine(v: Vector3f): Vector3f;
      public inverseMultiplyPoint3Affine(p: Vector3f): Vector3f;
      /**
       * @return self
       */
      public copy(inM: Matrix4x4f): Matrix4x4f;
      /**
       * @return self
       */
      public setPerspective(fovy: number, aspect: number, zNear: number, zFar: number): Matrix4x4f;
      /**
       * @return self
       */
      public setPerspectiveCotan(cotanHalfFOV: number, zNear: number, zFar: number): Matrix4x4f;
      /**
       * @return self
       */
      public setOrtho(left: number, right: number, bottom: number, top: number, zNear: number, zFar: number): Matrix4x4f;
      /**
       * @return self
       */
      public setFrustum(left: number, right: number, bottom: number, top: number, zNear: number, zFar: number): Matrix4x4f;
      public getAxisX(): Vector3f;
      public getAxisY(): Vector3f;
      public getAxisZ(): Vector3f;
      public getPosition(): Vector3f;
      public getRow(row: number): Vector4f;
      public setAxisX(v: Vector3f): Matrix4x4f;
      public setAxisY(v: Vector3f): Matrix4x4f;
      public setAxisZ(v: Vector3f): Matrix4x4f;
      public setPosition(v: Vector3f): Matrix4x4f;
      public setRow(row: number, v: Vector4f): Matrix4x4f;
      public setColumn(col: number, v: Vector4f): Matrix4x4f;
      /**
       * @return self
       */
      public setTranslate(v: Vector3f): Matrix4x4f;
      /**
       * @return self
       */
      public setPositionAndOrthoNormalBasis(inP: Vector3f, inX: Vector3f, inY: Vector3f, inZ: Vector3f): Matrix4x4f;
      /**
       * @return self
       */
      public translate(v: Vector3f): Matrix4x4f;
      /**
       * @return self
       */
      public addTranslate(v: Vector3f): Matrix4x4f;
      public setTR(t: Vector3f, r: Quaternionf): void;
      public setTRS(t: Vector3f, r: Quaternionf, s: Vector3f): void;
      public setTRInverse(t: Vector3f, r: Quaternionf): void;
      public getDecompose(outT: Vector3f, outS: Vector3f, outR: Quaternionf): void;
      /**
       * @param epsilon optional, default is 0.00001
       */
      public compareApproximately(m: Matrix4x4f, m1: Matrix4x4f, epsilon: number): boolean;
      public compareApproximately(m: Matrix4x4f, m1: Matrix4x4f): boolean;
      public transformPoints3x3(inVec3Ptr: Vector3f, outVec3Ptr: Vector3f, count: number): void;
      public transformPoints3x3(inVec3Ptr: Vector3f, inStride: number, outVec3Ptr: Vector3f, outStride: number, count: number): void;
      public transformPoints3x4(inVec3Ptr: Vector3f, outVec3Ptr: Vector3f): void;
      public transformPoints3x4(inVec3Ptr: Vector3f, outVec3Ptr: Vector3f, count: number): void;
      public transformPoints3x4(inVec3Ptr: Vector3f, inStride: number, outVec3Ptr: Vector3f, outStride: number, count: number): void;
      /**
       * @param inM input
       * @param outM output
       */
      public multiplyMatrices3x4(inM: Matrix4x4f, outM: Matrix4x4f): void;
      /**
       * @param inM input
       * @param outM output
       */
      public copyMatrix(inM: Matrix4x4f, outM: Matrix4x4f): void;
      /**
       * @param inM input
       * @param outM output
       */
      public transposeMatrix4x4(inM: Matrix4x4f, outM: Matrix4x4f): void;
      /**
       * @param inM1 input
       * @param inM2 input
       * @param outM output
       */
      public multiplyMatrices4x4(inM1: Matrix4x4f, inM2: Matrix4x4f, outM: Matrix4x4f): void;
      /**
       * @param inM1Vec input
       * @param inM2Vec input
       * @param outMVec output
       */
      public multiplyMatrixArray4x4(inM1Vec: Matrix4x4f, inM2Vec: Matrix4x4f, outMVec: Matrix4x4f, count: number): void;
      /**
       * @param inM1Vec input
       * @param inM2Vec input
       * @param outMVec output
       */
      public multiplyMatrixArrayWithBase4x4(baseM: Matrix4x4f, inM1Vec: Matrix4x4f, inM2Vec: Matrix4x4f, outMVec: Matrix4x4f, count: number): void;
      /**
       * @param outM output
       */
      public invert_General3D(outM: Matrix4x4f): boolean;
      public isFinite(): boolean;
      public static eq(v0: Matrix3x3f, v1: Matrix3x3f): boolean;
      public static equals(v0: Matrix3x3f, v1: Matrix3x3f): boolean;
      public static compareApproximately(m: Matrix4x4f, epsilon: Matrix4x4f): boolean;
      public static compareApproximately(m: Matrix4x4f, epsilon: Matrix4x4f, dist: number): boolean;
      public static transformPoints3x3(v0: Matrix4x4f, inVec3Ptr: Vector3f, outVec3Ptr: Vector3f, count: number): void;
      public static transformPoints3x3(v0: Matrix4x4f, inVec3Ptr: Vector3f, inStride: number, outVec3Ptr: Vector3f, outStride: number, count: number): void;
      public static transformPoints3x4(v0: Matrix4x4f, inVec3Ptr: Vector3f, outVec3Ptr: Vector3f): void;
      public static transformPoints3x4(v0: Matrix4x4f, inVec3Ptr: Vector3f, outVec3Ptr: Vector3f, count: number): void;
      public static transformPoints3x4(v0: Matrix4x4f, inVec3Ptr: Vector3f, inStride: number, outVec3Ptr: Vector3f, outStride: number, count: number): void;
      /**
       * @param inM input
       * @param outM output
       */
      public static multiplyMatrices3x4(inM0: Matrix4x4f, inM1: Matrix4x4f, outM: Matrix4x4f): void;
      /**
       * @param inM input
       * @param outM output
       */
      public static copyMatrix(inM: Matrix4x4f, outM: Matrix4x4f): void;
      /**
       * @param inM input
       * @param outM output
       */
      public static transposeMatrix4x4(inM: Matrix4x4f, outM: Matrix4x4f): void;
      /**
       * @param inM1 input
       * @param inM2 input
       * @param outM output
       */
      public static multiplyMatrices4x4(inM1: Matrix4x4f, inM2: Matrix4x4f, outM: Matrix4x4f): void;
      /**
       * @param inM1Vec input
       * @param inM2Vec input
       * @param outMVec output
       */
      public static multiplyMatrixArray4x4(inM1Vec: Matrix4x4f, inM2Vec: Matrix4x4f, outMVec: Matrix4x4f, count: number): void;
      /**
       * @param inM1Vec input
       * @param inM2Vec input
       * @param outMVec output
       */
      public static multiplyMatrixArrayWithBase4x4(baseM: Matrix4x4f, inM1Vec: Matrix4x4f, inM2Vec: Matrix4x4f, outMVec: Matrix4x4f, count: number): void;
      /**
       * @param outM output
       */
      public static invert_General3D(inM: Matrix4x4f, outM: Matrix4x4f): boolean;
    }
    class Guid {
      constructor();
      constructor(v: ArrayBuffer);
      constructor(a: string, b: string);
      public eq(v: Guid): boolean;
      public equals(v: Guid): boolean;
      public toString(): string;
      public isEmpty(): boolean;
    }
    class Vector {
      constructor();
      public handle: number;
      public eq(v: Vector): boolean;
      public equals(v: Vector): boolean;
      public pushBack(v: Variant): void;
      public popBack(): Variant;
      public pushFront(v: Variant): void;
      public popFront(): Variant;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public get(index: number): Variant;
      public set(index: number, v: Variant): void;
      public insert(index: number, v: Variant): void;
      public hash(): number;
      public front(): Variant;
      public back(): Variant;
      public remove(index: number): void;
      public copy(): Vector;
      public deepCopy(): Vector;
      public clone(): Vector;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: Variant): number;
      public find(v: Variant, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: Variant): number;
      public rfind(v: Variant, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: Variant): number;
      public count(v: Variant): number;
      public has(v: Variant): boolean;
      public erase(index: Variant): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(v: number): void;
    }
    class Map {
      constructor();
      public handle: number;
      public eq(v: Map): boolean;
      public equals(v: Map): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public get(key: Variant): Variant;
      public getVectorKeys(): Vector;
      public set(key: Variant, value: Variant): void;
      public hash(): number;
      public insert(key: Variant, value: Variant): void;
      public remove(key: Variant): void;
      public copy(): Map;
      public deepCopy(): Map;
      public clone(): Map;
      public find(key: Variant): Variant;
      public has(key: Variant): boolean;
      public hasAll(keys: Vector): boolean;
    }
    class Int8Vector {
      constructor();
      public handle: number;
      public eq(v: Int8Vector): boolean;
      public equals(v: Int8Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: number): void;
      public popBack(): number;
      public pushFront(v: number): void;
      public popFront(): number;
      public get(index: number): number;
      public set(index: number, value: number): void;
      public hash(): number;
      public front(): number;
      public back(): number;
      public insert(index: number, value: number): void;
      public remove(index: number): void;
      public copy(): Int8Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: number, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: number, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: number): number;
      public count(v: number): number;
      public has(v: number): boolean;
      public erase(v: number): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class Int16Vector {
      constructor();
      public handle: number;
      public eq(v: Int16Vector): boolean;
      public equals(v: Int16Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: number): void;
      public popBack(): number;
      public pushFront(v: number): void;
      public popFront(): number;
      public get(index: number): number;
      public set(index: number, value: number): void;
      public hash(): number;
      public front(): number;
      public back(): number;
      public insert(index: number, value: number): void;
      public remove(index: number): void;
      public copy(): Int16Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: number, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: number, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: number): number;
      public count(v: number): number;
      public has(v: number): boolean;
      public erase(v: number): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class Int32Vector {
      constructor();
      public handle: number;
      public eq(v: Int32Vector): boolean;
      public equals(v: Int32Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: number): void;
      public popBack(): number;
      public pushFront(v: number): void;
      public popFront(): number;
      public get(index: number): number;
      public set(index: number, value: number): void;
      public hash(): number;
      public front(): number;
      public back(): number;
      public insert(index: number, value: number): void;
      public remove(index: number): void;
      public copy(): Int32Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: number, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: number, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: number): number;
      public count(v: number): number;
      public has(v: number): boolean;
      public erase(v: number): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class Int64Vector {
      constructor();
      public handle: number;
      public eq(v: Int64Vector): boolean;
      public equals(v: Int64Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: number): void;
      public popBack(): number;
      public pushFront(v: number): void;
      public popFront(): number;
      public get(index: number): number;
      public set(index: number, value: number): void;
      public hash(): number;
      public front(): number;
      public back(): number;
      public insert(index: number, value: number): void;
      public remove(index: number): void;
      public copy(): Int64Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: number, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: number, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: number): number;
      public count(v: number): number;
      public has(v: number): boolean;
      public erase(v: number): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class UInt8Vector {
      constructor();
      public handle: number;
      public eq(v: UInt8Vector): boolean;
      public equals(v: UInt8Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: number): void;
      public popBack(): number;
      public pushFront(v: number): void;
      public popFront(): number;
      public get(index: number): number;
      public set(index: number, value: number): void;
      public hash(): number;
      public front(): number;
      public back(): number;
      public insert(index: number, value: number): void;
      public remove(index: number): void;
      public copy(): UInt8Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: number, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: number, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: number): number;
      public count(v: number): number;
      public has(v: number): boolean;
      public erase(v: number): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class UInt16Vector {
      constructor();
      public handle: number;
      public eq(v: UInt16Vector): boolean;
      public equals(v: UInt16Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: number): void;
      public popBack(): number;
      public pushFront(v: number): void;
      public popFront(): number;
      public get(index: number): number;
      public set(index: number, value: number): void;
      public hash(): number;
      public front(): number;
      public back(): number;
      public insert(index: number, value: number): void;
      public remove(index: number): void;
      public copy(): UInt16Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: number, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: number, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: number): number;
      public count(v: number): number;
      public has(v: number): boolean;
      public erase(v: number): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class UInt32Vector {
      constructor();
      public handle: number;
      public eq(v: UInt32Vector): boolean;
      public equals(v: UInt32Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: number): void;
      public popBack(): number;
      public pushFront(v: number): void;
      public popFront(): number;
      public get(index: number): number;
      public set(index: number, value: number): void;
      public hash(): number;
      public front(): number;
      public back(): number;
      public insert(index: number, value: number): void;
      public remove(index: number): void;
      public copy(): UInt32Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: number, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: number, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: number): number;
      public count(v: number): number;
      public has(v: number): boolean;
      public erase(v: number): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class FloatVector {
      constructor();
      public handle: number;
      public eq(v: FloatVector): boolean;
      public equals(v: FloatVector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: number): void;
      public popBack(): number;
      public pushFront(v: number): void;
      public popFront(): number;
      public get(index: number): number;
      public set(index: number, value: number): void;
      public hash(): number;
      public front(): number;
      public back(): number;
      public insert(index: number, value: number): void;
      public remove(index: number): void;
      public copy(): FloatVector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: number, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: number, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: number): number;
      public count(v: number): number;
      public has(v: number): boolean;
      public erase(v: number): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class DoubleVector {
      constructor();
      public handle: number;
      public eq(v: DoubleVector): boolean;
      public equals(v: DoubleVector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: number): void;
      public popBack(): number;
      public pushFront(v: number): void;
      public popFront(): number;
      public get(index: number): number;
      public set(index: number, value: number): void;
      public hash(): number;
      public front(): number;
      public back(): number;
      public insert(index: number, value: number): void;
      public remove(index: number): void;
      public copy(): DoubleVector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: number, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: number, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: number): number;
      public count(v: number): number;
      public has(v: number): boolean;
      public erase(v: number): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class StringVector {
      constructor();
      public handle: number;
      public eq(v: StringVector): boolean;
      public equals(v: StringVector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: string): void;
      public popBack(): string;
      public pushFront(v: string): void;
      public popFront(): string;
      public get(index: number): string;
      public set(index: number, value: string): void;
      public hash(): number;
      public front(): string;
      public back(): string;
      public insert(index: number, value: string): void;
      public remove(index: number): void;
      public copy(): StringVector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: string, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: string, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: string): number;
      public count(v: string): number;
      public has(v: string): boolean;
      public erase(v: string): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class Vec2Vector {
      constructor();
      public handle: number;
      public eq(v: Vec2Vector): boolean;
      public equals(v: Vec2Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: Vector2f): void;
      public popBack(): Vector2f;
      public pushFront(v: Vector2f): void;
      public popFront(): Vector2f;
      public get(index: number): Vector2f;
      public set(index: number, value: Vector2f): void;
      public hash(): number;
      public front(): Vector2f;
      public back(): Vector2f;
      public insert(index: number, value: Vector2f): void;
      public remove(index: number): void;
      public copy(): Vec2Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: Vector2f, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: Vector2f, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: Vector2f): number;
      public count(v: Vector2f): number;
      public has(v: Vector2f): boolean;
      public erase(v: Vector2f): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class Vec3Vector {
      constructor();
      public handle: number;
      public eq(v: Vec3Vector): boolean;
      public equals(v: Vec3Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: Vector3f): void;
      public popBack(): Vector3f;
      public pushFront(v: Vector3f): void;
      public popFront(): Vector3f;
      public get(index: number): Vector3f;
      public set(index: number, value: Vector3f): void;
      public hash(): number;
      public front(): Vector3f;
      public back(): Vector3f;
      public insert(index: number, value: Vector3f): void;
      public remove(index: number): void;
      public copy(): Vec3Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: Vector3f, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: Vector3f, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: Vector3f): number;
      public count(v: Vector3f): number;
      public has(v: Vector3f): boolean;
      public erase(v: Vector3f): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class Vec4Vector {
      constructor();
      public handle: number;
      public eq(v: Vec4Vector): boolean;
      public equals(v: Vec4Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: Vector4f): void;
      public popBack(): Vector4f;
      public pushFront(v: Vector4f): void;
      public popFront(): Vector4f;
      public get(index: number): Vector4f;
      public set(index: number, value: Vector4f): void;
      public hash(): number;
      public front(): Vector4f;
      public back(): Vector4f;
      public insert(index: number, value: Vector4f): void;
      public remove(index: number): void;
      public copy(): Vec4Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: Vector4f, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: Vector4f, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: Vector4f): number;
      public count(v: Vector4f): number;
      public has(v: Vector4f): boolean;
      public erase(v: Vector4f): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class QuatVector {
      constructor();
      public handle: number;
      public eq(v: QuatVector): boolean;
      public equals(v: QuatVector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: Quaternionf): void;
      public popBack(): Quaternionf;
      public pushFront(v: Quaternionf): void;
      public popFront(): Quaternionf;
      public get(index: number): Quaternionf;
      public set(index: number, value: Quaternionf): void;
      public hash(): number;
      public front(): Quaternionf;
      public back(): Quaternionf;
      public insert(index: number, value: Quaternionf): void;
      public remove(index: number): void;
      public copy(): QuatVector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: Quaternionf, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: Quaternionf, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: Quaternionf): number;
      public count(v: Quaternionf): number;
      public has(v: Quaternionf): boolean;
      public erase(v: Quaternionf): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class Mat3Vector {
      constructor();
      public handle: number;
      public eq(v: Mat3Vector): boolean;
      public equals(v: Mat3Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: Matrix3x3f): void;
      public popBack(): Matrix3x3f;
      public pushFront(v: Matrix3x3f): void;
      public popFront(): Matrix3x3f;
      public get(index: number): Matrix3x3f;
      public set(index: number, value: Matrix3x3f): void;
      public hash(): number;
      public front(): Matrix3x3f;
      public back(): Matrix3x3f;
      public insert(index: number, value: Matrix3x3f): void;
      public remove(index: number): void;
      public copy(): Mat3Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: Matrix3x3f, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: Matrix3x3f, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: Matrix3x3f): number;
      public count(v: Matrix3x3f): number;
      public has(v: Matrix3x3f): boolean;
      public erase(v: Matrix3x3f): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
    class Mat4Vector {
      constructor();
      public handle: number;
      public eq(v: Mat4Vector): boolean;
      public equals(v: Mat4Vector): boolean;
      public size(): number;
      public empty(): boolean;
      public clear(): void;
      public pushBack(v: Matrix4x4f): void;
      public popBack(): Matrix4x4f;
      public pushFront(v: Matrix4x4f): void;
      public popFront(): Matrix4x4f;
      public get(index: number): Matrix4x4f;
      public set(index: number, value: Matrix4x4f): void;
      public hash(): number;
      public front(): Matrix4x4f;
      public back(): Matrix4x4f;
      public insert(index: number, value: Matrix4x4f): void;
      public remove(index: number): void;
      public copy(): Mat4Vector;
      /**
       * @param index start index
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public find(v: Matrix4x4f, index: number): number;
      /**
       * @param index start id
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public rfind(v: Matrix4x4f, index: number): number;
      /**
       * @return if cannot find element v, return 0xFFFFFFFF
       */
      public findLast(v: Matrix4x4f): number;
      public count(v: Matrix4x4f): number;
      public has(v: Matrix4x4f): boolean;
      public erase(v: Matrix4x4f): void;
      public sort(): void;
      public shuffle(): void;
      public reverse(): void;
      public resize(n: number): void;
    }
  }
}
declare namespace effect {
  namespace Amaz {
    type prototype = any;

    /**
     * RTTI Descriptor
     */
    interface RTTIDescriptor {
      Children: Array<prototype>;
      EnumNameMap: {
        [key: string]: number;
      };
      EnumValueMap: {
        [key: number]: string;
      };
      FullName: string;
      Methods: Array<RTTIMethodDescriptor>;
      Name: string;
      Parent: prototype;
      Properties: Array<RTTIPropertyDescriptor>;
      This: prototype;
      isClass: boolean;
      isDerivedFromObject: boolean;
      isEnum: boolean;
      isExternal: boolean;
      isLocal: boolean;
      isPrimitive: boolean;
      attributes: RTTIDescriptorAttributes;
    }
    interface RTTIDescriptorAttributes {
      classAttr?: {
        path: string;
      };
    }

    /**
     * RTTI Method Descriptor
     */
    interface RTTIMethodDescriptor {
      Argc: number;
      Args: Array<RTTIArgumentDescriptor>;
      DefaultValues: Array<any>;
      Name: string;
      ReturnClass: prototype;
      isConst: boolean;
      isReturnConst: boolean;
      isReturnRef: boolean;
      isReturnVoid: boolean;
      _proto: prototype;
    }

    /**
     * RTTI Argument Descriptor
     */
    interface RTTIArgumentDescriptor {
      Name: string;
      isConstRef: boolean;
      _proto: prototype;
    }

    /**
     * RTTI Property Descriptor
     */
    interface RTTIPropertyDescriptor {
      Name: string;
      PropertyRTTI: prototype;
      Getter: RTTIMethodDescriptor;
      Setter: RTTIMethodDescriptor;
      isClone: boolean;
      isScriptBind: boolean;
      isSerialize: boolean;
      isWeak: boolean;
      isWeakBind: boolean;
      attributes: RTTIPropertyDescriptorAttributes;
    }

    /**
     * RTTI Property Attributes
     */
    interface RTTIPropertyDescriptorAttributes {
      displayAttr?: DisplayAttribute;
      hiddenAttr?: HiddenAttribute;
      orderAttr?: OrderAttribute;
      expandAttr?: ExpandAttribute;
      tileAttr?: TileAttribute;
      readonlyAttr?: ReadonlyAttribute;
      rangeAttr?: RangeAttribute;
      dragAttr?: DragAttribute;
      optionAttr?: OptionAttribute;
      enumArrowAttr?: EnumArrowAttribute;
      sliderAttr?: SliderAttribute;
      inputAttr?: InputAttribute;
      dirtyAttr?: DirtyAttribute;
      typeAttr?: TypeAttribute;
      noAlphaAttr?: NoAlphaAttribute;
      sizeAttr?: SizeAttribute;
      sizeOnlyAttr?: SizeOnlyAttribute;
      colorAttr?: ColorAttribute;
      radian2AngleAttr?: Radian2AngleAttribute;
      vectorReadonlyAttr?: VectorReadonlyAttribute;
      weakShowAttr?: WeakShowAttribute;
      colorMapAttr?: ColorMapAttribute;
      buttonAttr?: ButtonAttribute;
      createInstanceAttr?: CreateInstanceAttribute;
    }

    /**
     * Property Attribute (Base class)
     */
    interface Attribute {}
    interface DisplayAttribute extends Attribute {
      label: string;
    }
    interface HiddenAttribute extends Attribute {}
    interface OrderAttribute extends Attribute {
      order: number;
    }
    interface ExpandAttribute extends Attribute {
      hasTitle: boolean;
      title: string;
    }
    interface TileAttribute extends Attribute {}
    interface ReadonlyAttribute extends Attribute {}
    interface RangeAttribute extends Attribute {
      min: Variant;
      max: Variant;
    }
    interface DragAttribute extends Attribute {
      step: Variant;
    }
    interface OptionAttribute extends Attribute {
      labels: string[];
      values: Variant[];
    }
    interface EnumArrowAttribute extends Attribute {}
    interface SliderAttribute extends Attribute {}
    interface InputAttribute extends Attribute {}
    interface DirtyAttribute extends Attribute {
      keys: string[];
    }
    interface TypeAttribute extends Attribute {
      type: string;
    }
    interface NoAlphaAttribute extends Attribute {}
    interface SizeAttribute extends Attribute {
      min: number;
      max: number;
    }
    interface SizeOnlyAttribute extends Attribute {}
    interface ColorAttribute extends Attribute {}
    interface Radian2AngleAttribute extends Attribute {}
    interface VectorReadonlyAttribute extends Attribute {}
    interface WeakShowAttribute extends Attribute {}
    interface ColorMapAttribute extends Attribute {}
    interface ButtonAttribute extends Attribute {
      label: string;
    }
    interface CreateInstanceAttribute extends Attribute {
      types: string[];
    }

    /**
     * Generic Interface
     */
    interface IGenericRTTI {
      RTTI: RTTIDescriptor;
      prototype: {
        RTTI: RTTIDescriptor;
      };
    }

    /**
     * Base Class interface
     */
    interface AObject {
      RTTI: RTTIDescriptor;
    }
  }
}
declare namespace effect {
  namespace Amaz {
    class AABB2D extends AObject {
      constructor();
      public min: Vector2f;
      public max: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief algorithm manager
    */
    class AEAlgorithmManager extends AObject {
      constructor();
      public handle: number;
      public getAEAlgorithmResult(): AEAlgorithmResult;
      /**
      * @brief Runtime set bach algorithm enable or disable support multi-instance
      * graphName can be null, if null, will search in all the graph
      * name can be algorithm name (face) or node name (face_0)
      *
      * @param graphName
      * @param name
      * @param enable
      */
      public setAlgorithmEnable(graphName: string, name: string, enable: boolean): boolean;
      /**
      * @brief Runtime set bach algorithm int64_t parameters support multi-instance
      * graphName can be null, if null, will search in all the graph
      * name can be algorithm name (face) or node name (face_0)
      *
      * @param graphName
      * @param nodeName
      * @param key
      * @param value
      */
      public setAlgorithmParamInt(graphName: string, name: string, key: string, value: number): boolean;
      /**
      * @brief Runtime set bach algorithm float parameters support multi-instance
      * graphName can be null, if null, will search in all the graph
      * name can be algorithm name (face) or node name (face_0)
      *
      * @param graphName
      * @param nodeName
      * @param key
      * @param value
      */
      public setAlgorithmParamFloat(graphName: string, name: string, key: string, value: number): boolean;
      /**
      * @brief Runtime set bach algorithm string parameters support multi-instance
      * graphName can be null, if null, will search in all the graph
      * name can be algorithm name (face) or node name (face_0)
      *
      * @param graphName
      * @param nodeName
      * @param key
      * @param value
      */
      public setAlgorithmParamStr(graphName: string, name: string, key: string, value: string): boolean;
      /**
      * @brief Runtime set algorithm input texture, such as RenderTexture
      *
      * @param inputSlot
      * @param texture
      * @param keyVals
      * @return
      */
      public setInputTexture(inputSlot: number, texture: Texture, config: Map): boolean;
      public setInputTextureStr(inputSlot: string, texture: Texture, config: Map): boolean;
      /**
      * @brief Convert face mesh points 106 to 295
      *
      * @param points
      * @return AmazingEngine::Vec2Vector
      */
      public face106To295(points: Vec2Vector): Vec2Vector;
      public setBlitSize(graphName: string, width: number, height: number): boolean;
      public getAlgorithmParamMap(graphName: string, nodeName: string): Map;
      public setAlgorithmCommand(key: string, graphName: string, nodeName: string): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum AEPersonKeyPointType {
      /**
      * 
      */
      kNose,
      /**
      * 
      */
      kNeck,
      /**
      * 
      */
      kRightShoulder,
      /**
      * 
      */
      kRightElbow,
      /**
      * 
      */
      kRightWrist,
      /**
      * 
      */
      kLeftShoulder,
      /**
      * 
      */
      kLeftElbow,
      /**
      * 
      */
      kLeftWrist,
      /**
      * 
      */
      kRightHip,
      /**
      * 
      */
      kRightKnee,
      /**
      * 
      */
      kRightAnkle,
      /**
      * 
      */
      kLeftHip,
      /**
      * 
      */
      kLeftKnee,
      /**
      * 
      */
      kLeftAnkle,
      /**
      * 
      */
      kRightEye,
      /**
      * 
      */
      kLeftEye,
      /**
      * 
      */
      kRightEar,
      /**
      * 
      */
      kLeftEar,
      /**
      * 
      */
      kRightHand,
      /**
      * 
      */
      kLeftHand,
    }
    namespace AEPersonKeyPointType {
      let RTTI: RTTIDescriptor;
    }
    class AMGARHitTestResultTask extends AObject {
      constructor();
      public handle: number;
      public getLocalToWorldTransform(): Matrix4x4f;
      public getTrackedAnchor(): ARTrackedAnchor;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGARRaycastResult extends AObject {
      constructor();
      public handle: number;
      public getWorldTransform(): Matrix4x4f;
      public getRaycastTarget(): void;
      public getRaycastAlignment(): void;
      public getAnchor(): ARTrackedAnchor;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AudioEffectNode Audio Effect
    */
    class AMGAudioEffectNode extends AMGAudioNode {
      constructor();
      public handle: number;
      /**
      * @brief setParameter for AudioEffectNode
      * @param s key
      * @param f value
      */
      public setParameter(s: string, f: number): void;
      /**
      * @brief setParameters for AudioEffectNode
      * @param m parametersMap
      */
      public setParameters(m: Map): void;
      public getParameter(s: string): number;
      public getParameterRange(s: string): Vector2f;
      public getParameterDescriptors(): Map;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Audio Extractor Node
    */
    class AMGAudioExtractorNode extends AMGAudioNode {
      constructor();
      public handle: number;
      /**
      * @brief get the Extractor Result about current Node.
      * @return AudioExtractorResult*
      */
      public getResult(): AudioExtractorResult;
      /**
      * @brief setParameter for ExtractorNode
      * @param s key
      * @param f value
      */
      public setParameter(s: string, f: number): void;
      /**
      * @brief set String Parameter for ExtractorNode
      * @param s key
      * @param f value
      */
      public setStringParameter(s: string, s0: string): void;
      public getParameter(s: string): number;
      public getStringParameter(s: string): string;
      public getParameterDescriptors(): Map;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGAudioGainNode extends AMGAudioNode {
      constructor();
      public gain: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Audio clip of resource.
    */
    class AMGAudioGraph extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief createNode from type and config.
      * @param type audioNode type.
      * @param config audioNode config.
      * @return AMGAudioNode*
      */
      public createAudioNode(type: string, config: Map): AMGAudioNode;
      /**
      * @brief create Audio Effect Node from type and config.
      * @param type audio effect node type.
      * @param config audio effect node config.
      * @return AMGAudioNode*
      */
      public createAudioEffectNode(type: string, config: Map): AMGAudioNode;
      /**
      * @brief create Audio Extractor Node from type and config.
      * @param type audio extractor node type.
      * @param config audio extractor node config.
      * @return AMGAudioNode*
      */
      public createAudioExtractorNode(type: string, config: Map): AMGAudioNode;
      public getTTSManager(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Audio Music DSP Node
    */
    class AMGAudioMDSPNode extends AMGAudioNode {
      constructor();
      public handle: number;
      /**
      * @brief create Music DSP graph from graph description file
      * @param graphFile Music DSP graph description file
      * @return error number
      */
      public setupMDSPGraphFromFile(s: string): number;
      /**
      * @brief add resource search path
      * @param path resource search path
      */
      public addSearchPath(s: string): void;
      /**
      * @brief prepare
      * @param sampleRate sample rate
      * @param maxBlockSize max block size
      * @return error number
      */
      public prepare(d: number, i: number): number;
      /**
      * @brief set music dsp graph parameter
      * @param portIndex port index
      * @param parameterIndex parameter index
      * @param normalisedParameterValue normalized parameter value
      * @return success or fail
      */
      public setParameter(i: number, i0: number, f: number): boolean;
      /**
      * @brief set tempo
      * @param value tempo
      */
      public setTempo(d: number): void;
      /**
      * @brief change parameter of music-dsp node dynamically
      * @param portIndex port index
      * @param parameterIndex parameter index
      * @param normalisedParameterValue normalized parameter value
      * @return success or fail
      */
      public dynamicParameterChange(i: number, i0: number, f: number): boolean;
      public dynamicParameterChangeByName(i: number, s: string, f: number): boolean;
      /**
      * @brief emplace Midi event
      * @param portIndex port index
      * @param type eventType (144: noteOn, 128: noteOff)
      * @param channel channel
      * @param secondByte concise meaning depends on eventType
      * @param thirdByte concise meaning depends on eventType
      * @return success or fail
      */
      public emplaceMidiEvent(i: number, i0: number, i1: number, i2: number, i3: number): boolean;
      /**
      * @brief emplace Midi event
      * @param portIndex port index
      * @param type eventType (144: noteOn, 128: noteOff)
      * @param channel channel
      * @param secondByte concise meaning depends on eventType
      * @param thirdByte concise meaning depends on eventType
      * @param quantiseDurationBeats lateness of the beat
      * @param quantiseLatenessThreshold maximum accepted lateness
      * @return success or fail
      */
      public emplaceMidiEventQuantised(i: number, i0: number, i1: number, i2: number, i3: number, f: number, f4: number): boolean;
      /**
      * @brief create music-dsp subnode
      * @param processorName name of the subnode
      */
      public createSubNode(s: string, s0: string): AMGAudioMDSPSubNode;
      /**
      * @brief create subnode from file
      */
      public createSubNodeFromFilePath(s: string, s0: string): AMGAudioMDSPSubNode;
      /**
      * @brief create subnode from file uri
      */
      public createSubNodeFromFileURI(s: string, s0: string): AMGAudioMDSPSubNode;
      /**
      * @brief build graph
      */
      public build(): void;
      /**
      * @brief save node as json file
      * @param fileName name of json file
      */
      public saveToJson(s: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Audio Music DSP SubNode
    */
    class AMGAudioMDSPSubNode extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief connect music-dsp subnode
      * @param other subnode pointer to be connected
      * @param portType three types: audioType = 0 midiType = 1 parameterChangeType = 2
      * @param upstreamPortIndex the port index of the subnode we intend to extract data from
      * @param downstreamPortIndex the port index of the subnode we intend to flow data to
      * @return subnode pointer to be connected
      */
      public connect(AMGAudioMDSPSubNode: AMGAudioMDSPSubNode, i: number, i0: number, i1: number): AMGAudioMDSPSubNode;
      /**
      * @brief expose port of music-dsp node to music-dsp graph
      * @param portDirection direction can be either inputPort or outputPort of the graph
      * @param portType three types: audioType = 0 midiType = 1 parameterChangeType = 2
      * @param nodePortIndex the port of the node which we want to acess through the graph
      * @param graphPortIndex the port index used to access the data of the corresponding processor node. Must be unique for each direction/type combination
      */
      public exposePort(i: number, i0: number, i1: number, i2: number): void;
      /**
      * @brief add note to midi sequencer
      * @param beatPosition position of the note in beats
      * @param duration duration of the note in beats
      * @param pitch pitch of the note in MIDI number
      * @param normalisedVelocity velocity (volume) of the note, range 0-1
      * @param channel channel of the note
      */
      public addNote(f: number, f0: number, i: number, f1: number, i2: number): void;
      /**
      * @brief deleteNote for midi sequencer by ID
      * @param nodeID midi sequencer ID
      */
      public deleteNoteByNoteID(i: number): void;
      /**
      * @brief delete note by beat_position
      * @param beatPosition position of the note in beats
      * @param pitch pitch of the note in MIDI number
      * @param channel channel of the note
      */
      public deleteNoteByPosition(f: number, i: number, i0: number): void;
      /**
      * @brief clear all notes
      */
      public clearAllNotes(): void;
      /**
      * @brief play midi sequencer
      */
      public play(): void;
      /**
      * @brief stop midi sequencer
      */
      public stop(): void;
      /**
      * @brief set maxBeat
      * @param maxBeat max beat
      */
      public setMaxBeats(d: number): void;
      /**
      * @brief set isLooping para
      * @param isLooping whether node used as loop
      */
      public setIsLooping(b: boolean): void;
      /**
      * @brief set groove timing strength
      * @param grooveTimingStrenght groove timing strength
      */
      public setGrooveTimingStrength(f: number): void;
      /**
      * @brief set groove velocity strength
      * @param grooveVelocityStrenght groove velocity strength
      */
      public setGrooveVelocityStrength(f: number): void;
      /**
      * @brief get beat position
      * @return beat position
      */
      public getBeatPosition(): number;
      /**
      * @brief get playing status
      * @return playing status
      */
      public isPlaying(): boolean;
      /**
      * @brief get the number of loops of the current playback
      * @return number of loops of the current playback
      */
      public whichLoop(): number;
      /**
      * @brief add Midi Event
      * @return success or fail
      */
      public addMidiEvent(i: number, i0: number, d: number, d1: number, i2: number): boolean;
      /**
      * @brief delete Midi Event
      * @return success or fail
      */
      public deleteMidiEvent(i: number, i0: number, d: number, d1: number, i2: number): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGAudioMicSourceNode extends AMGAudioNode {
      constructor();
      public handle: number;
      public start(): void;
      public stop(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AMGAudioModule is a singleton of engine.
    */
    class AMGAudioModule extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief Create Audio Proxy
      * @return SharePtr<AMGAudioProxy> proxy
      */
      public createAudioProxy(config: Map): AMGAudioProxy;
      /**
      * @brief Destory Audio Proxy
      */
      public destroyAudioProxy(audioProxy: AMGAudioProxy): void;
      /**
      * @brief read midi file
      * @return midi info
      */
      public readMidi(s: string, i: number): Vector;
      public getPlaybackDeviceType(): number;
      public getPlaybackDelay(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGAudioMusicSourceNode extends AMGAudioNode {
      constructor();
      public handle: number;
      public start(): void;
      public stop(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Audio Node Base Class.
    */
    class AMGAudioNode extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief Connect other AudioNode
      */
      public connect(node: AMGAudioNode): void;
      public pin(i: number): AMGAudioNodePin;
      public pout(i: number): AMGAudioNodePout;
      /**
      * @brief setByPass Func
      */
      public setByPass(b: boolean): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGAudioNodePin extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGAudioNodePout extends AObject {
      constructor();
      public handle: number;
      public connect(pin: AMGAudioNodePin): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AMGAudioProxy is a Proxy class for AudioGraph.
    */
    class AMGAudioProxy extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief create audio graph for lua call
      */
      public createAudioGraph(): AMGAudioGraph;
      /**
      * @brief use Audio Graph.
      * @param graph audio graph
      */
      public useAudioGraph(graph: AMGAudioGraph): void;
      /**
      * @brief start for lua call
      */
      public start(): void;
      /**
      * @brief stop for lua call
      */
      public stop(): void;
      /**
      * @brief get time progress
      * @return progress, time unit second
      */
      public getTime(): number;
      /**
      * @brief get under run count
      * @return under run count
      */
      public getUnderRunCount(): number;
      public initOSCClient(host: string, port: string): void;
      public postOSCMessageF1(address: string, value: number): void;
      public postOSCMessageF2(address: string, x_value: number, y_value: number): void;
      public postOSCMessageF3(address: string, x_value: number, y_value: number, z_value: number): void;
      public postOSCMessageI1(address: string, value: number): void;
      public postOSCMessageI2(address: string, x_value: number, y_value: number): void;
      public postOSCMessageI3(address: string, x_value: number, y_value: number, z_value: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Recorder Node Proxy for AudioSDK
    */
    class AMGAudioRecorderNode extends AMGAudioNode {
      constructor();
      public handle: number;
      /**
      * @brief start offline data export
      */
      public start(): void;
      /**
      * @brief pause offline data export
      */
      public pause(): void;
      /**
      * @brief stop offline data export
      */
      public stop(): void;
      /**
      * @brief set up offline data export destination
      * @param descFile file path for writting data
      * @return success or fail
      */
      public setPath(s: string): boolean;
      /**
      * @brief get file path
      * @return file path
      */
      public getPath(): string;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AudioSourceNode Audio player
    */
    class AMGAudioSourceNode extends AMGAudioNode {
      constructor();
      public handle: number;
      /**
      * @brief set audio file path
      */
      public setSource(s: string): void;
      public setTTSSource(arg0: any): boolean;
      /**
      * @brief set loop
      */
      public setLoop(b: boolean): void;
      /**
      * @brief start the Audionode
      */
      public start(): void;
      /**
      * @brief resume the Audionode
      */
      public resume(): void;
      /**
      * @brief pause the audionode
      */
      public pause(): void;
      /**
      * @brief stop the audionode
      */
      public stop(): void;
      public getState(): number;
      public getLoopCount(): number;
      public getProgress(): number;
      public getDuration(): number;
      public setStartTime(f: number): boolean;
      public setEndTime(f: number): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum AMGBeautyMeshType {
      FACE145,
    }
    namespace AMGBeautyMeshType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AMGChar stores the position, rotation, size of a character realtimely. generally used by aniamtion script.
    */
    class AMGChar extends AObject {
      constructor();
      /**
      * < unicode of the character
      */
      public utf8code: string;
      /**
      * < initial local position relative to the center of sdftextcomp.
      */
      public initialPosition: Vector3f;
      /**
      * @brief get position
      * @return const Vector3f&
      */
      public position: Vector3f;
      /**
      * @brief get rotation
      * @return const Vector3f&
      */
      public rotate: Vector3f;
      /**
      * @brief get scale factor of the character
      * @return const Vector3f&
      */
      public scale: Vector3f;
      /**
      * < indicate which row the character in,  default is a invalid value -1
      */
      public rowth: number;
      /**
      * < indicate the serial number in row, default is a invalid value -1
      */
      public idInRow: number;
      /**
      * < width of the character
      */
      public width: number;
      /**
      * < height of the character
      */
      public height: number;
      /**
      * @brief get anchor for rotation
      * @return const Vector2f&
      */
      public anchor: Vector2f;
      /**
      * < range [0,1], 0 means the whole character use SDFText's textcolor, 1 means the whole character use SDFText's ktv color. other value means the character should be devided into two quad.
      */
      public transparentRatio: number;
      public color: ProxyVector4f;
      public handle: number;
      public getBaseline(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGClothInfo extends AObject {
      constructor();
      public radius: number;
      public mass: number;
      public stretchCompliance: number;
      public compressCompliance: number;
      public distanceDampingCoef: number;
      public bendingCompliance: number;
      public airDampingCoef: number;
      public groupBits: number;
      public maskBits: number;
      public useDensity: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGCollisionFinder extends AObject {
      constructor();
      public handle: number;
      public addBoxCollider(halfExtent: Vector3f, colliderOrigin: Vector3f, colliderOrientation: Quaternionf, localScaling: Vector3f, categoryBits: number, maskBits: number): number;
      public addBoxColliderToEntity(entity: Entity, halfExtent: Vector3f, categoryBits: number, maskBits: number): number;
      public addBoxColliderToRigidBody(amgPbdSimulator: AMGPbdSimulator, boxHalfExtent: Vector3f, attachedRigidBodyIndex: number, localScaling: Vector3f, groupBits: number, maskBits: number, arg6: boolean): number;
      public addSphereCollider(radius: number, colliderOrigin: Vector3f, colliderOrientation: Quaternionf, localScaling: Vector3f, categoryBits: number, maskBits: number): number;
      public addSphereColliderToEntity(entity: Entity, radius: number, categoryBits: number, maskBits: number): number;
      public addSphereColliderToRigidBody(amgPbdSimulator: AMGPbdSimulator, radius: number, attachedRigidBodyIndex: number, localScaling: Vector3f, groupBits: number, maskBits: number, arg6: boolean): number;
      public addCapsuleCollider(radius: number, height: number, colliderOrigin: Vector3f, colliderOrientation: Quaternionf, localScaling: Vector3f, categoryBits: number, maskBits: number): number;
      public addCapsuleColliderToEntity(entity: Entity, radius: number, height: number, categoryBits: number, maskBits: number): number;
      public addCapsuleColliderToRigidBody(amgPbdSimulator: AMGPbdSimulator, radius: number, height: number, attachedRigidBodyIndex: number, localScaling: Vector3f, groupBits: number, maskBits: number, arg7: boolean): number;
      public addCylinderCollider(halfExtent: Vector3f, colliderOrigin: Vector3f, colliderOrientation: Quaternionf, localScaling: Vector3f, categoryBits: number, maskBits: number): number;
      public addCylinderColliderToEntity(entity: Entity, halfExtent: Vector3f, categoryBits: number, maskBits: number): number;
      public addMeshColliderToEntity(entity: Entity, mesh: Mesh, categoryBits: number, maskBits: number, skin: Skin, useConvexHull: boolean, convexHullVertices: Vec3Vector): number;
      public addCylinderColliderToRigidBody(amgPbdSimulator: AMGPbdSimulator, cylinderHalfExtent: Vector3f, attachedRigidBodyIndex: number, localScaling: Vector3f, groupBits: number, maskBits: number, arg6: boolean): number;
      public addConeCollider(radius: number, height: number, colliderOrigin: Vector3f, colliderOrientation: Quaternionf, localScaling: Vector3f, categoryBits: number, maskBits: number): number;
      public addConeColliderToEntity(entity: Entity, radius: number, height: number, categoryBits: number, maskBits: number): number;
      public addConeColliderToRigidBody(amgPbdSimulator: AMGPbdSimulator, radius: number, height: number, attachedRigidBodyIndex: number, localScaling: Vector3f, groupBits: number, maskBits: number, arg7: boolean): number;
      public addDiscreteParticleCollider(radius: number, colliderOrigin: Vector3f, categoryBits: number, maskBits: number): number;
      public addDiscreteParticleColliderToEntity(entity: Entity, radius: number, categoryBits: number, maskBits: number): number;
      public addDiscreteParticleColliderToParticle(amgPbdSimulator: AMGPbdSimulator, radius: number, attachedParticleIndex: number, groupBits: number, maskBits: number): number;
      public attachColliderToRigidBody(amgPbdSimulator: AMGPbdSimulator, colliderId: number, attachedRigidBodyIndex: number, setBaseTransformFromRigidBody: boolean): boolean;
      public detachCollider(colliderId: number, disableRelativeTransformation: boolean): void;
      public getAttachedRigidBodyIndex(colliderId: number): number;
      public setColliderBaseTransform(cid: number, origin: Vector3f, orientation: Quaternionf, localScaling: Vector3f): void;
      public setColliderBaseTransformFromEntity(cid: number): void;
      public updateAllColliderBaseTransformFromEntities(): void;
      public setColliderRestitutionCoef(colliderId: number, restitutionCoef: number): void;
      public setColliderDynamicFrictionCoef(colliderId: number, dynamicFrictionCoef: number): void;
      public setColliderStaticFrictionCoef(colliderId: number, staticFrictionCoef: number): void;
      public setColliderIsTangible(colliderId: number, isTangible: boolean): void;
      public setColliderRelativeTransform(cid: number, relativePos: Vector3f, relativeRotation: Quaternionf): void;
      public disableColliderRelativeTransform(cid: number): void;
      public updateColliderTransform(cid: number): void;
      public updateTransforms(): void;
      public updateColliderAABB(cid: number): void;
      public updateAABBs(): void;
      public getAABB(cid: number): AABB;
      public removeCollider(cid: number): void;
      public doCollisionDetection(): void;
      public doCollisionDetectionSingleCollider(cid: number): void;
      public deactivateCollider(cid: number): void;
      public activateCollider(cid: number, arg1: FloatVector): void;
      public contactCount(): number;
      public getContactInfoList(contactInfoList: Vector): void;
      public rayTestClosestHit(origin: Vector3f, dir: Vector3f, maxDistance: number, collisionFilterMask: number, rayHitInfo: AMGRayHitInfo): boolean;
      public rayTestAllHits(origin: Vector3f, dir: Vector3f, maxDistance: number, collisionFilterMask: number): void;
      public rayHitCount(): number;
      public getRayHitInfoList(rayHitInfoList: Vector): void;
      public enableInterParticleCollision(): void;
      public disableInterParticleCollision(): void;
      public enableParticleRigidbodyCollision(): void;
      public disableParticleRigidbodyCollision(): void;
      public reset(): void;
      public colliderCurrentFrameContactsCount(cid: number): number;
      public getColliderCurrentFrameContactInfoList(cid: number, contactInfoList: Vector): void;
      public addColliderCollisionEventFocus(cid: number): void;
      public removeColliderCollisionEventFocus(cid: number): void;
      public updateColliderGroupBits(cid: number, groupBits: number): void;
      public updateDeformableMeshCollider(colliderId: number, mesh: Mesh, skinning: Skin): void;
      public generateConvexHull(meshVertices: Vec3Vector, vertices: Vec3Vector, edges: UInt32Vector): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGCollisionFinder2D extends AObject {
      constructor();
      public handle: number;
      public setSimulator(simulator: AMGSimulator2D): void;
      public createOrUpdateBoxCollider(colliderId: number, size: Vector2f, offset: Vector2f, rotation: number, scale: number): number;
      public createOrUpdateCircleCollider(colliderId: number, offset: Vector2f, scale: number, radius: number): number;
      public createOrUpdateEdgeCollider(colliderId: number, points: Vec2Vector, offset: Vector2f, rotation: number, scale: number): number;
      public removeCollider(colliderId: number): void;
      public attachColliderToRigidBody(colliderId: number, attachedRigidBodyId: number, categoryBits: number, maskBits: DynamicBitset): boolean;
      public setColliderRestitution(colliderId: number, restitution: number): void;
      public setColliderFriction(colliderId: number, friction: number): void;
      public setColliderIsTrigger(colliderId: number, isTrigger: boolean): void;
      public setColliderMaskBits(colliderId: number, maskBits: DynamicBitset): void;
      public setColliderCategoryBits(colliderId: number, categoryBits: number): void;
      public getRayCastHit(origin: Vector2f, direction: Vector2f, length: number, maskBits: DynamicBitset, mode: number): FloatVector;
      public setCollisionListenerEnabled(colliderId: number, enabled: boolean): void;
      public getAllCollisionHitPairs(arg0: Int32Vector, arg1: FloatVector): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief ComputeEntity wrapper for lua
    */
    class AMGComputeEntity extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief set property
      * @param prop Property will be set    *
      */
      public setProperty(property: PropertySheet): void;
      /**
      * @brief Get property
      **/
      public getProperty(): PropertySheet;
      /**
      * @brief Sets a named float value.
      * @param name The name of the property.
      * @param f Float value to set.
      */
      public setFloat(name: string, f: number): void;
      /**
      * @brief Get a named float value.
      * @param name The name of the property.
      * @return float The value of the property.
      */
      public getFloat(name: string): number;
      /**
      * @brief Sets a named vec4 value.
      * @param name The name of the property.
      * @param c Vec4 value to set.
      */
      public setVector4(name: string, c: Vector4f): void;
      /**
      * @brief Get a named vec4 value.
      * @param name The name of the property.
      * @return const Vector4f& The value of the property.
      */
      public getVector4(name: string): Vector4f;
      /**
      * @brief Sets a named matrix value.
      * @param name The name of the property.
      * @param m Matrix value to set.
      */
      public setMatrix4x4f(name: string, m: Matrix4x4f): void;
      /**
      * @brief Get a named matrix value.
      * @param name The name of the property.
      * @return const Matrix4x4f& The value of the property.
      */
      public getMatrix4x4f(name: string): Matrix4x4f;
      /**
      * @brief Sets a named texture value.
      * @param name The name of the property.
      * @param tex Texture value to set.
      */
      public setTexture(name: string, tex: Texture): void;
      /**
      * @brief Get a named texture value.
      * @param name The name of the property.
      * @return Texture* The value of the property.
      */
      public getTexture(name: string): Texture;
      public setImage(name: string, image: Texture): void;
      public getImage(name: string): Texture;
      /**
      * @brief Sets a named buffer value.
      * @param name The name of the property.
      * @param buffer Buffer value to set.
      */
      public setBuffer(name: string, tex: Buffer): void;
      /**
      * @brief Get a named buffer value.
      * @param name The name of the property.
      * @return Buffer* The value of the property.
      */
      public getBuffer(name: string): Buffer;
      /**
      * @brief Sets a named integer value.
      * @param name The name of the property.
      * @param i Integer value to set.
      */
      public setInt(name: string, tex: number): void;
      /**
      * @brief Get a named integer value.
      * @param name The name of the property.
      * @return const int& The value of the property.
      */
      public getInt(name: string): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AMGComputePipeline is a self contained command sequence which is record once,
    * but can be executed multiple times. The set of graphics command exposed to lua
    * layer enables user to add custom rendering logic in addition to existing render system.
    */
    class AMGComputePipeline extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief compile shader
      * @param variant shader source or bytecode map (key is backend)
      */
      public compile(shader: Map): boolean;
      /**
      * @brief Create new Entity
      */
      public newEntity(): AMGComputeEntity;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGContactInfo extends AObject {
      constructor();
      public normal: Vector3f;
      public colliderId0: number;
      public colliderId1: number;
      public hitPoint0: Vector3f;
      public hitPoint1: Vector3f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGFaceMeshUtils extends AObject {
      constructor();
      public handle: number;
      public setMesh(_mesh: Mesh, _type: AMGBeautyMeshType, _posAttrStart: number, _posAttrSize: number): void;
      public updateMeshWithFaceData106(_type: AMGBeautyMeshType, _basePoints: Vec2Vector, _faceIndex: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Enum of lnstener type
    */
    enum AMGListenerType {
      /**
      * the type between AlwaysInvokeListenerType and UserListenerTypeStart is reserved for system
      */
      ALWAYS_INVOKE_TYPE,
    }
    namespace AMGListenerType {
      let RTTI: RTTIDescriptor;
    }
    class AMGManualObjectRenderer extends Renderer {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGModifiedProperty extends AObject {
      constructor();
      public componentType: number;
      public componentId: number;
      public propertyType: number;
      public newValue: FloatVector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGModifiedPropertyHandler extends AObject {
      constructor();
      public handle: number;
      public updateAllModifiedProperties(amgPbdSimulator: AMGPbdSimulator, amgCollisionFinder: AMGCollisionFinder, modifiedProperties: Vector): void;
      public updateProperties(amgPbdSimulator: AMGPbdSimulator, amgCollisionFinder: AMGCollisionFinder, modifiedProperties: FloatVector): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGPbdSimulator extends AObject {
      constructor();
      public handle: number;
      public dumpRigidBodyTransform(rigidBodyCount: number, transforms: FloatVector): void;
      public setNumSubsteps(numSubSteps: number): void;
      public setNumPositionSolveIterations(numIterations: number): void;
      public enableFixedTimestepIndependentOfFramerate(): void;
      public disableFixedTimestepIndependentOfFramerate(): void;
      public enableSlowMotionMode(): void;
      public disableSlowMotionMode(): void;
      public setNumVelocitySolveIterationsForContact(numIterations: number): void;
      public setNumPositionSolveIterationsForContact(numIterations: number): void;
      public setGravityAcceleration(gravityAccel: Vector3f): void;
      public setRigidBodyInitialVelocity(bodyId: number, initialVelocity: Vector3f): void;
      public step(deltaTime: number, amgCollisionFinder: AMGCollisionFinder): void;
      public IKStep(): void;
      public addParticle(mass: number, restPos: Vector3f, initialVelocity: Vector3f, linearDampingCoef: number): number;
      public getParticlePosition(particleId: number): Vector3f;
      public addRigidBody(mass: number, inertiaTensorDiagonalAtRest: Vector3f, restPos: Vector3f, restOrientation: Quaternionf, initialVelocity: Vector3f, initialAngularVelocity: Vector3f, linearDampingCoef: number, rotationalDampingCoef: number): number;
      public addRigidBodyToEntity(mass: number, inertiaTensorDiagonalAtRest: Vector3f, entity: Entity, initialVelocity: Vector3f, initialAngularVelocity: Vector3f, linearDampingCoef: number, rotationalDampingCoef: number): number;
      public removeRigidBody(bodyId: number): void;
      public getRigidBodyPosition(bodyId: number): Vector3f;
      public getRigidBodyVelocity(bodyId: number): Vector3f;
      public getRigidBodyAngularVelocity(bodyId: number): Vector3f;
      public getRigidBodyOrientation(bodyId: number): Quaternionf;
      public setRigidBodyTransformFromEntity(bodyId: number, arg1: boolean, arg2: boolean): void;
      public fetchRigidBodyTransformFromEntity(arg0: boolean, arg1: boolean): void;
      public pushRigidBodyTransformToEntity(): void;
      public setRigidBodyRelativePosEntitySpace(bodyId: number, center: Vector3f): void;
      public removeConstraint(constraintId: number): void;
      public disableConstraint(constraintId: number): void;
      public enableConstraint(constraintId: number): void;
      public setTimestep(dt: number): void;
      public setMaxDeltaTime(val: number): void;
      public getMaxDeltaTime(): number;
      public removeStretch(): void;
      public resetRigidBodyToInitialStates(bodyId: number): void;
      public enableBodyKinematic(bodyId: number): void;
      public disableBodyKinematic(bodyId: number): void;
      public disableRigidBody(bodyId: number): void;
      public enableRigidBody(bodyId: number, parameters: FloatVector): void;
      public addDistanceJoint(objectA: number, isParticleA: boolean, globalPosA: Vector3f, objectB: number, isParticleB: boolean, globalPosB: Vector3f, distanceJointCoef: Vector3f, restLength: number): number;
      public setDistanceJointRestLength(constraintId: number, restLength: number): void;
      public setDistanceJointConnectorLocalPos(constraintId: number, localPosA: Vector3f, localPosB: Vector3f): void;
      public addFixedRelativeRotationJoint(objectA: number, objectB: number, compliance: number, dampingCoef: number, useRelativeDeltaRotation: boolean): number;
      public addHingeJoint(objectA: number, objectB: number, hingeAxis: Vector3f, angleDegMin: number, angleDegMax: number, compliance: number, dampingCoef: number, useRelativeDeltaRotation: boolean): number;
      public setHingeJointAngleLimits(constraintId: number, degreeMin: number, degreeMax: number, axis: Vector3f): void;
      public addAnisotropicSphericalJoint(objectA: number, objectB: number, degreeMin: Vector3f, degreeMax: Vector3f, compliance: number, dampingCoef: number, twistAxis: number, useRelativeDeltaRotation: boolean): number;
      public addSphericalJoint(objectA: number, objectB: number, degree: Vector3f, compliance: number, dampingCoef: number, twistAxis: number, separateTwist: boolean): number;
      public setSphericalJointAngleLimit(constraintId: number, swingDegree: number, twistDegreeMin: number, twistDegreeMax: number, twistAxis: number): void;
      public setParticlePosition(index: number, globalPos: Vector3f): void;
      public setRigidBodyPosition(index: number, globalPos: Vector3f): void;
      public setIKAngularJointPreferredAngle(constraintId: number, quat: Quaternionf): void;
      public setIKAngularJointPreferredAngleStatus(constraintId: number, val: boolean): void;
      public applyIKAngularJointPreferredAngle(constraintId: number, percantage: number): void;
      public setJointInitialRelativeDeltaRotation(constraintId: number, quat: Quaternionf): void;
      public setJointInitialRelativeDeltaRotationStatus(constraintId: number, val: boolean): void;
      public setRigidBodyRotation(index: number, globalRot: Quaternionf): void;
      public setRigidBodyVelocity(index: number, globalVelocity: Vector3f): void;
      public setRigidBodyAngularVelocity(index: number, globalAngularVelocity: Vector3f): void;
      public applyExternalForceToRigidBodyCenterOfMass(idx: number, force: Vector3f): void;
      public enableParticleKinematic(particleId: number): void;
      public disableParticleKinematic(particleId: number): void;
      public addClothActor(amgCollisionFinder: AMGCollisionFinder, trans: Transform, mesh: Mesh, clothInfo: AMGClothInfo, skin: Skin): number;
      public reinitializeClothActor(clothId: number, trans: Transform, mesh: Mesh, recalculateJoints: boolean, skin: Skin): void;
      public addWindForce(windVelocity: Vector3f, dragCoeff: number, liftCoeff: number): number;
      public bindWindWithMesh(windId: number, clothId: number): void;
      public removeWindMeshBind(windId: number, clothId: number): void;
      public updateMeshVertexPosition(clothId: number, arg1: Transform): void;
      public removeClothActor(clothId: number, amgCollisionFinder: AMGCollisionFinder): void;
      public enableClothActor(clothId: number): void;
      public disableClothActor(clothId: number): void;
      public updateInertiaTensorForAll(centers: Vec3Vector, amgCollisionFinder: AMGCollisionFinder): void;
      public updateInertiaTensor(idx: number, colliderIds: Int32Vector, centers: Vec3Vector, amgCollisionFinder: AMGCollisionFinder): void;
      public updateRigidBodyInertiaTensor(bodyId: number, dataBuffer: FloatVector, amgCollisionFinder: AMGCollisionFinder): void;
      public freezeRigidBodyTranslation(idx: number, freezingAxis: number): void;
      public unfreezeRigidBodyTranslation(idx: number, freezingAxis: number): void;
      public setJointBreakingLimit(constraintId: number, breakingLimit: number): void;
      public attachJoints(constraintIds: Int32Vector): void;
      public setJointGlobalConnector(constraintId: number, idBody: number, pos: Vector3f): void;
      public enableApplyForceOnchange(): void;
      public disableApplyForceOnchange(): void;
      public setOnlyVelocitySolveForContacts(velocityOnly: boolean): void;
      public setAutoAddBendingConstraint(autoAddBendingConstraint: boolean): void;
      public setStoreComponentIdWithBitsCopy(storeComponentIdWithBitsCopy: boolean): void;
      public resetPhysics(): void;
      public addExternalForceToCloth(clothId: number, force: Vector3f): void;
      public attachParticlesToRigidbody(clothId: number, indices: UInt32Vector, bodyId: number, isDynamic: boolean, pinConstraints: Int32Vector): void;
      public detachParticlesFromRigidbody(clothId: number, indices: UInt32Vector, pinConstraints: Int32Vector): void;
      public addLRAConstrintsToCloth(clothId: number, indices: UInt32Vector, compliance: number, scale: number): void;
      public removeLRAConstrintsFromCloth(clothId: number): void;
      public addBalloonConstraintToCloth(clothId: number, pressure: number, compliance: number): void;
      public removeBalloonConstraintFromCloth(clothId: number): void;
      public addBendingConstraintsToCloth(clothId: number, bendingCompliance: number): void;
      public removeBendingConstraintsFromCloth(clothId: number): void;
      public setClothMotionBackstopConstraints(meshId: number, orginalCloth: Mesh, skinnedCloth: Skin, maxDistanceSphereRadius: number, collisionSphereRadius: number, collisionDistance: number, compliance: number): void;
      public updatePositionsNormalsClothMotionBackstopConstraints(meshId: number, originalCloth: Mesh, skinnedCloth: Skin): void;
      public setClothMotionBackstopConstraintParameters(meshId: number, indices: UInt32Vector, maxDistanceSphereRadius: number, collisionSphereRadius: number, collisionDistance: number, compliance: number): void;
      public setRigidbodyShadowBodyId(bodyId: number, shadowBodyId: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGPhysicsMaterial extends AObject {
      constructor();
      public data: FloatVector;
      public handle: number;
      public clearDirty(): void;
      public isDirty(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGPinComponent extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGPinSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGRayHitInfo extends AObject {
      constructor();
      public colliderId: number;
      public hitPoint: Vector3f;
      public hitNormal: Vector3f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGRaycastQuery extends AObject {
      constructor();
      public origin: Vector3f;
      public direction: Vector3f;
      public target: any;
      public targetAlignment: any;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGSimulator2D extends AObject {
      constructor();
      public handle: number;
      public setWorldGravity(gravity: Vector2f): void;
      public addRigidBody(mass: number, initialPosition: Vector2f, initialRotation: number, initialVelocity: Vector2f, initialAngularVelocity: number, linearDamping: number, angularDamping: number): number;
      public addRigidBodyToEntity(mass: number, entity: Entity, initialVelocity: Vector2f, initialAngularVelocity: number, linearDamping: number, angularDamping: number): number;
      public removeRigidBody(bodyId: number): void;
      public enableRigidBody(bodyId: number): void;
      public disableRigidBody(bodyId: number): void;
      public addSpringJoint(initialActive: boolean, initialCompliance: number, initialDampingCoef: number, initialBreakingForce: number): number;
      public updateSpringJointParameters(jointId: number, compliance: number, dampingCoeff: number, breakForce: number, breakTorque: number): void;
      public enableSpringJoint(jointId: number, bodyAId: number, bodyBId: number, anchorA: Vector2f, anchorB: Vector2f, arg5: number): void;
      public addFixJoint(initialActive: boolean, initialBreakingForce: number, initialBreakingTorque: number): number;
      public updateFixJointParameters(jointId: number, breakForce: number, breakTorque: number): void;
      public enableFixJoint(jointId: number, bodyAId: number, bodyBId: number, anchorA: Vector2f, anchorB: Vector2f): void;
      public addHingeJoint(initialActive: boolean, initialLowerLimitAngle: number, initialUpperLimitAngle: number, initialBreakingForce: number, initialBreakingTorque: number): number;
      public updateHingeJointParameters(jointId: number, angleLowerLimit: number, angleUpperLimit: number, breakForce: number, breakTorque: number): void;
      public enableHingeJoint(jointId: number, bodyAId: number, bodyBId: number, anchorA: Vector2f, anchorB: Vector2f, enableLimit: boolean): void;
      public disableJoint(jointId: number): void;
      public removeJoint(jointId: number): void;
      public fetchRigidBodyTransformFromEntity(): void;
      public pushRigidBodyTransformToEntity(): void;
      public step(timeStep: number): void;
      public setRigidBodyType(bodyId: number, type: number): void;
      public setRigidBodyFixedFreedom(bodyId: number, flag: number): void;
      public setRigidBodyGravityScale(bodyId: number, scale: number): void;
      public setRigidBodyMass(bodyId: number, mass: number): void;
      public setRigidBodyPosition(bodyId: number, position: Vector2f): void;
      public setRigidBodyRotation(bodyId: number, rotation: number): void;
      public setRigidBodyVelocity(bodyId: number, velocity: Vector2f): void;
      public setRigidBodyAngularVelocity(bodyId: number, angularVelocity: number): void;
      public setRigidBodyLinearDamping(bodyId: number, linearDamping: number): void;
      public setRigidBodyAngularDamping(bodyId: number, angularDamping: number): void;
      public applyExternalForceToRigidBody(bodyId: number, force: Vector2f, point: Vector2f, applyForceToCenter: boolean): void;
      public applyExternalTorqueToRigidBody(bodyId: number, torque: number): void;
      public applyExternalLinearImpulseToRigidBody(bodyId: number, linearImpulse: Vector2f): void;
      public applyExternalAngularImpulseToRigidBody(bodyId: number, angularImpulse: number): void;
      public setPositionSolverIterations(positionIterations: number): void;
      public setVelocitySolverIterations(velocityIterations: number): void;
      public getRigidBodyMass(bodyId: number): number;
      public getRigidBodyPosition(bodyId: number): Vector2f;
      public getRigidBodyRotation(bodyId: number): number;
      public getRigidBodyVelocity(bodyId: number): Vector2f;
      public getRigidBodyAngularVelocity(bodyId: number): number;
      public resetPhysics(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AMGTransform2D extends Transform {
      constructor();
      public handle: number;
      public setAnchor(anchorTo: Vector2f, originalPixelSize: Vector2f, pixelRatio: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AObject {
      constructor();
      public name: string;
      public guid: Guid;
      public assetMgr: AssetManager;
      public serializedProperty: ScriptSerializedProperty;
      public handle: number;
      public isInstanceOf(name: string): boolean;
      public onLoadEnd(): void;
      public onDualInstanceScriptMethodCall(arg0: any, arg1: any): void;
      public getEditorFlag(): number;
      public setEditorFlag(f: number, val: boolean): void;
      public hasEditorFlag(f: number): boolean;
      public syncEditorFlag(f: number): void;
      public clone(): AObject;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARActionResult extends AlgorithmResultEvent {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARAnchorableComponent extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum ARBackendType {
      Unknown,
      Bach,
      ARKit,
      ARCore,
    }
    namespace ARBackendType {
      let RTTI: RTTIDescriptor;
    }
    class ARCameraComponent extends Component {
      constructor();
      public zNear: number;
      public zFar: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * Tells the AAR system what type of environmental texture capturing to perform
    */
    enum AREnvironmentCaptureProbeType {
      /**
      * No capturing will happen
      */
      None,
      /**
      * Capturing will be manual with the app specifying where the probes are and their size
      */
      Manual,
      /**
      * Capturing will be automatic with probes placed by the AAR system
      */
      Automatic,
    }
    namespace AREnvironmentCaptureProbeType {
      let RTTI: RTTIDescriptor;
    }
    class ARPanableComponent extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum ARPlaneDetectionMode {
      /**
      * Detect Horizontal Surfaces *
      */
      None,
      /**
      * Detects Vertical Surfaces *
      */
      HorizontalPlaneDetection,
      VerticalPlaneDetection,
      AnyPlaneDetection,
    }
    namespace ARPlaneDetectionMode {
      let RTTI: RTTIDescriptor;
    }
    class ARRendererSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARRotateableComponent extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARScaleableComponent extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum ARSceneReconstructionMode {
      /**
      * Scene reconstruction generates a mesh of the world *
      */
      None,
      /**
      * Scene reconstruction generates a mesh of the world with classification for each face. *
      */
      Mesh,
      MeshWithClassification,
    }
    namespace ARSceneReconstructionMode {
      let RTTI: RTTIDescriptor;
    }
    class ARSessionComponent extends Component {
      constructor();
      public sessionConfig: ARSessionConfig;
      public handle: number;
      public getARSessionWrapper(): ARSessionWrapper;
      public getAllTrackedGeometries(): Vector;
      public hitTest(screenCoord: Vector2f, arg1: any, camera: Camera): Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARSessionConfig extends AObject {
      constructor();
      public sessionType: ARSessionType;
      public planeDetectionMode: ARPlaneDetectionMode;
      public environmentCaptureProbe: AREnvironmentCaptureProbeType;
      public trackingFeature: ARSessionTrackingFeature;
      public sceneReconstructionMode: ARSceneReconstructionMode;
      public alwaysUpdateMesh: boolean;
      public needMeshNormal: boolean;
      public useBachAlgorithm: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARSessionSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * Tells the AAR system how much of the face work to perform
    */
    enum ARSessionTrackingFeature {
      /**
      * None of the session feature is enabled
      */
      None,
      /**
      * 2D pose detection is enabled
      */
      PoseDetection2D,
      /**
      * Person segmentation is enabled
      */
      PersonSegmentation,
      /**
      * Person segmentation with depth info is enabled
      */
      PersonSegmentationWithDepth,
      /**
      * Scene Depth
      */
      SceneDepth,
      /**
      * Smoothed Scene Depth
      */
      SmoothedSceneDepth,
    }
    namespace ARSessionTrackingFeature {
      let RTTI: RTTIDescriptor;
    }
    enum ARSessionType {
      /**
      ** AAR session used to track orientation of the device only *
      */
      None,
      /**
      * AAR session used to track orientation of the device only
      */
      Orientation,
      /**
      * AAR meant to overlay onto the world with tracking
      */
      World,
      /**
      * AAR meant to overlay onto a face
      */
      Face,
      /**
      * Tracking of images supplied by the app. No world tracking, just images
      */
      Image,
      /**
      * A session used to scan objects for object detection in a world tracking session
      */
      ObjectScanning,
      /**
      * A session used to track human pose in 3D
      */
      PoseTracking,
    }
    namespace ARSessionType {
      let RTTI: RTTIDescriptor;
    }
    class ARSessionWrapper extends AObject {
      constructor();
      public handle: number;
      public getAllTrackedGeometries(): Vector;
      public getTrackingQuality(): void;
      public getSessionStatus(): void;
      public getTrackingQualityReson(): void;
      public isAvaliable(): boolean;
      public addAnchor(arg0: ARTrackedAnchor): void;
      public removeAnchor(arg0: ARTrackedAnchor): void;
      public removeAnchorWithGUID(arg0: string): void;
      public raycast(arg0: AMGRaycastQuery): Vector;
      public getDepthRegionConfidence(arg0: number, arg1: number, arg2: number, arg3: number): number;
      public getRawDepthTexture(arg0: boolean): Texture;
      public getRawDepthConfidenceTexture(): Texture;
      public getBackendType(): ARBackendType;
      public setAvatarAlgorithm(algorithmName: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARTappableComponent extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARTrackedAnchor extends AObject {
      constructor();
      public anchorType: AnchorType;
      public handle: number;
      public getMesh(): Mesh;
      public getTransform(): Matrix4x4f;
      public getAnchorGuid(): string;
      public setTransform(arg0: Matrix4x4f): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARTrackedAnchorInfo extends AObject {
      constructor();
      public anchors: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARTrackedEnvironmentProbeAnchor extends ARTrackedAnchor {
      constructor();
      public handle: number;
      public getEnvironmentTex(): Texture;
      public setTexUpdateMinTimeInterval(arg0: number): void;
      public updateEnvTexToMaterial(arg0: Material, arg1: string): void;
      public setExtent(arg0: Vector3f): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARTrackedFaceAnchor extends ARTrackedAnchor {
      constructor();
      public handle: number;
      public getLeftEyeTransform(): Matrix4x4f;
      public getRightEyeTransform(): Matrix4x4f;
      public getLookAt(): Vector3f;
      public getBlendShapes(): Map;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARTrackedMeshAnchor extends ARTrackedAnchor {
      constructor();
      public handle: number;
      public getClassificationHistogram(): FloatVector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARTrackedPlaneAnchor extends ARTrackedAnchor {
      constructor();
      public handle: number;
      public getCenter(): Vector3f;
      public getExtent(): Vector3f;
      public getAlignment(): void;
      public getNormal(): Vector3f;
      public getPlaneClassification(): void;
      public getPlaneClassificationStatus(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ARTrackedPointAnchor extends ARTrackedAnchor {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief The Unit of AR World
    */
    enum ARUnit {
      METER,
      CENTI_METER,
    }
    namespace ARUnit {
      let RTTI: RTTIDescriptor;
    }
    class AbstractAsset extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AccelerationSensorAgent extends SensorAgent {
      constructor();
      public handle: number;
      public getData(): Vector3f;
      public isValidData(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ActionCallResult extends AObject {
      constructor();
      public eventType: BEFEventType;
      public actionType: string;
      public entityName: string;
      public animClipName: string;
      public action: string;
      public isLoop: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ActionController extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ActionManipulator extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine Affector Base Class
    */
    class Affector extends AObject {
      constructor();
      /**
      * @brief Getter
      * @return const Vector3f&: position
      */
      public postion: Vector3f;
      /**
      * @brief Getter
      * @return const Quaternionf&: rotation
      */
      public rotation: Quaternionf;
      /**
      * @brief Getter
      * @return bool isEnabled
      */
      public enabled: boolean;
      public updateMode: ParticleUpdateMode;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine ColiisionType
    * 1. NONE
    * 2. BOUNCE
    * 3. FLOW
    */
    enum AffectorCollisionType {
      NONE,
      BOUNCE,
      FLOW,
      STOP,
    }
    namespace AffectorCollisionType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine Affector Force Operation
    * 1. AVERAGE:
    * 2. ADD:
    */
    enum AffectorForceApplication {
      AVERAGE,
      ADD,
    }
    namespace AffectorForceApplication {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine Affector IntersectionType
    * 1 POINT
    * 2 BOX
    */
    enum AffectorIntersectionType {
      POINT,
      BOX,
    }
    namespace AffectorIntersectionType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine ScaleAffectorType
    * LINEAR
    * RATIO
    */
    enum AffectorScaleType {
      LINEAR,
      RATIO,
    }
    namespace AffectorScaleType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine TextureAnimation Move Type
    */
    enum AffectorTextureAnimationType {
      LOOP,
      UPDOWN,
      RANDOM,
      STOP,
    }
    namespace AffectorTextureAnimationType {
      let RTTI: RTTIDescriptor;
    }
    class AlgorithmAsset extends AObject {
      constructor();
      public algoKey: string;
      public scriptPath: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AlgorithmResultEvent extends AObject {
      constructor();
      public eventType: BEFEventType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AlignAffector extends Affector {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AmazingEffectSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AmazingFaceMakeupLuaObject extends AObject {
      constructor();
      public handle: number;
      public getScene(): Scene;
      public setIntensity(intensity: number): number;
      public setIntensityWithName(name: string, intensity: number): void;
      public setActiveIntensity(name: string, intensity: number, isBuildin: boolean): void;
      public setIntensityOpacity(name: string, opacity: FloatVector): void;
      public setHideWhenPlayEnd(name: string, hide: boolean): boolean;
      public playClip(name: string, loopCount: number): boolean;
      public playClipFromTo(name: string, startIndex: number, endIndex: number, loopCount: number, reverse: boolean): boolean;
      public play(name: string): boolean;
      public pause(name: string): boolean;
      public seek(name: string, frameCnt: number, resourceType: number): boolean;
      public show(name: string): boolean;
      public hide(name: string): boolean;
      public isInit(name: string): boolean;
      public setUniform(name: string, uniformName: string, val: number): boolean;
      public setOptimize(flag: boolean): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AmazingSceneScriptManager extends AObject {
      constructor();
      public supportRendererType: any;
      public handle: number;
      public onUpdateAllScenesSystem(systemStr: string, frameTime: number): void;
      public onUpdateSceneSystem(scene: Scene, systemStr: string, frameTime: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AmazingViewer extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AnalyticsManager extends AObject {
      constructor();
      public handle: number;
      public reportEvent(eventName: string, data: Map): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum AnchorType {
      None,
      Plane,
      Face,
      EnvionmentProbe,
      Mesh,
      Point,
      Camera,
    }
    namespace AnchorType {
      let RTTI: RTTIDescriptor;
    }
    class AngleBinaryProgram extends AObject {
      constructor();
      public "32sourcePath": string;
      public "64sourcePath": string;
      public source: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief animation layer
    */
    class AnimLayer extends AObject {
      constructor();
      public states: Vector;
      public layerType: LayerType;
      public blendWeight: number;
      public autoPlay: boolean;
      public layerMask: AnimLayerMask;
      public defaultStartState: AnimState;
      public currentState: AnimState;
      public handle: number;
      /**
      * @brief create an animation state by name
      * @param name name
      * @param isTemporary whether this is a temporary stated created when play/schedule a clip
      * @return SharePtr<AnimState> state
      */
      public createAnimationState(name: string, isTemporary: boolean): AnimState;
      /**
      * @brief get an animation state by name
      * @param name name
      * @return SharePtr<AnimState> state
      */
      public getAnimationState(name: string): AnimState;
      /**
      * @brief play a state exclusively in the layer
      * @param state an animation state
      * @param fadeTime blend weight fade duration, if is 0, do transition immediately
      * @param createTransition whether to play this state mandatorily.
      * If set to false, the state will not be played if there is no no predefined transition rule between current state and new state
      * If set to true, the state will be force played even if there is no existing transition rule
      */
      public play(state: AnimState, fadeTime: number, createTransition: boolean): void;
      public removeState(state: AnimState): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief animation layer
    */
    class AnimLayerMask extends AObject {
      constructor();
      public entities: Map;
      public maskbits: DynamicBitset;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief frame sequence animation class
    */
    class AnimSeq extends AObject {
      constructor();
      /**
      * @brief get resource type, deprecated since 10.27.0
      * @return AMGSeqAssetType resource type
      */
      public assettype: SeqAssetType;
      /**
      * @brief get relative path of resource file
      * @return const std::string& relative path of resource file
      */
      public assetfilename: string;
      /**
      * @brief get playing fps
      * @return int32_t FPS
      */
      public fps: number;
      /**
      * @brief get lazyloading flag
      * @return bool lazyloading flag
      */
      public lazyload: boolean;
      /**
      * @brief get frame caching flag
      * @return bool caching flag
      */
      public cache: boolean;
      /**
      * @brief get image atlaes
      * @return const Vector& image atlaes
      */
      public atlases: Vector;
      /**
      * @brief set memory size limit of textures
      * @param texSizeLimit memory size limit
      */
      public memoryLimit: number;
      /**
      * @brief get preloading flag
      * @return bool preloading flag
      */
      public preload: boolean;
      /**
      * @brief get <int,string> index&action relationShip
      * @return const Map& The map store relationShip about index and action
      */
      public indexAction: Map;
      /**
      * @brief get async preload count
      * @return preload count
      */
      public preloadCount: number;
      public handle: number;
      /**
      * @brief get total frame count
      * @return int32_t frame count
      */
      public getFrameCount(): number;
      public onLoadEnd(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief sequence animation component
    */
    class AnimSeqComponent extends Component {
      constructor();
      /**
      * @brief get sequence animation
      * @return const SharePtr<AnimSeq>& sequence animation
      */
      public animSeq: AnimSeq;
      /**
      * @brief get uniform name of texture Sampler(use "_MainTex" now)
      * @return const std::string& uniform name
      */
      public texName: string;
      /**
      * @brief get frame name
      * @return const std::string& frame name
      */
      public frameName: string;
      public frameRotateName: string;
      public frameInnerName: string;
      /**
      * @brief get play mode
      * @return AMGPlayMode play mode
      */
      public playmode: PlayMode;
      /**
      * @brief get loop count: only works under LOOP mode - minus means infinite loop, float means playing time will be calculated
      * @return float loop count
      */
      public loopCount: number;
      /**
      * @brief get play speed
      * @return float speed
      */
      public speed: number;
      /**
      * @brief is auto play
      * @return bool auto play
      */
      public autoplay: boolean;
      /**
      * @brief get frame index.
      * @return int32_t frame index.
      */
      public frameIndex: number;
      /**
      * @brief get <string,animseq> name&animseq relationShip
      * @return const Map& The map store relationShip about name and animseq
      */
      public animSeqMap: Map;
      public handle: number;
      /**
      * @brief play
      */
      public play(): void;
      /**
      * @brief pause
      */
      public pause(): void;
      /**
      * @brief stop,animation will be reset to first frame
      */
      public stop(): void;
      /**
      * @brief seek to frame
      * @param index index
      */
      public seek(index: number): void;
      /**
      * @brief seek to time
      * @param localTime tiem stamp
      */
      public seekToTime(localTime: number): void;
      /**
      * @brief reset animation to first frame
      */
      public resetAnim(): void;
      /**
      * @brief switch anim sequence.
      * @param key key name.
      */
      public switchAnimseq(key: string): void;
      /**
      * @brief play Animseq From start To end. set play mode, loop count and the visibility of the entity
      * @param startIdx start Idx.
      * @param endIdx end Idx.
      * @param playMode playMode: ONCE, LOOP, PINGPONG, RANDOM
      * @param playCount play count for LOOP and PINGPONG mode
      * @param isVisible  visibility of the entity when play ended.
      */
      public playFromTo(startIndex: number, endIndex: number, playMode: PlayMode, playCount: number, isVisible: boolean): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Anim sequence event type.
    */
    enum AnimSeqEventType {
      /**
      * start play of one loop
      */
      ANIMSEQ_START,
      /**
      * end of one loop
      */
      ANIMSEQ_END,
      ANIMSEQ_ACTIONINDEX,
      /**
      * start to play the whole animseq
      */
      ANIMSEQ_WHOLE_START,
      /**
      * end of playing the whole animseq
      */
      ANIMSEQ_WHOLE_END,
    }
    namespace AnimSeqEventType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Anim sequence key info
    */
    class AnimSeqKeyInfo extends AObject {
      constructor();
      /**
      * @brief anim sequence event type
      */
      public type: AnimSeqEventType;
      /**
      * @brief anim sequence component
      */
      public animSeqCom: AnimSeqComponent;
      /**
      * < key index
      */
      public keyIndex: number;
      /**
      * < key name
      */
      public keyName: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AnimSeqSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AnimSequenceEventInfo extends AObject {
      constructor();
      public eventType: AnimSequenceEventType;
      public frameIndex: number;
      public eventName: string;
      public animSeq: AObject;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum AnimSequenceEventType {
      ANIMSEQ_PLAY_BEGIN,
      ANIMSEQ_PLAY_END,
      ANIMSEQ_LOOP_BEGIN,
      ANIMSEQ_LOOP_END,
      ANIMSEQ_KEY_FRAME,
      ANIMSEQ_PAUSE,
      ANIMSEQ_RESUME,
    }
    namespace AnimSequenceEventType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief animation state
    */
    class AnimState extends AObject {
      constructor();
      /**
      * @brief the animazClip construction infos of this state, excluding those created in script at runtime
      */
      public animazClips: Vector;
      /**
      * @brief the externalClips of this state, excluding those created in script at runtime
      */
      public externalClips: Vector;
      /**
      * @brief state play back speed
      */
      public speed: number;
      /**
      * @brief state startTime in sec
      */
      public startTime: number;
      /**
      * @brief state wrap mode
      * if > 0: repeat time
      * if == 0: LOOP
      * if == -1(PINGPONG): PINGPONG
      * if == -2(CLAMP_FOREVER): play once and repeat last frame
      * if == -3(SEEK): seek to a frame and play the frame
      * if == -10(USE_CLIP_WRAPMODES): use different wrapmodes for clips in this state
      */
      public wrapMode: number;
      /**
      * @brief whether the clips will override each other when blending in the state
      */
      public overrideBlend: boolean;
      /**
      * @brief whether the state will restore to original value when state end
      */
      public isRestoreOrigVal: boolean;
      /**
      * @brief state blending weight
      */
      public blendWeight: number;
      /**
      * @brief the clips of this state, including animaz clip and external clip
      */
      public clips: Vector;
      public animationLayer: AnimLayer;
      public handle: number;
      /**
      * @brief play the state
      */
      public playState(): void;
      /**
      * @brief add an external clip for the state
      * @param clipName clip name
      * @param initialBlendWeight the clip's default blendweight in the state
      */
      public addExternalClip(clipName: string, initialBlendWeight: number): boolean;
      /**
      * @brief add an animaz clip for the state
      * @param clipName clip name
      * @param animaz the animaz resource of this clip
      * @param startTime start time
      * @param endTime end time
      * @param wrapMode wrap mode
      * @param initialBlendWeight the clip's default blendweight in the state
      */
      public addAnimazClip(clipName: string, animaz: Animaz, startTime: number, endTime: number, wrapMode: number, initialBlendWeight: number): boolean;
      /**
      * @brief get an animation transtiron
      * @return AnimStateTransition
      */
      public getStateTransition(dstState: AnimState): AnimStateTransition;
      /**
      * @brief create an animation transtiron
      * @return AnimStateTransition
      */
      public createStateTransition(dstState: AnimState, isTemporary: boolean): AnimStateTransition;
      /**
      * @brief set clip weight
      * @param clipId clip id
      * @param blendWeight blendWeight of the clip
      */
      public setClipWeight(clipIndex: number, blendWeight: number): void;
      /**
      * @brief set clip weight
      * @param clipWeights key: clipid, value: clip weights
      */
      public setClipWeights(clipWeights: FloatVector): void;
      /**
      * @brief get time elapsed since playing
      * @return float time
      */
      public getElapsedTime(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief animation state Transiton, for state crossfading
    */
    class AnimStateTransition extends AObject {
      constructor();
      public transitionType: StateTransitionType;
      public duration: number;
      public dstState: AnimState;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum AnimSysEventType {
      ANIMSYS_START,
      ANIMSYS_END,
    }
    namespace AnimSysEventType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief timeline type of animation, GAMETIME use game time, do not count in time when game is stoped, SYSTEMTIME count in time when game is stopped
    */
    enum AnimTimeType {
      GAMETIME,
      SYSTEMTIME,
      AMAZER_INPUT_TIME,
    }
    namespace AnimTimeType {
      let RTTI: RTTIDescriptor;
    }
    class AnimatedMesh extends Mesh {
      constructor();
      public readMask: number;
      public vertexDataList: Vector;
      public uvDataList: Vector;
      public colorDataList: Vector;
      public indexDataList: Vector;
      public normalDataList: Vector;
      public bboxes: Vector;
      public frameIndex: number;
      public handle: number;
      public estimateMemoryFootprint(): number;
      public refreshData(): void;
      public calcIsRefreshing(): boolean;
      public initMesh(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum AnimatedMeshReadMask {
      NONE,
      VERTEX,
      UV,
      COLOR,
      NORMAL,
    }
    namespace AnimatedMeshReadMask {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Animator component
    */
    class Animator extends Component {
      constructor();
      /**
      * @brief Get Animation Resource of this animator, vector animations consists of Animazes, where AnimazClips are instantiated from
      * @return const Vector& Animation Resourc
      */
      public animations: Vector;
      /**
      * @brief Get auto playing list (Deprecated! Use AnimLayers' autoPlay & defaultStartState for animation auto play)
      * @return const Vector auto playing list
      */
      public runningClips: Vector;
      /**
      * @brief Get auto playing list && play mode(Deprecated! Use AnimLayers'  autoPlay & defaultStartState for animation auto play)
      * @return const Map playing list && play mode
      */
      public runningWrapModes: Map;
      /**
      * @brief set animator culling mode
      * @param cullingMode culling mode
      */
      public cullingMode: AnimatorCullingMode;
      /**
      * @brief Get layers
      * @return const Vector layer name & layer
      */
      public layers: Vector;
      /**
      * @brief Get layers
      * @return const Map layer name & layer
      */
      public layerMasks: Vector;
      public handle: number;
      /**
      * @brief Deprecated. play animation exclusively in default layer, use playState instead
      * @param clipName clip's name
      * @param wrapMode loopCount or wrap mode, described in AnimationClip
      * @param speed play speed
      * @param fadeTime blend weight fade duration, if is 0, do transition immediately
      * @param startTime start time normalized, negative number means just continue
      */
      public play(clipName: string, wrapMode: number, speed: number, fadeInTime: number, startTime: number): void;
      /**
      * @brief play state exclusively in its layer
      * @param layerIndex layer's index in the animator
      * @param stateIndex state's index in its layer
      * @param fadeTime blend weight fade duration, if is 0, do transition immediately
      * @param startTime start time normalized, negative number means just continue
      */
      public playState(layerIndex: number, stateIndex: number, fadeTime: number): void;
      /**
      * @brief stopAllAnimations
      */
      public stopAllAnimations(): void;
      /**
      * @brief Deprecated. Schedule an animation clip to play, use playState instead
      * @param clip clip
      * @param wrapMode play mode
      * @param speed play speed
      */
      public schedule(clip: AnimazClip, wrapMode: number, speed: number): void;
      /**
      * @brief Unschedule an animation clip
      * @param clip clip
      */
      public unschedule(clip: AnimazClip): void;
      /**
      * @brief pause
      */
      public pauseAnimator(): void;
      /**
      * @brief resume
      */
      public resumeAnimator(): void;
      /**
      * @brief Create an plain animation resource
      * @param name name
      * @return SharePtr<Animaz> animation resource created
      */
      public createAnimation(name: string): Animaz;
      /**
      * @brief get animation resource by name
      * @param name name
      * @return SharePtr<Animaz> animation resource
      */
      public getAnimation(name: string): Animaz;
      /**
      * @brief delete animation resource by name
      * @param animationName name
      * @return bool is succeed
      */
      public removeAnimation(animationName: string): boolean;
      /**
      * @brief get an animation layer by index
      * @return SharePtr<AnimLayer> layer layer
      */
      public getAnimationLayer(layerIndex: number): AnimLayer;
      /**
      * @brief get or create an animation layer by name
      * @param name name
      * @return SharePtr<AnimLayer> layer
      */
      public getOrCreateAnimationLayer(name: string): AnimLayer;
      /**
      * @brief remove an animation layer by name
      * @param name name
      */
      public removeAnimationLayer(name: string): boolean;
      /**
      * @brief get a clip by its name
      * @param name name
      * @return SharePtr<BaseClip> BaseClip
      */
      public getClipByName(name: string): BaseClip;
      public removeAnimazClip(name: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Animator culling mode
    */
    enum AnimatorCullingMode {
      ALWAYS_ANIMATE,
      CULL_UPDATE_PROPERTY,
      CULL_COMPLETELY,
    }
    namespace AnimatorCullingMode {
      let RTTI: RTTIDescriptor;
    }
    class AnimatorSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief animation resource, Animaz is composed of AnimazTracks
    * if you want to run an animation you can create runtime instance AniamzClip from Animaz, you can get a default AnimazClip, which plays from start to end, or you can create your own instance
    */
    class Animaz extends AObject {
      constructor();
      /**
      * @brief set total duration
      * @param duration duration
      */
      public duration: number;
      /**
      * @brief set start time
      * @param startTime start time
      */
      public startTime: number;
      /**
      * @brief set end time
      * @param endTime end time
      */
      public endTime: number;
      /**
      * @brief get tracks
      * @return const Vector& tracks
      */
      public tracks: Vector;
      /**
      * @brief set timeline type
      * @param timeType timeline type
      */
      public timeType: AnimTimeType;
      public handle: number;
      /**
      * @brief get track by name, return nullptr if there is no result
      * @param name name
      * @return AnimazTrack* track
      */
      public getTrack(name: string): AnimazTrack;
      /**
      * @brief search clip by name and Animator, if there is a result, return this clip; else create a new AniamzClip and return this clip; Return default clip if name is ""
      * @param clipId name
      * @param begin start time
      * @param end end time
      * @param animator  The Animator to play on. If null, do not specify the animator
      * @return AnimazClip* clip
      */
      public getOrCreateClip(id: string, begin: number, end: number, animator: Animator): AnimazClip;
      /**
      * @brief search clip by name and Animator;  Return default clip if name is ""
      * @param clipId name
      * @param animator  The Animator to play on. If null, do not specify the animator
      * @return AnimazClip* clip
      */
      public getClip(id: string, animator: Animator): AnimazClip;
      /**
      * @brief  Play the AnimazClip with the specified name and animator
      * @param clipId The ID of the AnimazClip to play. If "", play the default clip.
      * @param animator  The Animator to play on. If null, do not specify the animator
      * @param wrapMode playMode
      * @param speed speed
      */
      public playClipByName(clipId: string, animator: Animator, wrapMode: number, speed: number): void;
      /**
      * @brief Pause the AnimazClip with the specified name and animator
      * @param clipId The ID of the AnimazClip to pause. If "", pause the default clip.
      * @param animator  The Animator to specified. If null, do not specify the animator
      */
      public pauseClipByName(clipId: string, animator: Animator): void;
      /**
      * @brief Stop the AnimazClip with the specified name and animator
      * @param clipId The ID of the AnimazClip to stop. If "", stop the default clip.
      * @param animator  The Animator specified. If null, do not specify the animator
      */
      public stopClipByName(clipId: string, animator: Animator): void;
      public removeAnimazClip(name: string, animator: Animator): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief running instance of Animaz resource
    */
    class AnimazClip extends BaseClip {
      constructor();
      public handle: number;
      /**
      * @brief get start time
      * @return float start time
      */
      public getStartTime(): number;
      /**
      * @brief get end time
      * @return float end time
      */
      public getEndTime(): number;
      /**
      * @brief get time elapsed since playing
      * @return float time
      */
      public getElapsedTime(): number;
      /**
      * @brief set wrap mode of clip
      * @param wrapMode wrapmode
      * if > 0: repeat time
      * if == 0: LOOP
      * if == -1(PINGPONG): PINGPONG
      * if == -2(CLAMP_FOREVER): play once and repeat last frame
      * if == -3(SEEK): seek to a frame and play the frame
      */
      public setWrapMode(wrapMode: number): void;
      /**
      * @brief get wrap mode of clip
      * @return float wrap mode
      */
      public getWrapMode(): number;
      /**
      * @brief set speed
      * @param speed speed, minus means play backward
      */
      public setSpeed(speed: number): void;
      /**
      * @brief get speed
      * @return float speed
      */
      public getSpeed(): number;
      /**
      * @brief is clip playing
      * @return bool is playing
      */
      public isPlaying(): boolean;
      /**
      * @brief play, restart if clip is playing
      */
      public play(): void;
      /**
      * @brief stop, will unschedule this clip if is not playing in next frame
      */
      public stop(): void;
      /**
      * @brief pause
      */
      public pause(): void;
      /**
      * @brief seek to time
      * @param seekTime seek time
      */
      public seek(seekTime: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief clip info
    */
    class AnimazClipInfo extends AObject {
      constructor();
      public clipName: string;
      public animation: Animaz;
      public startTime: number;
      public endTime: number;
      public initialBlendWeight: number;
      public wrapMode: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief animation event type
    */
    enum AnimazEventType {
      ANIM_START,
      ANIM_END,
      ANIM_RESUME,
      ANIM_PAUSE,
      ANIM_TIME,
      STATE_START,
      STATE_END,
    }
    namespace AnimazEventType {
      let RTTI: RTTIDescriptor;
    }
    class AnimazPlayerComponent extends Component {
      constructor();
      public animaz: Animaz;
      public loop: boolean;
      public animazTimeOffset: number;
      public clampAnimazTime: boolean;
      public handle: number;
      public peekAnimazTrackStatusWithDeltaTime(name: string, deltaTime: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Animaz track. each track controls changing of one property. Track is commposed of key frames
    */
    class AnimazTrack extends AObject {
      constructor();
      /**
      * @brief get key frame count
      * @return const uint32_t key frame count
      */
      public keyCount: number;
      /**
      * @brief get key frame times
      * @return const FloatVector& key frame times
      */
      public keyTimes: FloatVector;
      /**
      * @brief get key frame values
      * @return const FloatVector& key frame values
      */
      public keyValues: FloatVector;
      /**
      * @brief get control coefficients in(BEZIER interpolation) / differential coefficients in (HERMITE interpolation)
      * @return const FloatVector& control coefficients/differential coefficients
      */
      public keyInValues: FloatVector;
      /**
      * @brief get control coefficients out(BEZIER interpolation) / differential coefficients out (HERMITE interpolation)
      * @return const FloatVector& control coefficients/differential coefficients
      */
      public keyOutValues: FloatVector;
      /**
      * @brief get interpolation type between two key frames
      * @return const AMGInterpolationType interpolation type
      */
      public interpolationType: InterpolationType;
      /**
      * @brief get data type on track
      * @return const AMGTrackDataType data type on track
      */
      public trackDataType: TrackDataType;
      /**
      * @brief set target entity name(enity must be entiy where Animator at, or it's children, empty means entiy where Animator at)
      * @param targetName target entity name
      */
      public targetName: string;
      /**
      * @brief set target property name
      * @param propertyName target property name
      */
      public propertyName: string;
      /**
      * @brief set weak reference to Animaz
      * @param animation weak reference to Animaz
      */
      public animation: Animaz;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum AppEventType {
      RECORD,
      CAPTURE,
      COMPAT_BEF,
      SetFilter,
      SwitchFilter,
      SetFilterEnabled,
      SetEffectIntensity,
      SetTextEditorContent,
      TipsCommand,
      SetUniform,
      Memefit,
      MODULE,
      INTERACTIVE_VIEW_MESSAGE,
      INTERACTIVE_VIEW_SET_TEXTURE,
      INTERACTIVE_VIEW_SET_JSON,
      IMAGE_CAPTURE,
      READY_FOR_RC_VALUE_CHANGE,
      MESSAGE_POST,
    }
    namespace AppEventType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief app info
    *
    */
    class AppInfo extends AObject {
      constructor();
      /**
      * @brief whether male makeup is enabled
      *
      */
      public maleMakeupEnabled: boolean;
      /**
      * @brief faceu
      * Take pictures:"capture"
      * Record:"record"
      * Album import:"album"
      * Video chat:"voip"
      * Preview:"preview"
      */
      public clientState: string;
      public handle: number;
      public getSkipRecording(): boolean;
      public setSkipRecording(value: boolean): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AreaLight extends Light {
      constructor();
      public attenuationRange: number;
      public lightUnit: LightUnit;
      public shape: AreaShape;
      public twoSide: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum AreaShape {
      Rect,
      Circle,
    }
    namespace AreaShape {
      let RTTI: RTTIDescriptor;
    }
    class ArtTextAsset extends AObject {
      constructor();
      public resPath: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AssetDataBase extends AObject {
      constructor();
      public handle: number;
      public unmapObjectToFile(assetManager: AssetManager, object: AObject): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AssetImporter extends AObject {
      constructor();
      public platformSettings: Map;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AssetManager, load file to object, one scene - one asset manager
    */
    class AssetManager extends AObject {
      constructor();
      /**
      * @brief get root directory path
      * @return const std::string& root directory path
      */
      public rootDir: string;
      public translationDir: string;
      public handle: number;
      /**
      * @brief function wrap for the previous function to avoid template in method bind
      */
      public SyncLoad(uri: string): AObject;
      public SyncLoadWithMeta(uri: string, meta: Meta): AObject;
      public getAllScriptCustomAssets(): Map;
      public getAllCustomAssetsProperty(): Map;
      public setCustomAssetsProperty(uuid: string, propertyKey: string, arg2: any): void;
      public getCustomAssetsPreloadProperty(uuid: string, propertyKey: string): AObject;
      public setRootDir(dir: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum AssetPlatform {
      default,
      windows,
      android,
      ios,
      mac,
      linux,
      web,
    }
    namespace AssetPlatform {
      let RTTI: RTTIDescriptor;
    }
    class AssetPlatformSetting extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AssetRedirectData extends AObject {
      constructor();
      public redirectMap: Map;
      public handle: number;
      public setRedirectKey(arg0: string, arg1: string): void;
      public getRedirect(arg0: string): string;
      public removeRedirectKey(arg0: string): void;
      public isEmpty(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AssetsMap extends AObject {
      constructor();
      public assetsMap: Map;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Handle class for async loading
    */
    class AsyncLoadHandle extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief Get loaded object, or wait until object is loaded
      */
      public getObject(): AObject;
      /**
      * @brief Get loading state
      */
      public getState(): AsyncLoadState;
      /**
      * @brief Cancel handle
      */
      public cancelHandle(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief State for async loading
    */
    enum AsyncLoadState {
      /**
      * Pending
      */
      PENDING,
      /**
      * Loading
      */
      LOADING,
      /**
      * Loaded success
      */
      LOAD_SUCCESS,
      /**
      * Loaded fail
      */
      LOAD_FAIL,
      /**
      * canceled
      */
      CANCELED,
    }
    namespace AsyncLoadState {
      let RTTI: RTTIDescriptor;
    }
    enum AttachmentTarget {}
    namespace AttachmentTarget {
      let RTTI: RTTIDescriptor;
    }
    class AttributeMap extends AObject {
      constructor();
      public index: number;
      public count: number;
      public uniformName: string;
      public attributeType: VertexAttribType;
      public isDynamic: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Audio Component of Amazing Engine.
    */
    class Audio extends Component {
      constructor();
      /**
      * @brief Get audio clip from component.
      * @return AudioClip* The audio clip.
      */
      public clip: AudioClip;
      /**
      * @brief Play audio when scene ready.
      */
      public playOnAwake: boolean;
      /**
      * @brief Whether play mode is loop.
      */
      public loop: boolean;
      public handle: number;
      /**
      * @brief Play audio.
      */
      public play(): void;
      /**
      * @brief Pause audio playing.
      */
      public pause(): void;
      /**
      * @brief Resume audio pasued.
      */
      public resume(): void;
      /**
      * @brief Reset audio.
      */
      public reset(): void;
      /**
      * @brief Stop audio.
      */
      public stop(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Audio clip of resource.
    */
    class AudioClip extends AObject {
      constructor();
      /**
      * @brief Set audio uri.
      * @param uri the uri of audio.
      */
      public source: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Audio Extractor Result
    */
    class AudioExtractorResult extends AObject {
      constructor();
      /**
      * @brief include the value about Extractor Result.
      */
      public featureList: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Feature for Audio Extractor result.
    */
    class AudioFeature extends AObject {
      constructor();
      /**
      * @brief time about current feature
      */
      public time: number;
      /**
      * @brief duration about current feature
      */
      public duration: number;
      /**
      * @brief values about current feature
      */
      public values: Vector;
      public result: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Audio Midi Node
    */
    class AudioMidiNode extends AObject {
      constructor();
      /**
      * @brief note appear time
      */
      public time: number;
      /**
      * @brief note duration
      */
      public duration: number;
      /**
      * @brief note pitch
      */
      public pitch: number;
      /**
      * @brief note velocity
      */
      public velocity: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AudioParameterDescriptor extends AObject {
      constructor();
      public range: Vector2f;
      public description: string;
      public unit: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class AudioSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class BEFEffectNode extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum BEFEventCode {
      BEC_TOUCH_BEGAN,
      /**
      * deprecated
      */
      BEC_TOUCH_MOVED,
      BEC_TOUCH_ENDED,
      BEC_TOUCH_CANCELLED,
    }
    namespace BEFEventCode {
      let RTTI: RTTIDescriptor;
    }
    enum BEFEventType {
      /**
      * LuaBase Event:
      */
      BET_BASE,
      /**
      * LuaBase Event:
      */
      BET_BASE_HAND_INFO,
      /**
      * LuaBase Event:
      */
      BET_BASE_HAND_GESTURE,
      /**
      * LuaBase Event:
      */
      BET_BASE_FACE_DETECT,
      /**
      * LuaBase Event:
      */
      BET_BASE_FACE_ATTRIBUTE,
      /**
      * LuaBase Event:
      */
      BET_EFFECT,
      /**
      * LuaBase Event:
      */
      BET_FEATURE,
      /**
      * LuaBase Event:
      */
      BET_USER,
      /**
      * LuaBase Event:
      */
      BET_ANIMATION,
      /**
      * LuaBase Event:
      */
      BET_TIMER,
      /**
      * LuaBase Event:
      */
      BET_POINT2DTRANS,
      /**
      * LuaBase Event:
      */
      BET_ACTION_DETECT,
      /**
      * LuaBase Event:
      */
      BET_TOUCH,
      /**
      * LuaBase Event:
      */
      BET_COMPOSER,
      BET_COMPOSER_GLOBAL,
      BET_EXCLUSIVE,
      BET_EXCLUSIVE_GLOBAL,
      /**
      * LuaBase Event:
      */
      BET_RECORD_VIDEO,
      BET_CAMERA_SWITCHED,
      BET_CAPTURE,
      /**
      * LuaBase Event:
      */
      BET_EFFECT_COMPAT,
    }
    namespace BEFEventType {
      let RTTI: RTTIDescriptor;
    }
    class BEFRect extends AObject {
      constructor();
      public left: number;
      public top: number;
      public right: number;
      public bottom: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum BEFTimerType {
      EVENT_ONCE,
      EVENT_CIRCLE,
    }
    namespace BEFTimerType {
      let RTTI: RTTIDescriptor;
    }
    enum BEF_ANIMATION_EVENT_CODE {
      ANIMATION_START,
      ANIMATION_END,
      ANIMATION_INTERRUPT,
    }
    namespace BEF_ANIMATION_EVENT_CODE {
      let RTTI: RTTIDescriptor;
    }
    enum BEF_AR_ACTION_CODE {
      ACTION_TRANSLATE,
      ACTION_ROTATE_LEFT,
      ACTION_ROTATE_RIGHT,
      ACTION_INTERRUPT,
      ACTION_END,
      ACTION_CLICK,
    }
    namespace BEF_AR_ACTION_CODE {
      let RTTI: RTTIDescriptor;
    }
    enum BEF_CAPTURE_EVENT_CODE {
      CAPTURE_NO_INIT,
      CAPTURE_ONCE,
    }
    namespace BEF_CAPTURE_EVENT_CODE {
      let RTTI: RTTIDescriptor;
    }
    enum BEF_RECODE_VEDIO_EVENT_CODE {
      RECODE_VEDIO_NO_INIT,
      RECODE_VEDIO_START,
      RECODE_VEDIO_END,
      RECODE_VEDIO_DELETE,
    }
    namespace BEF_RECODE_VEDIO_EVENT_CODE {
      let RTTI: RTTIDescriptor;
    }
    class BaseAction extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief base class for clips
    */
    class BaseClip extends AObject {
      constructor();
      public blendWeight: number;
      public isRestoreOrigVal: boolean;
      public overrideOther: boolean;
      public initialBlendWeight: number;
      public handle: number;
      /**
      * @brief get attached entity
      * @return the attached entity
      */
      public getAttachedEntity(): Entity;
      /**
      * @brief get target entity by name in the current sub tree
      * @param targetName the name of target entity
      * @return the target entity
      */
      public getTargetEntity(targetName: string): Entity;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngien ColliderAffector Base Class
    * Determines how a particle collision should be determined. POINT means that the position of
    *    the particle will be validated against the Colliders' shape. BOX means that the dimensions
    *   (width, height and depth) are used to determine whether the particle collides.
    *      Determines how a particle behaves after collision with this collider. The behaviour of the
    *    particle is solved in the collider and only behaviour that needs the colliders?data is taken
    *    into account. The fact that a particle expires for example, can be achieved by using an
    *    Observer in combination with an EventHandler (DoExpireEventHandler).
    *    NONE means that the particle doesn't do anything. This value should be set if the behaviour
    *    of the particle is determined outside the collider (for example, expiring the particle).
    *    BOUNCE means that the particle bounces off the collider.
    *    FLOW means that the particle flows around the contours of the collider.
    */
    class BaseColliderAffector extends Affector {
      constructor();
      /**
      * @brief AmazingEngine AMGAffectorIntersectionType Getter
      * @return AMGAffectorIntersectionType intersectionType
      */
      public intersectionType: AffectorIntersectionType;
      /**
      * @brief AmazingEngine AMGAffectorCollisionType Getter
      * @return AMGAffectorCollisionType collisionType
      */
      public collisionType: AffectorCollisionType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine BaseForceAffector
    */
    class BaseForceAffector extends Affector {
      constructor();
      /**
      * @brief Force scalar getteer
      * @return Real force scalar
      */
      public forceScalar: number;
      /**
      * @brief AmazingEngine Force Operation Getteer
      * @return AMGAffectorForceApplication AmazingEngine Affector Force Operation
      */
      public forceApplication: AffectorForceApplication;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief BaseTextComp containing typesetting parameters and position for letters
    */
    class BaseText extends Component {
      constructor();
      /**
      * @brief get enable status of 'use system text'
      * @return bool
      */
      public forceDegeneratedEs2Enabled: boolean;
      /**
      * @brief get text content
      * @return const std::string& utf8 encoded string
      */
      public str: string;
      /**
      * @brief get font size
      * @return float
      */
      public fontSize: number;
      public autoAdaptDpiEnabled: boolean;
      /**
      * @brief get font file path for self-provided font
      * @return const Name&
      */
      public fontPath: string;
      /**
      * @brief deprecate! get font file path for self-provided fallback font
      * @return const Name&
      */
      public fallbackFontPath: string;
      /**
      * @brief set the additional gap between two characters(Now, this api is somehow misunderstanding. Two English letters or two Chinese character)
      * @return float  a number describes the word gap is how many times of the row height.
      */
      public wordGap: number;
      /**
      * @brief get horizontal inner padding value, it will influence the size of bounding box.
      * @return float
      */
      public horizontalPadding: number;
      /**
      * @brief get vertical inner padding value, it will influence the size of bounding box.
      * @return float
      */
      public verticalPadding: number;
      /**
      * @brief get line gap, additional space between two lines.
      * @return float
      */
      public lineGap: number;
      /**
      * @brief get typesetting kind, horizontal or vertical.
      * @return AMGTypeSettingKind
      */
      public typeSettingKind: TypeSettingKind;
      /**
      * @brief get text align type
      * @return AMGTextAlign
      */
      public textAlign: TextAlign;
      /**
      * @brief get the enable status of fixed rect typesetting mode
      * @return bool
      */
      public fixedRectEnabled: boolean;
      /**
      * @brief get the flag of the auto font size, if set true, font size will be automatically adjusted to fit the rect size
      * @return bool
      */
      public autoFontSize: boolean;
      /**
      * @brief get the bounding rect of the text
      * @return const Rect&
      */
      public rect: Rect;
      /**
      * @brief get auto-wrap width
      * @return float
      */
      public autoWrapWidth: number;
      /**
      * @brief get char, only for script-using, aniamtion about position of character
      * @return const Vector&
      */
      public chars: Vector;
      public handle: number;
      public getRealHeight(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class BaseTextSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class BehaviorComponent extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class BehaviorSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum BehaviorWhenTrackerDisappear {
      ALIGN_VISIBILITY_WITH_TRACKER,
      STAY_PREVIOUS_FRAME,
      RESET_TO_ORIGIN,
    }
    namespace BehaviorWhenTrackerDisappear {
      let RTTI: RTTIDescriptor;
    }
    class Billboard extends CameraFollower {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum BlendFactor {
      ZERO,
      ONE,
      SRC_COLOR,
      ONE_MINUS_SRC_COLOR,
      DST_COLOR,
      ONE_MINUS_DST_COLOR,
      SRC_ALPHA,
      ONE_MINUS_SRC_ALPHA,
      DST_ALPHA,
      ONE_MINUS_DST_ALPHA,
    }
    namespace BlendFactor {
      let RTTI: RTTIDescriptor;
    }
    enum BlendOp {
      ADD,
      SUB,
      REVSUB,
      MIN,
      MAX,
    }
    namespace BlendOp {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief 2D Box shape collider
    *
    */
    class BoxCollider2D extends Collider2D {
      constructor();
      /**
      * @brief Set the box size
      * @param size size
      */
      public size: Vector2f;
      /**
      * @brief Set the Edge Radius of the box's edge
      * note this edge radius is the skin radius of the box shape
      * it will always be a small value which is almost invisible for users,
      * but significantly visible for computer.
      * @param edgeRadius edge radius
      */
      public edgeRadius: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief box collider 3d
    */
    class BoxCollider3D extends Collider3D {
      constructor();
      /**
      * @brief half extent of the box, change trigger collider dirty
      */
      public halfExtent: Vector3f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine BoxColliderAffector
    */
    class BoxColliderAffector extends BaseColliderAffector {
      constructor();
      /**
      * @brief Getter
      * @return float width
      */
      public width: number;
      /**
      * @brief Getter
      * @return float height
      */
      public height: number;
      /**
      * @brief Getter
      * @return float depth
      */
      public depth: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine Box Emitter
    */
    class BoxEmitter extends Emitter {
      constructor();
      /**
      * @brief Box Emitter height getter
      * @return Real height
      */
      public boxHeight: number;
      /**
      * @brief Box Emitter width getter
      * @return Real width
      */
      public boxWidth: number;
      /**
      * @brief Box Emitter depth getter
      * @return Real depth
      */
      public boxDepth: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class BrushComponent extends Component {
      constructor();
      public distance: number;
      public brushBeginLength: number;
      public brushMainLength: number;
      public brushEndLength: number;
      public brushDrawingScale: number;
      public brushLocalFrameType: BrushLocalFrameType;
      public brushDrawingType: BrushDrawingType;
      public brushFixedEnd: BrushSegment;
      public animationEnabled: boolean;
      public controlledByInputSpeed: boolean;
      public resamplingEnabled: boolean;
      public smoothingEnabled: boolean;
      public smoothingStrength: number;
      public verticalForcingStrength: number;
      public animationSpeed: number;
      public inputSpeedScale: number;
      public inputSpeedCutOff: number;
      public inputSpeedControlStrength: number;
      public skipMinDistance: number;
      public skipMaxDistance: number;
      public resampleArcLengthInterval: number;
      public simplifyEnabled: boolean;
      public redistributeUVEnabled: boolean;
      public alignEndUV: boolean;
      public simplifyThreshold: number;
      public simplifyWindowSize: number;
      public simplifyMaximumLength: number;
      public faceEnabled: boolean;
      public prefabBegin: Prefab;
      public prefabMain: Prefab;
      public prefabEnd: Prefab;
      public stroke: BrushStroke;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum BrushDrawingType {
      Discrete,
      Continuous,
    }
    namespace BrushDrawingType {
      let RTTI: RTTIDescriptor;
    }
    enum BrushLocalFrameType {
      Natural,
      Vertical,
      CameraFacing,
    }
    namespace BrushLocalFrameType {
      let RTTI: RTTIDescriptor;
    }
    enum BrushSegment {
      Begin,
      Main,
      End,
      COUNT,
    }
    namespace BrushSegment {
      let RTTI: RTTIDescriptor;
    }
    class BrushStroke extends AObject {
      constructor();
      public renderDirty: boolean;
      public animationSpeed: number;
      public handle: number;
      public isEnded(): boolean;
      public isAnimationEnabled(): boolean;
      public refreshStroke(beginIndex: number): void;
      public finishStroke(): void;
      public size(): number;
      public getSegmentPosition(index: number): Vector3f;
      public setSegmentPosition(pos: Vector3f, index: number): void;
      public getSegmentUp(index: number): Vector3f;
      public setSegmentUp(up: Vector3f, index: number): void;
      public getSegmentTangent(index: number): Vector3f;
      public setSegmentTangent(index: Vector3f, arg1: number): void;
      public getSegmentTime(index: number): number;
      public setSegmentTime(time: number, index: number): void;
      public getSegmentRadius(index: number): number;
      public setSegmentRadius(radius: number, index: number): void;
      public getSegmentArcLength(index: number): number;
      public getSegmentArcLengthSum(index: number): number;
      public getSegmentTransform(index: number): Transform;
      public getSegmentRenderer(index: number): Renderer;
      public addPoint(pos: Vector3f, up: Vector3f, lookAt: Vector3f, touchPressure: number, isEnd: boolean): void;
      public addARPoint(pos: Vector2f, up: Vector3f, camPos: Vector3f, proj: Matrix4x4f, worldToClip: Matrix4x4f, touchPressure: number, isEnd: boolean): void;
      public addFacePoint(pos: Vector3f, mvp: Matrix4x4f, vertices: Vec3Vector, touchPressure: number, isEnd: boolean): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class BrushSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Buffer extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class BufferRenderTarget extends RenderTarget {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Enum class of buildin texture type
    */
    enum BuiltInTextureType {
      /**
      * @brief AE_NORMAL created by engine
      */
      NORAML,
      /**
      * @brief INPUT0
      */
      INPUT0,
      /**
      * @brief INPUT1
      */
      INPUT1,
      /**
      * @brief INPUT2
      */
      INPUT2,
      /**
      * @brief INPUT3
      */
      INPUT3,
      /**
      * @brief INPUT4
      */
      INPUT4,
      /**
      * @brief INPUT5
      */
      INPUT5,
      /**
      * @brief INPUT6
      */
      INPUT6,
      /**
      * @brief INPUT7
      */
      INPUT7,
      /**
      * @brief INPUT8
      */
      INPUT8,
      /**
      * @brief INPUT9
      */
      INPUT9,
      /**
      * @brief OUTPUT
      */
      OUTPUT,
      /**
      * @brief HAIR Hair mask
      */
      HAIR,
      /**
      * @brief BG Background mask
      */
      BG,
      /**
      * @brief CLOTHES Clothes mask
      */
      CLOTHES,
      /**
      * @brief CAR Car mask
      */
      CAR,
      /**
      * @brief HEAD Head mask
      */
      HEAD,
      /**
      * @brief GROUND Ground mask
      */
      GROUND,
      /**
      * @brief MOUTHMASK Mouse mask
      */
      MOUTHMASK,
      /**
      * @brief TEETHMASK Teeth mask
      */
      TEETHMASK,
      /**
      * @brief FACEMASK Face mask
      */
      FACEMASK,
      /**
      * @brief Foot Mask
      */
      FOOTMASK,
      /**
      * @brief SKYSEGMASK SKYSEG Mask
      */
      SKYSEGMASK,
      /**
      * @brief Building Mask
      */
      BUILDING,
      /**
      * @brief SKIN SEG Mask
      */
      SKINSEGMASK,
      /**
      * @brief APOLLO PROCESS Mask
      */
      APOLLOPROCMASK,
      /**
      * @brief Foot Mask2
      */
      FOOTMASK2,
      /**
      * @brief SaliencySeg Mask Small
      */
      SALIENCYMASK_SMALL,
      /**
      * @brief SaliencySeg Mask Regular
      */
      SALIENCYMASK_REGULAR,
      /**
      * @brief External texture
      */
      SALIENCYINPUT,
      /**
      * @brief External texture
      */
      EXTERNAL,
      /**
      * @brief Depth texture
      */
      DEPTH,
      /**
      * @brief Image Transform Mask
      */
      NODEHUBIMAGEMASK,
      /**
      * @brief Hand Mask
      */
      HANDMASK,
      /**
      * @brief User upload texture
      */
      VE_IN,
      /**
      * @brief User upload texture
      */
      VE_OUT,
      /**
      * @brief User upload texture
      */
      CAM_OUT,
      VE_CAPTURE,
      /**
      * @brief User upload texture
      */
      DEFAULT_IN,
    }
    namespace BuiltInTextureType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief builtin effect config
    */
    class BuiltinEffectConfig extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief get internal beauty smooth
      * @return float value
      */
      public getInternalBeautySmooth(): number;
      /**
      * @brief get internal beauty brighten
      * @return float value
      */
      public getInternalBeautyBrighten(): number;
      /**
      * @brief get internal beauty sharp
      * @return float value
      */
      public getInternalBeautySharp(): number;
      /**
      * @brief get internal reshape eye
      * @return float value
      */
      public getInternalReshapeEye(): number;
      /**
      * @brief get internal reshape face
      * @return float value
      */
      public getInternalReshapeFace(): number;
      /**
      * @brief get internal makeup blusher
      * @return float value
      */
      public getInternalMakeupBlusher(): number;
      /**
      * @brief get internal makeup lips
      * @return float value
      */
      public getInternalMakeupLips(): number;
      /**
      * @brief get internal left filter instensity
      * @return float value
      */
      public getInternalLeftFilterIntensity(): number;
      /**
      * @brief get internal right filter instensity
      * @return float value
      */
      public getInternalRightFilterIntensity(): number;
      /**
      * @brief get internal filter position
      * @return float value
      */
      public getInternalFilterPosition(): number;
      /**
      * @brief get internal left filter
      * @return Texture2D* texture
      */
      public getInternalFilterLeft(): Texture2D;
      /**
      * @brief get internal right filter
      * @return Texture2D* texture
      */
      public getInternalFilterRight(): Texture2D;
      /**
      * @brief get internal instensity
      * @param name name
      * @return float value
      */
      public getInternalIntensity(name: string): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief builtin object
    */
    class BuiltinObject extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief get input texture width
      * @return int32_t width
      */
      public getInputTextureWidth(): number;
      /**
      * @brief get input texture height
      * @return int32_t height
      */
      public getInputTextureHeight(): number;
      /**
      * @brief get output texture width
      * @return int32_t width
      */
      public getOutputTextureWidth(): number;
      /**
      * @brief get output texture height
      * @return int32_t height
      */
      public getOutputTextureHeight(): number;
      /**
      * @brief whether the platform is android
      * @return bool result
      */
      public isAndroid(): boolean;
      /**
      * @brief get builtin effect config
      * @return BuiltinEffectConfig* config
      */
      public getBuiltinEffectConfig(): BuiltinEffectConfig;
      /**
      * @brief get scene by name
      * @param name name
      * @return Scene* scene
      */
      public getScene(name: string): Scene;
      /**
      * @brief add scene
      * @param name name
      * @param scene scene
      */
      public addScene(name: string, scene: Scene): void;
      public getStickerRootPath(stickerName: string): string;
      /**
      * @brief remove scene
      * @param name name
      * @return bool result
      */
      public removeScene(name: string): boolean;
      /**
      * get user texture in map
      * @param name name of textute
      */
      public getUserTexture(name: string): Texture2D;
      /**
      * get orientation of user texture
      * @param key name of textute
      */
      public getUserTextureOrientation(name: string): number;
      public getUserStringValue(name: string): string;
      public addUserStringValue(name: string, arg1: string): void;
      public addUserTexture(name: string, texture: Texture): void;
      public removeUserTexture(name: string): void;
      /**
      * @brief get built-in texture
      * @param type texture type
      * @param index index
      * @return Texture2D* texture
      */
      public getBuiltinTexture(type: BuiltInTextureType, index: number, arg2: RendererType): Texture;
      /**
      * @brief release middle render texture
      */
      public releaseMidRts(): void;
      public isInEditMode(): boolean;
      public setInEditMode(mode: boolean): void;
      public getMiddleRenderTexture(index: number): RenderTexture;
      public getEffectId(effectName: string): number;
      public getStickerPanel(effectName: string): string;
      public getEffectIdMap(): Map;
      public getStickerPanelMap(): Map;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class BuiltinObjectSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Calibrate extends AObject {
      constructor();
      public faceCount: number;
      public handle: number;
      public getPnPMMatrix(index: number, camera: Camera, onlyGet: boolean, faceType: CaptureType, viewportSize: Vector2f): Matrix4x4f;
      public getPnPPMatrix(faceType: CaptureType, viewportSize: Vector2f): Matrix4x4f;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief enumerating calibate version
    *
    */
    enum CalibrationType {
      V1,
      V2,
      V3,
      V4,
      V5,
      V6,
      UNKNOW,
    }
    namespace CalibrationType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Class Camera.
    */
    class Camera extends Component {
      constructor();
      /**
      * @brief Return the culling mask of current camera.
      * @return const DynamicBitset& The culling mask of current camera.
      */
      public layerVisibleMask: DynamicBitset;
      /**
      * @brief Return the render order of current camera.
      * @return uint32_t The render order of current camera.
      */
      public renderOrder: number;
      /**
      * @brief Return the projection type of current camera.
      * @return AMGCameraType The projection type.
      */
      public type: CameraType;
      /**
      * @brief Set the clear color of current camera.
      * @param c The clear color.
      */
      public clearColor: Color;
      /**
      * @brief Set the clear type of current camera.
      * @param ct The clear type.
      */
      public clearType: CameraClearType;
      /**
      * @brief Set whether need to clear target before render.
      * @param flag Whether need to clear target.
      */
      public alwaysClear: boolean;
      /**
      * @brief Get camera viewport with normalized rect.
      * @return const Rect& The normalized rect to represent viewport.
      */
      public viewport: Rect;
      /**
      * @brief Get fov of current camera.
      * @return float Fov.
      */
      public fovy: number;
      /**
      * @brief Get the orthogonal projection scale.
      * @return float The scale value.
      */
      public orthoScale: number;
      public fitMode: CameraFitMode;
      /**
      * @brief Get the near culling plane z value.
      * @return float The z value of near culling plane.
      */
      public zNear: number;
      /**
      * @brief Get the far culling plane z value.
      * @return float The z value of far culling plane.
      */
      public zFar: number;
      public inputTexture: Texture;
      /**
      * @brief Set the render texture of current camera.
      * @param tex The render texture which is going to be set to current camera.
      */
      public renderTexture: RenderTexture;
      /**
      * @brief Get projection matrix of current camera.
      * @return const Matrix4x4f& The projection matrix of current camera.
      */
      public projectionMatrix: Matrix4x4f;
      /**
      * @brief Set whether this camera is a root camera.
      * @param flag Whether this camera is a root camera.
      */
      public isRootCamera: boolean;
      public maskMaterial: Material;
      public sortMethod: CameraSortMethod;
      public rtBackupMode: CameraRTBackupMode;
      public handle: number;
      /**
      * @brief Check whether input box is out of current frustum.
      * @param bbox Input box need to check.
      * @return bool Whether input box is out of current frustum.
      */
      public isOutOfFrustum(bbox: AABB): boolean;
      /**
      * @brief Projects a World space point into screen space.
      * @param worldSpacePoint The input point in world space.
      * @return Vector3f
      */
      public worldToScreenPoint(v: Vector3f): Vector3f;
      /**
      * @brief Unprojects a screen space point into world space
      * @param screenSpacePoint A point in screen space.
      * @return Vector3f Calculation result of point in world space.
      */
      public screenToWorldPoint(v: Vector3f): Vector3f;
      /**
      * @brief Unprojects a view port space into world space
      * @param viewPort A point in view port space.
      * @return Vector3f Calculation result of point in wolrd space.
      */
      public viewportToWorldPoint(viewPortPoint: Vector3f): Vector3f;
      /**
      * @brief Projects a world space point into viewport space
      * @param worldSpace A point in world space.
      * @return Vector3f Calculation result of point in viewport
      */
      public worldToViewportPoint(worldPoint: Vector3f): Vector3f;
      /**
      * @brief Return whether traget layer is visible.
      * @param layer The index of layer.
      * @return bool Wthether target layer is visible.
      */
      public isLayerVisible(layer: number): boolean;
      public isEntityVisible(entity: Entity): boolean;
      /**
      * @brief Clear current render target.
      * @param isolated Whether this function is called isolately.
      */
      public clearTarget(isolated: boolean): void;
      /**
      * @brief Return view projection matrix.
      * @return const Matrix4x4f& The view projeciton matrix.
      */
      public getWorldToClipMatrix(): Matrix4x4f;
      /**
      * @brief Return the camera to world matrix.
      * @return Matrix4x4f& The camera to world matrix.
      */
      public getCameraToWorldMatrix(): Matrix4x4f;
      /**
      * @brief Return the world to camera matrix.
      * @return const Matrix4x4f& The world to camera matrix.
      */
      public getWorldToCameraMatrix(): Matrix4x4f;
      /**
      * @brief set the camera to world matrix.
      * @param Matrix4x4f The custom camera to world matrix.
      */
      public setWorldToCameraMatrix(matrix: Matrix4x4f): void;
      /**
      * @brief reset the camera to world matrix.
      */
      public resetWorldToCameraMatrix(): void;
      /**
      * @brief Get the world position of current camera.
      * @return Vector3f The world position of current camera.
      */
      public getPosition(): Vector3f;
      /**
      * @brief Get the forward direction of current camera.
      * @return Vector3f The forward direction.
      */
      public getLookAt(): Vector3f;
      /**
      * @brief Converts a screen point into a world space ray.
      * @param screenPos A point in screen sapce.
      * @return Ray Calculation result of world space ray.
      */
      public ScreenPointToRay(screenPos: Vector2f): Ray;
      /**
      * @brief Converts a viewport point into a world space ray.
      * @param viewportPos A point in viewport space.
      * @return Ray Calculation result of world space ray.
      */
      public ViewportPointToRay(viewportPos: Vector2f): Ray;
      public invokeCameraEvent(cameraEvent: number): void;
      public tryGetCullingParameters(): ScriptableCullingParameters;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Camera Clear Type Enum.
    */
    enum CameraClearType {
      /**
      * @brief Clear color only.
      */
      COLOR,
      /**
      * @brief Clear depth only.
      */
      DEPTH,
      /**
      * @brief Clear color and depth.
      */
      COLOR_DEPTH,
      /**
      * @brief Clear nothing.
      */
      DONT,
      /**
      * @brief Clear depth and stencil
      */
      DEPTH_STENCIL,
      /**
      * @brief Clear color, depth and stencil
      */
      COLOR_DEPTH_STENCIL,
      STENCIL,
      COLOR_STENCIL,
    }
    namespace CameraClearType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Camera listener type.
    */
    enum CameraEvent {
      /**
      * @brief Listener will be triggered before render.
      */
      BEFORE_RENDER,
      BEFORE_FORWARD_OPAQUE,
      AFTER_FORWARD_OPAQUE,
      BEFORE_FORWARD_ALPHA,
      AFTER_FORWARD_ALPHA,
      /**
      * @brief Listener will be triggered after render.
      */
      AFTER_RENDER,
      /**
      * @brief Listener will be triggered after image effects.
      */
      AFTER_IMAGE_EFFECTS,
      /**
      * @brief Listener will be triggered after all process.
      */
      AFTER_EVERYTHING,
      /**
      * @brief Listener will be triggered between AFTER_RENDER and AFTER_IMAGE_EFFECTS.
      */
      RENDER_IMAGE_EFFECTS,
    }
    namespace CameraEvent {
      let RTTI: RTTIDescriptor;
    }
    enum CameraFitMode {
      NONE,
      FILL,
      FIT,
    }
    namespace CameraFitMode {
      let RTTI: RTTIDescriptor;
    }
    class CameraFollower extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class CameraFollowerSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief The position of Camera.
    */
    enum CameraPosition {
      FRONT,
      BACK,
    }
    namespace CameraPosition {
      let RTTI: RTTIDescriptor;
    }
    enum CameraRTBackupMode {
      NEVER,
      CAMERA_CHANGED,
    }
    namespace CameraRTBackupMode {
      let RTTI: RTTIDescriptor;
    }
    enum CameraSortMethod {
      SORT_ORDER_AND_RENDERQUEUES,
      STRICT_SORT_ORDER,
      RENDERQUEUE_AND_DEPTH,
    }
    namespace CameraSortMethod {
      let RTTI: RTTIDescriptor;
    }
    class CameraSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Camera Projection Type Enum.
    */
    enum CameraType {
      /**
      * @brief Perspective projection.
      */
      PERSPECTIVE,
      /**
      * @brief Orthogonal projection.
      */
      ORTHO,
    }
    namespace CameraType {
      let RTTI: RTTIDescriptor;
    }
    enum CanvasRenderMode {
      SCREEN_SPACE_OVERLAY,
      SCREEN_SPACE_CAMERA,
      WORLD_SPACE,
    }
    namespace CanvasRenderMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief capsule collider 3d
    */
    class CapsuleCollider3D extends Collider3D {
      constructor();
      /**
      * @brief radius of the capsule
      */
      public radius: number;
      /**
      * @brief height of the capsule
      */
      public height: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief enumerating face types
    *
    */
    enum CaptureType {
      HUMAN,
      HUMAN_EXT,
      CAT,
      DOG,
      FACE_PLACEHOLDER,
      UNKNOW,
    }
    namespace CaptureType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief enumerating cv point follow or slovepnp head mode follow
    *
    */
    enum CaptureVersion {
      SOLVEPNP,
      CVPOINTS,
    }
    namespace CaptureVersion {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief a struct to store the texture coordinates.
    */
    class CharRect extends AObject {
      constructor();
      /**
      * < whether sdf texture
      */
      public isSdf: boolean;
      /**
      * < min x
      */
      public x0: number;
      /**
      * < max x
      */
      public x1: number;
      /**
      * < min y
      */
      public y0: number;
      /**
      * < max y
      */
      public y1: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief circle shape collider
    */
    class CircleCollider2D extends Collider2D {
      constructor();
      /**
      * @brief Set the Radius of the circle shape
      * @param radius radius
      */
      public radius: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine Circle Emitter
    */
    class CircleEmitter extends Emitter {
      constructor();
      /**
      * @brief Sphere outer radius getter
      * @return Real ( outer radius )
      */
      public radius: number;
      /**
      * @brief Sphere inner radius getter
      * @return Real ( inner radius )
      */
      public inner_radius: number;
      /**
      * @brief  Sphere emittion step angle getter
      * @return Real(rad) :
      */
      public stepAngle: number;
      /**
      * @brief Whether use random angle for circle emitter
      * @return bool
      */
      public useRandomAngle: boolean;
      /**
      * @brief  Sphere emittion min angle getter
      * @return Real(rad) :
      */
      public minAngle: number;
      /**
      * @brief  Sphere emittion min angle getter
      * @return Real(rad) :
      */
      public maxAngle: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum ClientState {
      CLIENT_STATE_UNKNOW,
      CLIENT_STATE_PREVIEW,
      CLIENT_STATE_CAPTURE,
      CLIENT_STATE_RECORD,
      CLIENT_STATE_ALBUM,
      CLIENT_STATE_EDITOR,
      CLIENT_STATE_PREVIEW_PHOTO,
      CLIENT_STATE_PREVIEW_VIDEO,
    }
    namespace ClientState {
      let RTTI: RTTIDescriptor;
    }
    class CloneFeatureNode extends FeatureNode {
      constructor();
      public effectName: string;
      public cloneFeatureTypes: StringVector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief collider orientation
    */
    enum CollideDirection {
      X,
      Y,
      Z,
    }
    namespace CollideDirection {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief collider2D is the base class of all collider type, including box/ circle/ edge/.
    */
    class Collider2D extends Component {
      constructor();
      /**
      * @brief Set the physics Material
      * if b2Fixture object has been created, material params will also be passed into it
      * @param material material
      */
      public material: PhysicsMaterial;
      /**
      * @brief Set the Density of this collider
      * @param density density
      */
      public density: number;
      /**
      * @brief Set the Trigger property
      * @param trigger trigger
      */
      public trigger: boolean;
      /**
      * @brief Set the Category Bits
      * collider's category, will matched by mask
      * @param bits bits
      */
      public categoryBits: number;
      /**
      * @brief Set the Mask Bits
      * collider can collider with which categories.
      * @param bits bits
      */
      public maskBits: number;
      /**
      * @brief Set the Group Index
      * collision groups allow a certain group of objects to never collide(negative)
      * or always collider(positive). zero means no collision group. None-zero group filtering always
      * wins against the mask bits.
      * @param groupIndex group index
      */
      public groupIndex: number;
      /**
      * @brief Set the pivot offset
      * @param offset offset
      */
      public offset: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief collider3D interface
    */
    class Collider3D extends Component {
      constructor();
      /**
      * @brief local offset relative to the rigidbody center
      */
      public offset: Vector3f;
      /**
      * @brief local rotation relative to the rigidbody center
      */
      public rot: Quaternionf;
      /**
      * @brief used in which systems
      */
      public flag: Collider3DFlag;
      /**
      * @brief exclusivity of the collider for processing raytest in InputSystem
      */
      public inputExclusive: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Collider3DFlag
    */
    enum Collider3DFlag {
      /**
      * @brief Physics3DSystem
      */
      Physics,
      /**
      * @brief InputSystem
      */
      Input,
      /**
      * @brief all systems
      */
      All,
    }
    namespace Collider3DFlag {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief ColliderListener
    */
    enum ColliderListener {
      /**
      * @brief gesture tap
      */
      ON_GESTURE_TAP,
      /**
      * @brief gesture long tap
      */
      ON_GESTURE_LONG_TAP,
      /**
      * @brief gesture double click
      */
      ON_GESTURE_DOUBLE_CLICK,
      /**
      * @brief gesture drag
      */
      ON_GESTURE_DRAG,
      /**
      * @brief collider hit
      */
      ON_HIT,
    }
    namespace ColliderListener {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Collision information
    */
    class Collision3D extends AObject {
      constructor();
      /**
      * @brief This rigidbody. may be nullptr if is particle
      */
      public thisRigidbody: RigidBody3D;
      /**
      * @brief The other rigidbody we hit. may be nullptr if is particle
      */
      public otherRigidbody: RigidBody3D;
      /**
      * @brief This collider we hit. do not support multi colliders with mesh collider. may be nullptr.
      */
      public thisCollider: Collider3D;
      /**
      * @brief The other collider we hit. do not support multi colliders with mesh collider. may be nullptr.
      */
      public otherCollider: Collider3D;
      /**
      * @brief The contact points.
      */
      public contacts: Vector;
      /**
      * @brief This component. RigidBody3D or ParticleComponent.
      */
      public thisComponent: Component;
      /**
      * @brief The other component we hit. RigidBody3D or ParticleComponent.
      */
      public otherComponent: Component;
      /**
      * @brief This collider object we hit. Collider3D or Particle. may be nullptr.
      */
      public thisColliderObject: AObject;
      /**
      * @brief The other collider object  we hit. Collider3D or Particle. may be nullptr.
      */
      public otherColliderObject: AObject;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Collision3D event type.
    */
    enum Collision3DEventType {
      /**
      * @brief Begun touching.
      */
      ENTER,
      /**
      * @brief Is touching.
      */
      STAY,
      /**
      * @brief Stopped touching.
      */
      EXIT,
    }
    namespace Collision3DEventType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief type of collision detection
    * CONTINUOUS_DYNAMIC is only for rigid body 3D, you can't set collision detection type to CONTINUOUS_DYNAMIC in rigid
    * body 2D
    */
    enum CollisionDetectionType {
      /**
      * @brief discrete collision detection between all kinds of rigid bodies, fastest
      */
      DISCRETE,
      /**
      * @brief continuous collision detection, only do continuous detection between dynamic collider with static collider
      */
      CONTINUOUS,
      /**
      * @brief do continuous detection between continuous and continuous dynamic collider, heavy computation overhead
      */
      CONTINUOUS_DYNAMIC,
      /**
      * @brief speculative mode, this is the only continuous collision detection mode you can set on KINEMATIC rigid body
      */
      CONTINUOUS_SPECULATIVE,
    }
    namespace CollisionDetectionType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief collision event type
    */
    enum CollisionEventType {
      BEGIN_COLLISION,
      END_COLLISION,
      PRE_SOLVE,
      POST_SOLVE,
    }
    namespace CollisionEventType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine ColorAffector (AmazingEngine
    */
    class ColorAffector extends Affector {
      constructor();
      public colorMap: Vector;
      /**
      * @brief AMGColorOperation Setter
      * @param colorOperation : Color Affector Type
      */
      public colorOperation: ColorOperation;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief color blend attachment state
    */
    class ColorBlendAttachmentState extends AObject {
      constructor();
      /**
      * @brief set blend enable
      * @param blendEnable bool
      */
      public blendEnable: boolean;
      /**
      * @brief set src color blend factor
      * @param srcColorBlendFactor AMGBlendFactor
      */
      public srcColorBlendFactor: BlendFactor;
      /**
      * @brief set dst color blend factor
      * @param dstColorBlendFactor AMGBlendFactor
      */
      public dstColorBlendFactor: BlendFactor;
      /**
      * @brief set src alpha blend factor
      * @param srcAlphaBlendFactor AMGBlendFactor
      */
      public srcAlphaBlendFactor: BlendFactor;
      /**
      * @brief set dst alpha blend factor
      * @param dstAlphaBlendFactor AMGBlendFactor
      */
      public dstAlphaBlendFactor: BlendFactor;
      /**
      * @brief set color write mask
      * @param colorWriteMask uint32_t
      */
      public colorWriteMask: number;
      public ColorBlendOp: BlendOp;
      public AlphaBlendOp: BlendOp;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief color blend state
    */
    class ColorBlendState extends AObject {
      constructor();
      /**
      * @brief set blend constants
      * @param constants Vector4f
      */
      public blendConstants: Vector4f;
      /**
      * @brief blend enable name
      */
      public blendEnableName: string;
      /**
      * @brief blend factor name
      */
      public blendFactorName: string;
      /**
      * @brief blend op name
      */
      public blendOpName: string;
      /**
      * @brief set attachments
      * @param att Vector of ColorBlendAttachmentState
      */
      public attachments: Vector;
      public handle: number;
      /**
      * @brief push attachment
      * @param state ColorBlendAttachmentState
      * @param isPushFront bool
      */
      public pushAttachment(arg0: ColorBlendAttachmentState, arg1: boolean): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief defined the color change rule according to input textcolor
    * @deprecated may be deprecated in the future
    */
    class ColorChange extends AObject {
      constructor();
      /**
      * < whether the color need to change
      */
      public change: boolean;
      /**
      * < define percentage of the this color, used for gradient color. range from [0,1]
      */
      public percent: number;
      /**
      * < rgba
      */
      public color: Color;
      /**
      * < hsb change rule
      */
      public hsbOffset: Vector3f;
      /**
      * @deprecated, do not use.
      */
      public alphaOffset: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum ColorMask {
      R,
      G,
      B,
      A,
    }
    namespace ColorMask {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine color change type
    * AmazingEngine
    */
    enum ColorOperation {
      MULTIPLY,
      SET,
      RANDOM,
    }
    namespace ColorOperation {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief CommandBuffer is a self contained command sequence which is record once,
    * but can be executed multiple times. The set of graphics command exposed to lua
    * layer enables user to add custom rendering logic in addition to existing render system.
    */
    class CommandBuffer extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief Add a "blit into a render texture" command.
      * @param source  Source texture to blit from.
      * @param dest    Destination render texture to blit into.
      */
      public blit(src: Texture, dest: RenderTexture): void;
      /**
      * @brief Add a "blit into a render texture" command.
      * @param source      Source texture to blit from.
      * @param dest        Destination render texture to blit into.
      * @param material    Material to use.
      * @param shaderPass  Shader pass to use (default is -1, meaning "all passes").
      */
      public blitWithMaterial(src: Texture, dest: RenderTexture, material: Material, shaderPass: number, isCache: boolean): void;
      /**
      * @brief Add a "blit into a render texture" command.
      * @param source      Source texture to blit from.
      * @param dest        Destination render texture to blit into.
      * @param material    Material to use.
      * @param shaderPass  Shader pass to use (default is -1, meaning "all passes").
      * @param properties  Additional material properties to apply onto material just before blitting.
      */
      public blitWithMaterialAndProperties(src: Texture, dest: RenderTexture, material: Material, shaderPass: number, properties: MaterialPropertyBlock, isCache: boolean): void;
      public blitSliceWithMaterial(src: Texture, dest: RenderTexture, srcSlice: number, destSlice: number, material: Material, shaderPass: number, isCache: boolean): void;
      public blitSliceWithMaterialAndProperties(src: Texture, dest: RenderTexture, srcSlice: number, destSlice: number, material: Material, shaderPass: number, properties: MaterialPropertyBlock, isCache: boolean): void;
      /**
      * @brief Clear all commands in the buffer.
      */
      public clearAll(): void;
      /**
      * @brief Adds a "clear render target" command.
      * @param clearColor      Should clear depth buffer?
      * @param clearDepth      Should clear color buffer?
      * @param backgroundColor Color to clear with.
      * @param depth           Depth to clear with (default is 1.0).
      */
      public clearRenderTexture(clearColor: boolean, clearDepth: boolean, backgroundColor: Color, depth: number): void;
      /**
      * @brief Adds a "clear render target" command.
      * @param clearColor      Should clear depth buffer?
      * @param clearDepth      Should clear color buffer?
      * @param clearStencil    Should clear stencil buffer?
      * @param backgroundColor Color to clear with.
      * @param depth           Depth to clear with.
      * @param stencil         Stencil to clear with.
      */
      public clearRenderTextureWithStencil(clearColor: boolean, clearDepth: boolean, clearStencil: boolean, backgroundColor: Color, depth: number, stencil: number): void;
      /**
      * @brief Add a command to disable the hardware scissor rectangle.
      */
      public disableScissorRect(): void;
      /**
      * @brief Add a "draw mesh" command
      * @param mesh            Mesh to draw.
      * @param matrix          Transformation matrix to use.
      * @param material        Material to use.
      * @param submeshIndex    Which subset of the mesh to render.
      * @param shaderPass      Which pass of the shader to use (default is -1, which renders all passes).
      * @param properties      Additional material properties to apply onto material just before this mesh will be drawn.
      */
      public drawMesh(mesh: Mesh, matrix: Matrix4x4f, material: Material, submeshIndex: number, shaderPass: number, properties: MaterialPropertyBlock, isCache: boolean): void;
      /**
      * @brief Add a "draw procedural" command
      * @param material Material to use.
      * @param topology AMGPrimitive used to draw
      * @param vertexCount The count of the vertex
      * @param indices indices used to indicate how to draw
      * @param instanceCount The count of instances you want to draw
      * @param layoutBuffers The LayoutBufferDescs used to describe multiple vbos
      * @param properties Additional material properties to apply onto material just before this mesh will be drawn.
      */
      public drawProcedural(material: Material, topology: Primitive, vertexCount: number, indices: UInt32Vector, instanceCount: number, layoutBufferDescs: Vector, properties: MaterialPropertyBlock): void;
      /**
      * @brief Add a "draw procedural" command
      * @param material Material to use.
      * @param shaderPass Which pass of the shader to use (default is -1, which renders all passes).
      * @param topology AMGPrimitive used to draw
      * @param vertexCount The count of the vertex
      * @param indices indices used to indicate how to draw
      * @param instanceCount The count of instances you want to draw
      * @param layoutBuffers The LayoutBufferDescs used to describe multiple vbos
      * @param properties Additional material properties to apply onto material just before this mesh will be drawn.
      */
      public drawProceduralWithPass(material: Material, shaderPass: number, topology: Primitive, vertexCount: number, indices: UInt32Vector, instanceCount: number, layoutBufferDescs: Vector, properties: MaterialPropertyBlock): void;
      /**
      * @brief Add a command to enable the hardware scissor rectangle. This command can be used to clip regions of the screen from rendering.
      * @param scissor         Viewport rectangle in pixel coordinates.
      */
      public enableScissorRect(rect: Rect): void;
      /**
      * @brief Add a "set global shader color property" command.
      * When the command buffer will be executed, a global shader color property will be set at this point.
      * @param name        name for GlobalColor
      * @param value       value for GlobalColor
      */
      public setGlobalColor(name: string, color: Color): void;
      /**
      * @brief Add a "set global shader float property" command.
      * When the command buffer will be executed, a global shader float property will be set at this point.
      * @param name        name for float
      * @param value       value for float
      */
      public setGlobalFloat(name: string, value: number): void;
      /**
      * @brief Add a "set global shader float array property" command.
      * When the command buffer will be executed, a global shader vec4 will be set at this point.
      * @param name        name for Vector4f
      * @param value       value for Vector4f
      */
      public setGlobalVector4f(name: string, value: Vector4f): void;
      /**
      * @brief Add a "set global shader matrix property" command.
      * When the command buffer will be executed, a global shader matrix property will be set at this point.
      * @param name        name for Matrix4x4f
      * @param value       value for Matrix4x4f
      */
      public setGlobalMatrix(name: string, value: Matrix4x4f): void;
      /**
      * @brief Add a "set global shader texture property" command, referencing a RenderTexture.
      * When the command buffer will be executed, a global shader texture property will be set at this point.
      * @param name        name for Texture
      * @param texture     texture
      */
      public setGlobalTexture(name: string, texture: RenderTexture): void;
      /**
      * @brief Add a "set global shader texture3D property" command, referencing a RenderTexture.
      * When the command buffer will be executed, a global shader texture property will be set at this point.
      * @param name        name for TextureCube
      * @param texture     textureCube
      */
      public setGlobalTextureCube(name: string, texture: TextureCube): void;
      /**
      * @brief Add a "set invert culling" command to the buffer.
      * When the command buffer is executed, the backface culling is either inverted (when invertCulling is set to true) or not (when invertCulling is set to false)
      * @param invCulling  A boolean indicating whether to invert the backface culling (true) or not (false).
      */
      public setInvertCulling(invCulling: boolean): void;
      /**
      * @brief Add a command to set the projection matrix.
      * View matrix is the matrix that transforms from view space into homogeneous clip space.
      * @param proj        Projection (camera to clip space) matrix.
      */
      public setProjectionMatrix(proj: Matrix4x4f): void;
      /**
      * @brief Add a "set active render target" command.
      * Render texture to use can be indicated in several ways: a RenderTexture object, a temporary render texture
      * @param target      Render target to set for both color & depth buffers.
      */
      public setRenderTexture(target: RenderTexture): void;
      public setRenderTextureWithSlice(target: RenderTexture, slice: number): void;
      /**
      * @brief Add a command to set the view matrix.
      * View matrix is the matrix that transforms from world space into camera space.
      * Note that when setting both view and projection matrices, it is slightly more efficient
      * @param view        View (world to camera space) matrix.
      */
      public setViewMatrix(view: Matrix4x4f): void;
      /**
      * @brief Add a command to set the rendering viewport.
      * By default after render target changes the viewport is set to encompass the whole render target.
      * @param pixelRect   Viewport rectangle in pixel coordinates.
      */
      public setViewport(pixelRect: Rect): void;
      /**
      * @brief End Render Pipeline
      */
      public endRender(): void;
      /**
      * @brief Add a command to set the view and projection matrices.
      * @param view        View (world to camera space) matrix.
      * @param proj        Projection (camera to clip space) matrix.
      */
      public setViewProjectionMatrices(view: Matrix4x4f, proj: Matrix4x4f): void;
      /**
      * @brief Add a command to execute a compute shader
      * @param entity entity used by current compute pipeline
      * @param threadGroupsX Number of work groups in the X dimension
      * @param threadGroupsY Number of work groups in the Y dimension
      * @param threadGroupsZ Number of work groups in the Z dimension
      */
      public dispatchCompute(entity: AMGComputeEntity, threadGroupsX: number, threadGroupsY: number, threadGroupsZ: number): void;
      /**
      * @brief Begin Compute Pipeline
      */
      public beginCompute(): void;
      /**
      * @brief End Compute Pipeline
      */
      public endCompute(): void;
      public getTemporaryRT(nameID: number, rtConfig: RenderTextureConfig, isScreenRT: boolean): void;
      public releaseTemporaryRT(nameID: number): void;
      public blitTempRT(args: Vector): void;
      public blitWithMaterialTempRT(args: Vector, material: Material, shaderPass: number, isCache: boolean): void;
      public blitWithMaterialAndPropertiesTempRT(args: Vector, material: Material, shaderPass: number, properties: MaterialPropertyBlock, isCache: boolean): void;
      public blitSliceWithMaterialTempRT(args: Vector, srcSlice: number, destSlice: number, material: Material, shaderPass: number, isCache: boolean): void;
      public blitSliceWithMaterialAndPropertiesTempRT(args: Vector, srcSlice: number, destSlice: number, material: Material, shaderPass: number, properties: MaterialPropertyBlock, isCache: boolean): void;
      public setGlobalTextureTemp(name: string, nameID: number): void;
      public setRenderTextureTemp(nameID: number): void;
      public propertyToID(name: string): number;
      public setRenderTextureWithSliceTemp(nameID: number, slice: number): void;
      public generateMipmap(texture: Texture): void;
      public generateMipmapTempRT(args: Vector): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class CompEntityGUID extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum CompareOp {
      NEVER,
      LESS,
      EQUAL,
      LESS_OR_EQUAL,
      GREATER,
      NOT_EQUAL,
      GREATER_OR_EQUAL,
      ALWAYS,
      MAX_ENUM,
    }
    namespace CompareOp {
      let RTTI: RTTIDescriptor;
    }
    class CompatScene extends AObject {
      constructor();
      public handle: number;
      public getScene(): Scene;
      public wrapper(scene: Scene): void;
      public play(anim_type: string, entity_name: string, clip_name: string, loop: boolean): boolean;
      public pause(anim_type: string, entity_name: string, clip_name: string): boolean;
      public isAnimPlaying(anim_type: string, entity_name: string, clip_name: string): boolean;
      public resume(anim_type: string, entity_name: string, clip_name: string): boolean;
      public stop(anim_type: string, entity_name: string, clip_name: string): boolean;
      public forceStop(anim_type: string, entity_name: string, clip_name: string): boolean;
      public reset(anim_type: string, entity_name: string, clip_name: string): boolean;
      public getEntityGUIDWithName(entity_name: string): number;
      public setVisible(entity_name: string, is_vis: boolean): void;
      public isVisible(entity_name: string): boolean;
      public setVisibleWithGUID(entityGUID: number, is_vis: boolean): void;
      public isVisibleWithGUID(entityGUID: number): boolean;
      public setEntityComponentEnableWithName(entityGUID: string, componentName: string, enable: boolean): boolean;
      public setEntityComponentEnableWithGUID(entityGUID: number, componentName: string, enable: boolean): boolean;
      public cloneEntity(fromEntityName: string, newEntityName: string): number;
      public removeEntityWithName(entityName: string): number;
      public removeEntityWithGUID(entityGUID: number): boolean;
      public setPosition(entityName: string, posX: number, posY: number, posZ: number): void;
      public setOrientation(entityName: string, w: number, x: number, y: number, z: number): void;
      public setScale(entityName: string, scaleX: number, scaleY: number, scaleZ: number): void;
      public setWorldPosition(entityName: number, posX: number, posY: number, posZ: number): void;
      public setWorldOrientation(entityName: number, w: number, x: number, y: number, z: number): void;
      public setWorldScale(entityName: number, scaleX: number, scaleY: number, scaleZ: number): void;
      public setPositionGUID(entityName: number, posX: number, posY: number, posZ: number): void;
      public setOrientationGUID(entityName: number, w: number, x: number, y: number, z: number): void;
      public setScaleGUID(entityName: number, scaleX: number, scaleY: number, scaleZ: number): void;
      public getEntityScreenPosition(EntityGUID: number): Vector3f;
      public getWorldPosition(EntityGUID: number): Vector3f;
      public getWorldOrientation(EntityGUID: number): Vector4f;
      public getWorldScale(EntityGUID: number): Vector3f;
      public getLocalPosition(EntityGUID: number): Vector3f;
      public getLocalOrientation(EntityGUID: number): Quaternionf;
      public getLocalScale(EntityGUID: number): Vector3f;
      public setDeviceOrientation(orient_0: number, orient_1: number, orient_2: number, orient_3: number, entityName: string): boolean;
      public setCameraOrientation(orient_0: number, orient_1: number, orient_2: number, orient_3: number): boolean;
      public bindEntityToFaceId(guid: number, faceID: number): void;
      public axisAngleToQuaternion(axis: Vector3f, angle: number): Quaternionf;
      public rotateQuat(rotate: Quaternionf, orient: Quaternionf): Quaternionf;
      public quatInverse(quat: Quaternionf): Quaternionf;
      public quatRoll(quat: Quaternionf, reprojectAxis: boolean): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief component base
    *
    */
    class Component extends AObject {
      constructor();
      /**
      * @brief get whether component is enable
      * @return bool whether component is enable
      */
      public enabled: boolean;
      public entity: Entity;
      /**
      * @brief Set prefab
      * @param prefab prefab
      */
      public prefab: Prefab;
      /**
      * @brief Set prefab object GUID
      * @param guid prefab object guid
      */
      public prefabObjectGuid: Guid;
      public handle: number;
      public isInheritedEnabled(): boolean;
      public instantiate(): Component;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Component Override
    */
    class ComponentOverride extends PrefabOverride {
      constructor();
      public componentOverrideType: ComponentOverrideType;
      public addComponent: Component;
      public modifyProperties: Map;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief ComponentOverrideType
    */
    enum ComponentOverrideType {
      Modify,
      Add,
      Remove,
    }
    namespace ComponentOverrideType {
      let RTTI: RTTIDescriptor;
    }
    enum ComponentType {
      RIGID_BODY,
      COLLIDER,
      DISTANCE_JOINT,
      SPHERICAL_JOINT,
      ANISOTROPIC_SPHERICAL_JOINT,
      HINGE_JOINT,
      FIXED_RELATIVE_ROTATION_JOINT,
    }
    namespace ComponentType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine Cone Emitter
    */
    class ConeEmitter extends Emitter {
      constructor();
      /**
      * @brief Cone radius getter
      * @return Real :
      */
      public radius: number;
      /**
      * @brief  Cone emittion Cone angle getter
      * @return Real(angles) :
      */
      public coneAngle: number;
      /**
      * @brief  Cone emittion Arc angle getter
      * @return Real(angles) :
      */
      public circleArc: number;
      /**
      * @brief  Cone emittion step angle getter
      * @return Real(angles) :
      */
      public stepAngle: number;
      /**
      * @brief  Cone emittion emit from getter
      * @return AMGConeEmitterEmitFrom : BASE or VOLUME
      */
      public emitFrom: ConeEmitterEmitFrom;
      /**
      * @brief Cone volume length getter
      * @return Real
      */
      public length: number;
      /**
      * @brief Whether use random angle for circle emitter
      * @return bool
      */
      public useRandomAngle: boolean;
      /**
      * @brief Whether use direction Align cone  getter
      * @return bool
      */
      public isAlignCone: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief ConeEmitter Emit from
    */
    enum ConeEmitterEmitFrom {
      BASE,
      VOLUME,
    }
    namespace ConeEmitterEmitFrom {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief ContactPoint
    */
    class ContactPoint3D extends AObject {
      constructor();
      /**
      * @brief The point of contact at other collider.
      */
      public point: Vector3f;
      /**
      * @brief Normal of the contact point.
      */
      public normal: Vector3f;
      /**
      * @brief The impulse applied to this contact point.
      */
      public impulse: number;
      /**
      * @brief The friction.
      */
      public friction: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum ContextType {
      AMGNone,
      AMGSpawner,
      AMGInit,
      AMGUpdate,
      AMGOutput,
      AMGEvent,
      AMGSpawnerGPU,
      AMGStrip,
      AMGInitStrip,
      AMGUpdateStrip,
      AMGPoint,
      AMGPointOutput,
      AMGQuad,
      AMGQuadOutput,
      AMGStripQuadOutput,
      AMGMesh,
      AMGMeshOutput,
      AMGTriangle,
      AMGTriangleOutput,
      AMGQuadInstancingOutput,
    }
    namespace ContextType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Options related to contour decimation
    */
    class ContourDecimationOption extends AObject {
      constructor();
      /**
      * Minimum nr of points in a contour; Only used by algorithm processing ContourSets
      */
      public minContourSize: number;
      /**
      * Maximum distance threshold used in the algorithm.
      * If a point to line distance it larger than this, it will be removed.
      */
      public maxDisThreshold: number;
      /**
      * Point number ratio in the result contour
      * to input contour. Defaut is 1.0 (not used). If this ratio is smaller
      * than 1.0, then the decimation will ensure that (#points in output
      * contour) / (#points in input contour) <= decimationRatio.
      */
      public decimationRatio: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Options for sampling algorithms
    */
    class ContourSamplingOption extends AObject {
      constructor();
      /**
      * Sampling radius
      */
      public radius: number;
      /**
      * Sampling padding
      */
      public padding: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief 2D set of continuous contour lines
    */
    class ContourSet extends AObject {
      constructor();
      public contours: Vector;
      public normals: Vector;
      public handle: number;
      public clone(): ContourSet;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief cube cross image provider for a cubemap
    */
    class CubeCrossImageProvider extends ImageProvider {
      constructor();
      public handle: number;
      /**
      * @brief Set image file's URI
      * @param uri current side's image URI
      */
      public setImageUri(uri: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief 6 side image provider for a cubemap
    */
    class CubeImageProvider extends ImageProvider {
      constructor();
      public handle: number;
      /**
      * @brief Set image file's URI
      * @param texType texture type, sepcify which side of a cubemap
      * @param uri current side's image URI
      */
      public setImageUri(texType: CubeMapTexType, uri: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum CubeMapResolution {
      16,
      32,
      64,
      128,
      256,
      512,
      1024,
      2048,
    }
    namespace CubeMapResolution {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Texture type in a texture cube
    */
    enum CubeMapTexType {
      /**
      * < POSITIVE_X
      */
      POSITIVE_X,
      /**
      * < NEGATIVE_X
      */
      NEGATIVE_X,
      /**
      * < POSITIVE_Y
      */
      POSITIVE_Y,
      /**
      * < NEGATIVE_Y
      */
      NEGATIVE_Y,
      /**
      * < POSITIVE_Z
      */
      POSITIVE_Z,
      /**
      * < NEGATIVE_Z
      */
      NEGATIVE_Z,
    }
    namespace CubeMapTexType {
      let RTTI: RTTIDescriptor;
    }
    enum CullFace {
      NONE,
      FRONT,
      BACK,
      FRONT_AND_BACK,
    }
    namespace CullFace {
      let RTTI: RTTIDescriptor;
    }
    class CullingResults extends AObject {
      constructor();
      public rt: RenderTexture;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum CurrentPage {
      NONE,
      LIVE,
      PREVIEW,
    }
    namespace CurrentPage {
      let RTTI: RTTIDescriptor;
    }
    class CurveInfo extends AObject {
      constructor();
      public curveType: CurveType;
      public curvePointsNum: number;
      public curveAngle: number;
      public arcCurveLength: number;
      public curveOffset: number;
      public curvePoints: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief General option for texture generation
    */
    class CurveOption extends AObject {
      constructor();
      public type: MeshCurve;
      public numSegments: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum CurveType {
      LINE,
      ARC,
      QUADRATIC_BEZIER,
      CUBIC_BEZIER,
    }
    namespace CurveType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine CustomDataAffector
    * update particle's custom data
    */
    class CustomDataAffector extends Affector {
      constructor();
      /**
      * @brief Scale X Getter
      * @return Value*  Scale X
      */
      public customData1X: Value;
      /**
      * @brief Scale X Getter
      * @return Value*  Scale X
      */
      public customData1Y: Value;
      /**
      * @brief Scale X Getter
      * @return Value*  Scale X
      */
      public customData1Z: Value;
      /**
      * @brief Scale X Getter
      * @return Value*  Scale X
      */
      public customData1W: Value;
      /**
      * @brief Scale X Getter
      * @return Value*  Scale X
      */
      public customData2X: Value;
      /**
      * @brief Scale X Getter
      * @return Value*  Scale X
      */
      public customData2Y: Value;
      /**
      * @brief Scale X Getter
      * @return Value*  Scale X
      */
      public customData2Z: Value;
      /**
      * @brief Scale X Getter
      * @return Value*  Scale X
      */
      public customData2W: Value;
      /**
      * @brief useTimeToDeath Getter
      * @return bool useTimeToDeath
      */
      public useTimeToDeath: boolean;
      /**
      * @brief useTimeToDeath Getter
      * @return bool useTimeToDeath
      */
      public useTimeToLive: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum DataType {
      Invalid,
      U8norm,
      S8norm,
      U8,
      S8,
      U16norm,
      S16norm,
      U16,
      /**
      * U32norm,
      */
      S16,
      U32,
      /**
      * U64,
      */
      S32,
      F16,
      /**
      * F64,
      */
      F32,
    }
    namespace DataType {
      let RTTI: RTTIDescriptor;
    }
    enum DeformationType {
      ARAP,
      LaplacianAdvanced,
    }
    namespace DeformationType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief depth stencil state
    */
    class DepthStencilState extends AObject {
      constructor();
      /**
      * @brief set depth test enable
      * @param depthTestEnable bool
      */
      public depthTestEnable: boolean;
      /**
      * @brief depth test enable name
      */
      public depthTestEnableName: string;
      /**
      * @brief set depth compare op
      * @param depthCompareOp AMGCompareOp
      */
      public depthCompareOp: CompareOp;
      /**
      * @brief depth compare op name
      */
      public depthCompareOpName: string;
      /**
      * @brief set depth write enable
      * @param depthWriteEnable bool
      */
      public depthWriteEnable: boolean;
      /**
      * @brief set stencil test enable
      * @param stencilTestEnable bool
      */
      public stencilTestEnable: boolean;
      /**
      * @brief stencil test enable name
      */
      public stencilTestEnableName: string;
      /**
      * @brief set stencil front
      * @param _stencilFront StencilOpState
      */
      public stencilFront: StencilOpState;
      /**
      * @brief set tencil back
      * @param _stencilBack StencilOpState
      */
      public stencilBack: StencilOpState;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief The orientation of device. It's clockwise.
    */
    enum DeviceOrientation {
      /**
      * The device is in portrait mode, with the device held upright and the home button on the bottom.
      */
      PORTRAIT,
      /**
      * The device is in landscape mode, with the device held upright and the Home button on the right side.
      */
      LANDSCAPE_LEFT,
      /**
      * The device is in portrait mode but upside down, with the device held upright and the home button at the top.
      */
      PORTRAIT_UPSIDE_DOWN,
      /**
      * The device is in landscape mode, with the device held upright and the Home button on the left side.
      */
      LANDSCAPE_RIGHT,
    }
    namespace DeviceOrientation {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief The rotation of device.
    */
    class DeviceRotation extends AObject {
      constructor();
      /**
      * @brief The rotatation in quaternion.
      */
      public quat: Quaternionf;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class DeviceSensorAgentWrapper extends DeviceSensorHub {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Interface of Device Sensor Hub
    */
    class DeviceSensorHub extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief Enable or disable a kind of sensor
      */
      public setSensorEnabled(arg0: SensorType, arg1: boolean): void;
      /**
      * @brief Get gravity sensor data with specific timestamp
      */
      public getGravityData(arg0: SensorDataSpace): Vector3f;
      /**
      * @brief get acceleration sensor data with specific timestamp
      */
      public getAccelerationData(arg0: SensorDataSpace): Vector3f;
      /**
      * @brief get gyro sensor data with specific timestamp
      */
      public getGyroData(arg0: SensorDataSpace): Vector3f;
      /**
      * @brief get rotation sensor data with specific timestamp
      */
      public getRotationData(arg0: SensorDataSpace): Quaternionf;
      /**
      * @brief get geomagnetic sensor data with specific timestamp
      */
      public getGeomagneticData(arg0: SensorDataSpace): Vector3f;
      /**
      * @brief get compass heading sensor data with specific timestamp
      */
      public getHeadingData(): number;
      /**
      * @brief get filtered rotation sensor data with specific timestamp
      */
      public getFilteredCameraRotation(): Quaternionf;
      /**
      * @brief set sensor data refresh rate
      */
      public setRefreshRate(arg0: SensorType, arg1: number): void;
      /**
      * @brief enable or disable sensor filter
      * @param enabled , true is enable, false is disable
      */
      public setSensorFilterEnabled(arg0: boolean): void;
      /**
      * @brief get gravity vector, with specific g
      */
      public getGravityVector(arg0: number): Vector3f;
      /**
      * @brief update entities's rigid body 3D gravity vector
      * @param recursive  whether should recurisve set
      * @param gravity signed gravity in y axis
      */
      public updateRigidBody3DGravity(arg0: Entity, arg1: boolean, arg2: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of DirectionalLight.
    */
    class DirectionalLight extends Light {
      constructor();
      /**
      * @brief get current Directionallight's CookieSize
      * @return float m_cookieSize
      */
      public cookieSize: number;
      public softShadowType: SoftShadowType;
      public EVSMExponents: Vector2f;
      public contactShadowEnable: boolean;
      /**
      * @brief get light unit
      * @return lightunit
      */
      public lightUnit: LightUnit;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class DownloadTask extends AObject {
      constructor();
      public status: JsDownloadStatus;
      public success: boolean;
      public errCode: number;
      public errString: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief DrawTexture draw texture
    */
    class DrawTexture extends Texture {
      constructor();
      /**
      * @brief Set rt's color format with dirty check
      * @param colorFormat color format
      */
      public colorFormat: PixelFormat;
      public realColorFormat: PixelFormat;
      public isReadable: boolean;
      public MSAAMode: MSAAMode;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class DrawingSettings extends AObject {
      constructor();
      public overrideMaterial: Material;
      public overrideMaterialPassIndex: number;
      public sortingSettings: SortingSettings;
      public isSpecShaderPass: boolean;
      public shaderPassName: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class DynamicComponent extends Component {
      constructor();
      public className: string;
      public ref: any;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief dynamic joint
    */
    class DynamicJoint extends Component {
      constructor();
      /**
      * @brief get damping ratio
      * @return Value* ratio
      */
      public damping: Value;
      /**
      * @brief get elasticity
      * @return Value* elasticity
      */
      public elasticity: Value;
      /**
      * @brief get stiffness
      * @return Value* stiffness
      */
      public stiffness: Value;
      /**
      * @brief get inertia
      * @return Value*
      */
      public inert: Value;
      /**
      * @brief get joint collider radius
      * @return Value*
      */
      public radius: Value;
      /**
      * @brief get external force
      * @return const Vector3f&
      */
      public force: Vector3f;
      /**
      * @brief get whether external force is represented in local space
      * @return const bool
      */
      public isLocalForce: boolean;
      /**
      * @brief get collider list
      * @return const Vector&
      */
      public colliderList: Vector;
      public handle: number;
      public resetMomentum(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief dynamic joint collider comp
    */
    class DynamicJointCollider extends Component {
      constructor();
      /**
      * @brief get center of collider
      * @return const Vector3f&
      */
      public center: Vector3f;
      /**
      * @brief get radius of cylinder
      * @return float
      */
      public radius: number;
      /**
      * @brief get height of cylinder
      * @return float
      */
      public height: number;
      /**
      * @brief get orientation of cylinder
      * @return AMGCollideDirection
      */
      public direction: CollideDirection;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum EaseType {
      linear,
      quadIn,
      quadOut,
      quadInOut,
      quadOutIn,
      CubicIn,
      CubicOut,
      CubicInOut,
      CubicOutIn,
      QuarticIn,
      QuarticOut,
      QuarticInOut,
      QuarticOutIn,
      QuinticIn,
      QuinticOut,
      QuinticInOut,
      QuinticOutIn,
      SinIn,
      SinOut,
      SinInOut,
      SinOutIn,
      ExponentitalIn,
      ExponentitalOut,
      ExponentitalInOut,
      ExponentitalOutIn,
      CircularIn,
      CircularOut,
      CircularInOut,
      CircularOutIn,
      ElasticIn,
      ElasticOut,
      ElasticInOut,
      ElasticOutIn,
      OvershootIn,
      OvershootOut,
      OvershootInOut,
      OvershootOutIn,
      BounceIn,
      BounceOut,
      BounceInOut,
      BounceOutIn,
      Floor,
      Ceil,
    }
    namespace EaseType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief edge shape collider
    */
    class EdgeCollider2D extends Collider2D {
      constructor();
      /**
      * @brief Set the Points data of edge
      * @param points points
      */
      public points: Vec2Vector;
      /**
      * @brief Set the Edge Radius
      * @param radius radius
      */
      public edgeRadius: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectAnimSeq extends AnimSeqComponent {
      constructor();
      public handle: number;
      public setAnimationEnd(animationEnd: boolean): void;
      public setVisible(visible: boolean): void;
      public isVisible(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectAudioComp extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectColorCurved extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceBrowLiquify extends EffectFaceMakeup {
      constructor();
      public BrowLiquifyWarpMesh: Mesh;
      public BrowLiquifyWarpEntityName: string;
      public browLiquifyWarpEntity: Entity;
      public BrowLiquifySucaiMesh: Mesh;
      public BrowLiquifySucaiEntityName: string;
      public browLiquifySucaiEntity: Entity;
      public leftPoints: Vec2Vector;
      public rightPoints: Vec2Vector;
      public warpRenderer: Renderer;
      public sucaiRenderer: Renderer;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceBrowV2 extends EffectFaceMakeup {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceEyeDetail extends EffectFaceMakeup {
      constructor();
      public BlurVEntityName: string;
      public BlurHEntityName: string;
      public BlurVerticalEntity: Entity;
      public blurVerticalRenderer: Renderer;
      public blurHorizotalRenderer: Renderer;
      public BlurHorizontalEntity: Entity;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceJieMaoV1 extends EffectFaceMakeup {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceLipV2 extends EffectFaceMakeup {
      constructor();
      public mouth_color: Vec4Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceLipV3 extends EffectFaceMakeup {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceLipV4 extends EffectFaceMakeup {
      constructor();
      public LipV4GlossMesh: Mesh;
      public LipV4GlossEntityName: string;
      public lipv4GlossEntity: Entity;
      public glossRenderer: Renderer;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief FaceMakeup Component
    * 1. update face mesh for meshrenderer
    * 2. stop rendering with invalid intensity
    * 3. rt-pingpong
    * 4. effectsdk anim processor
    */
    class EffectFaceMakeup extends Component {
      constructor();
      public type: EffectFaceMakeupType;
      public templateMesh: Mesh;
      public templateMaterials: Vector;
      public dynamicRenderChain: boolean;
      public makeupEntity: Entity;
      public faceIds: UInt8Vector;
      public renderer: Renderer;
      public facemakeupEntityName: string;
      public zPosition: number;
      public triggerLua: boolean;
      public version: number;
      public sdkType: number;
      public useVideoTexture: boolean;
      public useSegment: boolean;
      public skipZeroOpacity: boolean;
      public componentVersion: number;
      public intensity: number;
      public maleOpacity: number;
      public femaleOpacity: number;
      public handle: number;
      /**
      * @brief set unform for one face
      *
      * @param uniform_name uniform name
      * @param faceID face index
      * @param val uniform value
      */
      public setFaceUniform(uniform: string, face: number, value: number): void;
      /**
      * @brief set unform for all faces
      *
      * @param uniform_name uniform name
      * @param val uniform value
      */
      public setUniform(uniform: string, value: number): void;
      public setUniformInt(uniform: string, value: number): void;
      public setUniformVec4(uniform: string, value: Vector4f): void;
      public setUniformMat4(uniform: string, value: Matrix4x4f): void;
      public setUniformTex(uniform: string, value: Texture): void;
      public getUniformFloat(uniform: string): number;
      public getUniformVec4(arg0: string): Vector4f;
      /**
      * @brief init entity and renderer from scene
      *
      */
      public onInit(): void;
      public hide(): boolean;
      public show(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceMakeupFaceU extends EffectFaceMakeup {
      constructor();
      public xoffset: number;
      public yoffset: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceMakeupFaceUEyeDetail extends EffectFaceEyeDetail {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceMakeupFaceULipKeypoint extends EffectFaceMakeupFaceU {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFaceMakeupFaceUPupilV2 extends EffectFacePupilV2 {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum EffectFaceMakeupType {
      INPUT,
      OUTPUT,
      NONE,
      LIPS_SEG,
      MASK,
      MASK240,
      LIPS_KEYPOINT,
      TEETH,
      BROW,
      POINTS,
      EYE_PART,
      EYE_PART_DENSE,
      PUPIL,
      MOUTH_PART,
      LIPS_V2,
      LIPS_V3,
      LIPS_V4,
      MASK3D,
      JIEMAO_V1,
      JIEMAO_V2,
      EYE_DETAIL,
      FACEU_MASK,
      FACEU_LIPS_KEYPOINT,
      FACEU_JIEMAO,
      FACEU_BROW,
      FACEU_EYEPART,
      FACEU_EYEDETAIL,
      FACEU_PUPIL,
      SKIN_TONE,
    }
    namespace EffectFaceMakeupType {
      let RTTI: RTTIDescriptor;
    }
    class EffectFaceMouthPart extends EffectFaceMakeup {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectFacePupilV2 extends EffectFaceMakeup {
      constructor();
      public PupilMesh: Mesh;
      public PupilMaterials: Vector;
      public PupilEntityName: string;
      public pupilCutoffEntity: Entity;
      public cutoffRenderer: Renderer;
      public useEyepartMesh: boolean;
      public handle: number;
      public setCutOffUniformTex(uniform: string, value: Texture): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectHolder extends Component {
      constructor();
      public featurePaths: Vector;
      public handle: number;
      public getFeature(relPath: string): FeatureType;
      public asFeature(): boolean;
      public getFeatureLuaPath(): string;
      public getFeaturePathSize(): number;
      public getAllFeaturePaths(): Vector;
      public getAllFeatureLuaPaths(): Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief every EffectLayer must have the basic grad. it can have 3 outlines and 1 inline at most.
    * @deprecated may be removed in the future
    */
    class EffectLayer extends AObject {
      constructor();
      /**
      * < shared material
      */
      public mat: Material;
      /**
      * < material instance
      */
      public mat_instance: Material;
      /**
      * < inline
      */
      public inline1Grad: GradientChange;
      /**
      * < basic text
      */
      public grad: GradientChange;
      /**
      * < outline1
      */
      public outline1Grad: GradientChange;
      /**
      * < outline2
      */
      public outline2Grad: GradientChange;
      /**
      * < outline3
      */
      public outline3Grad: GradientChange;
      /**
      * < smoothing for this EffectLayer, usually for shadow
      */
      public smoothing: number;
      /**
      * < offset for this EffectLayer
      */
      public offset: Vector2f;
      /**
      * < enable inner shadow
      */
      public innerShadowEnabled: boolean;
      /**
      * < texture will take effect through which outline
      */
      public textureLevel: number;
      /**
      * < texture
      */
      public texture: Texture;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectLightSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectLineBuildParams extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief EffectLineBuilder
    * it is used to fill line mesh with params
    * the EffectLineBuilder object has linebuilderparams collection contains
    */
    class EffectLineBuilder extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief Set line control points
      * @return
      */
      public SetLinePosition(positionList: Vec3Vector): void;
      /**
      * @brief Set line corner
      * @return
      */
      public SetLineCornerVertices(countCornerVertice: number): void;
      /**
      * @brief Set Line Is Open Loop Control Point
      * @return
      */
      public SetLineLoop(isLoop: boolean): void;
      /**
      * @brief Set Line Align Type
      * @return
      */
      public SetLineAlignType(alignType: number): void;
      /**
      * @brief Set Curvy Type with LineWidth
      * `1:Line   2:CATMULL   3:SPLINE
      * @return
      */
      public SetLineWidthCurvyType(curvyType: number): void;
      /**
      * @brief Set Curvy Type with LineColor
      * `1:Line   2:CATMULL   3:SPLINE
      * @return
      */
      public SetLineColorCurvyType(curvyType: number): void;
      /**
      * @brief Set Line Width With length/total  of line
      * @return
      */
      public SetLineWidth(length: number, value: number): void;
      /**
      * @brief clear Line‘s Width  with pValue
      * @return
      */
      public ClearLineWidth(value: number): void;
      /**
      * @brief set  Line Color With length/total  of line
      * @return*/
      public SetLineColor(length: number, value: Vector4f): void;
      /**
      * @brief clear Line‘s Color  with pValue
      * @return
      */
      public ClearLineColor(value: Vector4f): void;
      /**
      * @brief Set  the LineConstuctParams width
      * @return
      */
      public SetLineConstuctParamsWidth(lineWidth: ValueCurved): void;
      /**
      * @brief Open Or Close UVExtendProperty: UV2 and UV3
      * @return
      */
      public SetOpenUVExtendProperty(isOpenExtend: boolean): void;
      /**
      * @brief Set  the LineConstuctParams Color
      * @return
      */
      public SetLineConstuctParamsColor(lineColorR: ValueCurved, lineColorG: ValueCurved, lineColorB: ValueCurved, lineColorA: ValueCurved): void;
      /**
      * @brief fill the mesh vertex and indic data
      * @return
      */
      public FillMesh(mesh: Mesh): void;
      /**
      * @brief init defalut mesh
      * @return
      */
      public InitDefaultMesh(mesh: Mesh): void;
      /**
      * @brief fill the mesh vertex and indic data with align camera
      * @return
      */
      public FillMeshWithAlignCamera(mesh: Mesh, camera: Camera): void;
      /**
      * @brief clear the mesh vertex and indic
      * @return
      */
      public ClearMesh(mesh: Mesh): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectListenerComp extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectNode extends Component {
      constructor();
      public defaultInput: RenderTexture;
      public inputTextures: Vector;
      public outputTextures: Vector;
      public renderOrder: number;
      public minorOrder: number;
      public type: EffectNodeTag;
      public version: number;
      public rendererType: RendererType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum EffectNodeEvent {
      BEFORE_RENDER,
      AFTER_RENDER,
    }
    namespace EffectNodeEvent {
      let RTTI: RTTIDescriptor;
    }
    class EffectNodeExclusion extends Component {
      constructor();
      public groupId: number;
      public sceneKey: string;
      public priority: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EffectNodeSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum EffectNodeTag {
      Null,
      GAN,
      Filter,
      FaceMakeup,
      FaceDeformation,
      Other,
    }
    namespace EffectNodeTag {
      let RTTI: RTTIDescriptor;
    }
    class EffectReadyResult extends AlgorithmResultEvent {
      constructor();
      public type: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Effect Text Param
    */
    class EffectTextParam extends AObject {
      constructor();
      /**
      * < version
      */
      public version: number;
      /**
      * @brief set effectTextParam mainColor
      * @param color rgba color
      */
      public textColor: Color;
      /**
      * < outline max width, unit is percent of line height
      */
      public outlineMaxWidth: number;
      /**
      * @brief set random grid size for texture
      * @param size vector2f width x height
      */
      public randomGridSize: Vector2f;
      /**
      * < Effect Layers
      */
      public effectLayers: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine Particle Emitter Base Class
    */
    class Emitter extends AObject {
      constructor();
      /**
      * @brief Emitter position getter
      * @return const Vector3f& pos
      */
      public position: Vector3f;
      /**
      * @brief Emitter rotation getter
      * @return const Quaternionf& rotation
      */
      public rotation: Quaternionf;
      /**
      * @brief isEnabled
      * @return bool isEnabled
      */
      public enable: boolean;
      /**
      * @brief Whether emitted particle position is moved by particle component position
      * @return bool isKeep: true/false
      */
      public keepLocalParticles: boolean;
      /**
      * @brief Emitter forceEmission getter
      * @return bool
      */
      public forceEmission: boolean;
      public useDurationTime: boolean;
      /**
      * @brief Emitter angle getter
      * @return Value*
      */
      public angle: Value;
      /**
      * @brief Emitter emission rate getter
      * @return Value*
      */
      public emissionRate: Value;
      /**
      * @brief Emitter totalTimeToLive rate getter
      * @return Value*
      */
      public totalTimeToLive: Value;
      /**
      * @brief Emitter duration getter
      * @return Value*
      */
      public duration: Value;
      /**
      * @brief Emitter repeatDelay getter
      * @return Value*
      */
      public repeatDelay: Value;
      /**
      * @brief Emitter mass getter
      * @return Value*
      */
      public particleMass: Value;
      /**
      * @brief Emitter velocity getter
      * @return Value*
      */
      public particleVelocity: Value;
      /**
      * @brief Emitter colList getter
      * @return const Vec4Vector&
      */
      public particleColorList: Vec4Vector;
      /**
      * @brief Emitter color getter
      * @return const Vector4f&
      */
      public particleColor: Vector4f;
      /**
      * @brief Emitter burList getter
      * @return Vec3Vector&
      */
      public particleBurstsList: Vec2Vector;
      public orientationStart: Quaternionf;
      public orientationEnd: Quaternionf;
      /**
      * @brief Emitter width getter
      * @return Value*
      */
      public particleWidth: Value;
      /**
      * @brief Emitter height getter
      * @return Value*
      */
      public particleHeight: Value;
      /**
      * @brief Emitter depth getter
      * @return Value*
      */
      public particleDepth: Value;
      /**
      * @brief Emitter scale getter
      * @return Value*
      */
      public particleScale: Value;
      /**
      * @brief Emitter size getter
      * @return Value*
      */
      public particleSize: Value;
      /**
      * @brief Emitter x rotation getter
      * @return Value*
      */
      public particleXRotation: Value;
      /**
      * @brief Emitter y rotation getter
      * @return Value*
      */
      public particleYRotation: Value;
      /**
      * @brief Emitter z rotation getter
      * @return Value*
      */
      public particleZRotation: Value;
      /**
      * @brief Emitter x rotation speed getter
      * @return Value*
      */
      public particleXRotationSpeed: Value;
      /**
      * @brief Emitter y rotation speed getter
      * @return Value*
      */
      public particleYRotationSpeed: Value;
      /**
      * @brief Emitter z rotationspeed getter
      * @return Value*
      */
      public particleZRotationSpeed: Value;
      /**
      * @brief Emitter alignToDirection getter
      * @return bool
      */
      public alignToDirection: boolean;
      /**
      * @brief Emitter randomDirection getter
      * @return Value*
      */
      public RandomDirection: Value;
      /**
      * @brief Emitter sphereDirection getter
      * @return Value*
      */
      public SphereDirection: Value;
      /**
      * @brief Emitter randomPosition getter
      * @return Value*
      */
      public RandomPosition: Value;
      /**
      * @brief Emitter distance emission rate getter
      * @return Value*
      */
      public distanceEmissionRate: Value;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief entity base
    *
    */
    class Entity extends AObject {
      constructor();
      /**
      * @brief set scene that entity belong to
      * @param s scene
      */
      public scene: Scene;
      /**
      * @brief get entity visible itself
      *
      * @return true
      * @return false
      */
      public selfvisible: boolean;
      /**
      * @brief get entity visible after all
      *
      * @return true
      * @return false
      */
      public visible: boolean;
      public tag: number;
      public components: Vector;
      public layer: number;
      /**
      * @brief Set prefab
      * @param prefab prefab
      */
      public prefab: Prefab;
      /**
      * @brief Set prefab object GUID
      * @param guid prefab object guid
      */
      public prefabObjectGuid: Guid;
      public handle: number;
      /**
      * @brief add tag to entity
      * @param tag tag
      */
      public addTag(tag: number): void;
      /**
      * @brief get whether entity has the tag
      * @param tag tag
      * @return bool result
      */
      public hasTag(tag: number): boolean;
      /**
      * @brief add component by type to entity
      * @param rttiType component
      * @return Component* component
      */
      public addComponent(rttiType: string): Component;
      public addJsScriptComponent(codePath: string): Component;
      /**
      * @brief remove component by type to entity
      * @param rttiType component
      * @return bool result
      */
      public removeComponent(rttiType: string): boolean;
      /**
      * @brief get component by rrti type
      *
      * @param rttiType rtti type
      * @return Component*
      */
      public getComponent(rttiType: string): Component;
      /**
      * @brief get all components by rtti type
      *
      * @param rttiType rtti type
      * @return const Vector&
      */
      public getComponents(rttiType: string): Vector;
      /**
      * @brief get all components by rtti type in entity sub tree
      * @param rttiType rtti type
      * @return Vector
      */
      public getComponentsRecursive(rttiType: string): Vector;
      /**
      * @brief get entity by name
      * @param name entity name
      * @return Entity* entity
      */
      public searchEntity(name: string): Entity;
      /**
      * @brief clone component from other componet
      *
      * @param other component
      * @return Component* component
      */
      public cloneComponentOf(comp: Component): Component;
      public removeComponentCom(comp: Component): boolean;
      public addLocatedComponent(rttiType: string, pos: number): Component;
      public addComponentAt(component: Component, pos: number): Component;
      public removeComponentAt(pos: number): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EntityGroup extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EntityGroupManager extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EntityGroups extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Entity Override.
    */
    class EntityOverride extends PrefabOverride {
      constructor();
      public entityOverrideType: EntityOverrideType;
      /**
      * @brief get Added Entity.
      * @return SharePtr<Entity> m_addedEntity.
      */
      public addEntity: Entity;
      public modifyProperties: Map;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief EntityOverrideType
    */
    enum EntityOverrideType {
      Add,
      Modify,
      Remove,
    }
    namespace EntityOverrideType {
      let RTTI: RTTIDescriptor;
    }
    enum EntityRotateType {
      ROTATE_DISABLE,
      ROTATE_AROUND_Z_AXIS,
      ROTATE_AROUND_XYZ_AXIS,
    }
    namespace EntityRotateType {
      let RTTI: RTTIDescriptor;
    }
    class Envmap extends Component {
      constructor();
      public diffuseEnvmap: TextureCube;
      public coefficients: FloatVector;
      public envmapLayers: DynamicBitset;
      public specularEnvmap: TextureCube;
      public IBLMode: boolean;
      public intensity: number;
      public rotation: number;
      public specularEnvmapDefault: TextureCube;
      public diffuseEnvmapDefault: TextureCube;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief event class in Amazing engine
    */
    class Event extends AObject {
      constructor();
      /**
      * @brief event type. See AMGEventType and AppEventType
      */
      public type: number;
      /**
      * @brief argument vector
      */
      public args: Vector;
      /**
      * @brief component argument
      */
      public component: Component;
      /**
      * @brief priority of the event
      */
      public priority: EventPriority;
      /**
      * @brief whether the event is handled
      */
      public isHandled: boolean;
      /**
      * @brief sending source of this event
      */
      public eventSource: EventSource;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EventActionSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class EventCenter extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief process priority of event
    */
    enum EventPriority {
      /**
      * @brief low priority
      */
      LOW,
      /**
      * @brief normal priority
      */
      NORMAL,
      /**
      * @brief high priority
      */
      HIGH,
    }
    namespace EventPriority {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief sending source of event
    */
    enum EventSource {}
    namespace EventSource {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief System for queuing and distribute events
    */
    class EventSystem extends System {
      constructor();
      public handle: number;
      /**
      * @brief post event, event will be processed during next EventSystem's update
      * @param event event to be posted
      */
      public postEvent(event: Event): void;
      /**
      * @brief send event, event will be processed immediately
      * @param event event to be sent
      */
      public sendEvent(event: Event): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief event type
    */
    enum EventType {
      /**
      * @brief 1.AMGTouchEventType 2.LATEST_COORD(Vec2Vector) 3.COORD(Vec2Vector) 4.Camera*
      */
      TOUCH,
      /**
      * @brief 1.AMGViewerEventType 2.Viewer*
      */
      VIEWER,
      /**
      * @brief 1.Vector2f 2.Camera*
      */
      CLICK,
      /**
      * @brief 1.PAN(Vector3f) 2.FACTOR(float) 3.Camera*
      */
      PAN,
      /**
      * @brief 1.ROTATION(Vector3f) 2.FACTOR(float) 3.Camera*
      */
      ROTATION,
      /**
      * @brief 1.SCALE(Vector3f) 2.FACTOR(float) 3.Camera*
      */
      SCALE,
      /**
      * @brief 1.KeyboardEventType 2.KeyboardSymbol 3.MOD_KEY_SYMBOL
      */
      KEYBOARD,
      /**
      * @brief 1.MouseEventType 2.MouseSymbol 3.COORD(Vector2f) 4.WHEEL_VALUE(float) 5.Camera*
      */
      MOUSE,
      /**
      * @brief 1.AMGSensorEventType 2.ATTITUDE(Quaternionf)
      */
      SENSOR,
      /**
      * @brief tracker
      */
      TRACKER,
      /**
      * @brief 1.Begin Collision 2. End Collision
      */
      COLLISION,
      /**
      * @brief 1.Begin Collision 2. End Collision
      */
      COLLISION3D,
      /**
      * @brief deprecated touch event ...
      */
      TOUCH_DEPRECATED,
      /**
      * @brief deprecated touch event ...
      */
      TOUCH_MANIPULATE,
      /**
      * @brief touch UI
      */
      TOUCH_UI,
      /**
      * @brief Geometry module
      */
      GEOMETRY,
      /**
      * @brief Geometry module
      */
      AR_ANCHOR,
      RCVALUE_CHANGE,
      TOUCH_MANIPULATE_DUET,
      CLIENT_STATE_SWITCH,
    }
    namespace EventType {
      let RTTI: RTTIDescriptor;
    }
    enum ExclusiveType {
      ALL,
      ONLY_EXCLUDED,
    }
    namespace ExclusiveType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief external clip, for blending physics/IK or other external source with animation
    */
    class ExternalClip extends BaseClip {
      constructor();
      public handle: number;
      /**
      * @brief find the update property item by target name and property name
      * @param targetName the target entity name
      * @param propertyName the target property name
      * @return update property item
      */
      public getPropertyItem(targetName: string, propertyName: string): ExternalPropertyItem;
      /**
      * @brief register or get an update property item
      * @param targetName the target entity name
      * @param propertyName the target property name
      * @param dataType the track data type
      * @return update property item
      */
      public registerOrGetPropertyItem(targetName: string, propertyName: string, dataType: TrackDataType): ExternalPropertyItem;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief The property update item in external clip
    */
    class ExternalPropertyItem extends AObject {
      constructor();
      /**
      * @brief set value
      * @param value the setting value
      */
      public value: any;
      /**
      * @brief set the auto update status
      * @param autoUpdate the auto update flag
      */
      public autoUpdate: boolean;
      public handle: number;
      /**
      * @brief add an update function that copy property value from another property
      * @param sourceTargetName the source target name
      * @param sourcePropertyName the source property name
      * @param searchRoot the root entity of search the source target
      */
      public addSourcePropertyUpdater(sourceTargetName: string, sourcePropertyName: string, searchRoot: Entity): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ExternalTargetItem extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief FABRIK algorithm data component, running FABRIK solve
    */
    class FABRIK extends Component {
      constructor();
      /**
      * @brief get tip attached transform
      * @return Transform* target transform
      */
      public targetJoint: Transform;
      /**
      * @brief get position offset to target
      * @return const Vector3f& offset
      */
      public targetOffset: Vector3f;
      /**
      * @brief get root enitity name of IK chain
      * @return const std::string& name of root entity
      */
      public rootJoint: string;
      /**
      * @brief get blend weight of IK result
      * @return const float blend weight
      */
      public ikWeight: number;
      /**
      * @brief get max iteration count of algorithm
      * @return const int max iteration count
      */
      public maxIteration: number;
      /**
      * @brief get calculation precision
      * @return const float precision
      */
      public precision: number;
      /**
      * @brief get whether apply rotation limit to joint
      * @return const bool flag
      */
      public useRotationLimit: boolean;
      /**
      * @brief set target tip position, this'll work without target transform
      * @param position position
      */
      public ikPosition: Vector3f;
      public chainLength: number;
      public handle: number;
      public AddCollider(collider: DynamicJointCollider): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Face3DAccurateAttaching extends BehaviorComponent {
      constructor();
      public controlPointsIndices: Int32Vector;
      public constrainPointsIndices: Int32Vector;
      public targetFacesIndices: Int32Vector;
      public targetPointsCoords: FloatVector;
      public barycentricCoords: FloatVector;
      public laplacianWeight: number;
      public constrainWeight: number;
      public selectionWeight: number;
      public iteration: number;
      public isInit: boolean;
      public target: Transform;
      public deformationType: DeformationType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Face3DAccurateAttachingSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class Face3DMesh.
    */
    class Face3DMesh extends Mesh {
      constructor();
      /**
      * @brief set face index
      * @param faceID [in] face index
      */
      public faceid: number;
      /**
      * @brief Set the type of current Face3DMesh.
      * @param type The Face3DMesh type.
      */
      public type: Face3DMeshType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Face3D Mesh Type Enum.
    */
    enum Face3DMeshType {
      /**
      * @brief Face3d
      */
      FACE,
      /**
      * @brief Head3d
      */
      HEAD,
    }
    namespace Face3DMeshType {
      let RTTI: RTTIDescriptor;
    }
    class Face3DSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FaceAction {
      /**
      * eye blink, 
      */
      EYE_BLINK,
      /**
      * mouth open, 
      */
      MOUTH_AH,
      /**
      * shake head, 
      */
      HEAD_YAW,
      /**
      * nod, 
      */
      HEAD_PITCH,
      /**
      * wiggle eyebrow, 
      */
      BROW_JUMP,
      /**
      * 
      */
      MOUTH_POUT,
      /**
      * 
      */
      EYE_BLINK_LEFT,
      /**
      * 
      */
      EYE_BLINK_RIGHT,
      SIDE_NOD,
    }
    namespace FaceAction {
      let RTTI: RTTIDescriptor;
    }
    class FaceActionResult extends AlgorithmResultEvent {
      constructor();
      public faceIndex: number;
      public faceAction: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FaceAttrExpression {
      UNKNOWN,
      ANGRY,
      DISGUST,
      FEAR,
      HAPPY,
      SAD,
      SURPRISE,
      NEUTRAL,
    }
    namespace FaceAttrExpression {
      let RTTI: RTTIDescriptor;
    }
    enum FaceAttrGender {
      UNKNOWN,
      MALE,
      FEMALE,
    }
    namespace FaceAttrGender {
      let RTTI: RTTIDescriptor;
    }
    class FaceBackgroundFitting extends BehaviorComponent {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceBackgroundFittingSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceCapture extends Component {
      constructor();
      public faceid: number;
      public captureType: CaptureType;
      public captureVersion: CaptureVersion;
      public alignarray: Vec2Vector;
      public alignoffset: Vector2f;
      public alignz: number;
      public isGlobal: boolean;
      public useSceneCameraFov: boolean;
      public isPictureMode: boolean;
      public isFaceCaptureEnable: boolean;
      public calirateVersion: CalibrationType;
      public nearPlane: number;
      public farPlane: number;
      public useSceneCameraNearFar: boolean;
      public behaviorWhenTrackerDisappear: BehaviorWhenTrackerDisappear;
      public entityRotateType: EntityRotateType;
      public handle: number;
      public getProjectionMatrix(): Matrix4x4f;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceCaptureSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceFollowComponent extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceFollowSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FaceGanObjectType {
      UNDEFINED,
      LEFT_DOUBLE,
      LEFT_PLUMP,
      LEFT_DOUBLE_PLUMP,
      RIGHT_DOUBLE,
      RIGHT_PLUMP,
      RIGHT_DOUBLE_PLUMP,
      LEFT_CLASS_ONLY,
      RIGHT_CLASS_ONLY,
    }
    namespace FaceGanObjectType {
      let RTTI: RTTIDescriptor;
    }
    class FaceInsetMeshGenerator extends AObject {
      constructor();
      public handle: number;
      public setParams(uvScale: Vector2f, uvOffset: Vector2f, innBorderRad: number, outBorderRad: number, subdivCount: number, skipConvexHull: boolean): void;
      public generateInsetMesh(points_src: Vec2Vector, eyeDistance: number, width: number, height: number, faceRoll: number): boolean;
      public getVertices(): Vec3Vector;
      public getUvs(): Vec2Vector;
      public getAlphas(): Vec2Vector;
      public getIndices(): UInt32Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceInsetRenderer extends Renderer {
      constructor();
      public mesh: Mesh;
      public useExternalMesh: boolean;
      public type: string;
      public areaType: string;
      public whichId: number;
      public inputTexture: Texture;
      public inputTextureScale: Vector2f;
      public inputTextureUVOffset: Vector2f;
      public outBorderRad: number;
      public innBorderRad: number;
      public opacity: number;
      public blendMode: string;
      public fillColor: Color;
      public needOutline: boolean;
      public outlineColor: Color;
      public outlineThickness: number;
      public depthTest: boolean;
      public subdivCount: number;
      public insetParams: Map;
      public preDefinedData: Map;
      public handle: number;
      public setDirty(dirty: boolean): void;
      public isDirty(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceInsetRendererSystem extends RendererSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FaceLiquifyVersionType {
      V1,
      V2,
    }
    namespace FaceLiquifyVersionType {
      let RTTI: RTTIDescriptor;
    }
    class FaceMakeUp extends Component {
      constructor();
      public mesh: Mesh;
      public type: FaceMakeUpType;
      public useAppConfig: boolean;
      public faceIds: UInt8Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceMakeUpSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FaceMakeUpType {
      FACE2D,
      FACE3D,
      FACE3D_LANDMARK,
      EYE,
      EYELASH,
      PUPIL,
    }
    namespace FaceMakeUpType {
      let RTTI: RTTIDescriptor;
    }
    enum FaceMakeupMeshType {
      TT295,
      EYEPART,
      PUPIL,
      ST295,
      STEYEPART,
      STPUPIL,
      QUAD,
      FACE3D,
      FACE3DTITLE,
      FACE3DMOUSEEYES,
      FACE3D_LANDMARK,
      STEYELASH,
      DEFAULT,
    }
    namespace FaceMakeupMeshType {
      let RTTI: RTTIDescriptor;
    }
    class FaceMakeupV2EffectAnimSeq extends EffectAnimSeq {
      constructor();
      public entityName: string;
      public clipName: string;
      public handle: number;
      public setHideWhenPlayEnd(hide: boolean): void;
      public playFromTo(startIdx: number, endIdx: number, playMode: PlayMode, playCount: number, isVisible: boolean): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceMakeupV2System extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FacePetType {
      /**
      * <
      */
      CAT,
      /**
      * <
      */
      DOG,
      /**
      * < 
      */
      HUMAN,
      /**
      * < 
      */
      OTHERS,
    }
    namespace FacePetType {
      let RTTI: RTTIDescriptor;
    }
    class FaceReshape extends BehaviorComponent {
      constructor();
      public params: FaceReshapeParams;
      public faceids: UInt8Vector;
      public smooth_strip: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceReshapeLiquefy extends BehaviorComponent {
      constructor();
      public params: FaceReshapeLiquefyParams;
      public petparams: FaceReshapeLiquefyPetParams;
      public indices: string;
      public faceids: UInt8Vector;
      public intensityParams: FloatVector;
      public Type: FaceReshapeLiquefyType;
      public maskTexName: string;
      public version: FaceLiquifyVersionType;
      public loadParamsFromComp: boolean;
      public indicesInComp: UInt16Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceReshapeLiquefyParams extends AObject {
      constructor();
      public params: string;
      public withMask: boolean;
      public use_yaw_corr: boolean;
      public low_corr_yaw_value: number;
      public high_corr_yaw_value: number;
      public narrow_face_scale: number;
      public widen_face_scale: number;
      public high_scale: number;
      public mesh_cache_enable: boolean;
      public liquifyParamsInComp: FloatVector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FaceReshapeLiquefyPetMeshType {
      MULTI_MESH,
      FIXED_MESH,
      NONE_MESH,
    }
    namespace FaceReshapeLiquefyPetMeshType {
      let RTTI: RTTIDescriptor;
    }
    class FaceReshapeLiquefyPetParams extends AObject {
      constructor();
      public leftEarInterpData: Int16Vector;
      public rightEarInterpData: Int16Vector;
      public faceInterpData: Int16Vector;
      public leftEarIndicesData: UInt16Vector;
      public reftEarIndicesData: UInt16Vector;
      public faceIndicesData: UInt16Vector;
      public intensities: FloatVector;
      public liquefyParams: FloatVector;
      public useFaceMask: boolean;
      public useLeftEarMask: boolean;
      public useRightEarMask: boolean;
      public onlyStandEarValid: boolean;
      public meshType: FaceReshapeLiquefyPetMeshType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FaceReshapeLiquefyType {
      HUMAN,
      DOG,
      CAT,
    }
    namespace FaceReshapeLiquefyType {
      let RTTI: RTTIDescriptor;
    }
    class FaceReshapeParams extends AObject {
      constructor();
      public params: FloatVector;
      public degrees: FloatVector;
      public indices: UInt16Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceReshapeSystem extends System {
      constructor();
      public handle: number;
      public useFrustumCulling(arg0: boolean): void;
      public useFaceBound(arg0: boolean): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceStretchComponent extends Component {
      constructor();
      public T_P: Vec2Vector;
      public T_Q: Vec2Vector;
      public FaceId: number;
      public Intensity: number;
      public Type: FaceStretchType;
      public T_fpts: Vec2Vector;
      public T_w: number;
      public T_h: number;
      public indexSetValid: UInt16Vector;
      public curFace_P: Vec2Vector;
      public curFace_Q: Vec2Vector;
      public handle: number;
      public setDirty(dirty: boolean): void;
      public isDirty(): boolean;
      public isValid(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FaceStretchSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FaceStretchType {
      HUMAN,
      DOG,
      CAT,
    }
    namespace FaceStretchType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Faces Texture2D
    */
    class FacesTexture2D extends Texture2D {
      constructor();
      /**
      * @brief get face index
      * @return uint32_t face index
      */
      public faceIndex: number;
      /**
      * @brief get matrix name
      * @return std::string& matrix name
      */
      public matrixName: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FeatureNode extends EffectNode {
      constructor();
      public featureTag: string;
      public handle: number;
      public enableFeature(arg0: number, arg1: boolean): void;
      public getScene(): Scene;
      public getAMGScriptObject(): AObject;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FeatureNodeExclusion extends EffectNodeExclusion {
      constructor();
      public tagName: Vector;
      public composerKey: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FeatureType {
      FT_NONE,
      FT_3DV3,
      FT_2DV3,
    }
    namespace FeatureType {
      let RTTI: RTTIDescriptor;
    }
    class FilterControlComponent extends Component {
      constructor();
      public isFilter: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FilterControlSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FilterMipmapMode {
      NONE,
      NEAREST,
      LINEAR,
    }
    namespace FilterMipmapMode {
      let RTTI: RTTIDescriptor;
    }
    enum FilterMode {
      NEAREST,
      LINEAR,
    }
    namespace FilterMode {
      let RTTI: RTTIDescriptor;
    }
    class FilteringSettings extends AObject {
      constructor();
      public renderQueueRange: RenderQueueRange;
      public enableRenderLayers: boolean;
      public editorOnlyFlag: boolean;
      public handle: number;
      public setLayersWithVector(vector: Vector): void;
      public getLayersWithVector(): Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Import Flipbook for texture 3d
    */
    class FlipbookProvider extends ImageProvider {
      constructor();
      /**
      * @brief get m_rows
      * @return int the rows value
      */
      public rows: number;
      /**
      * @brief get m_cols
      * @return int value
      */
      public cols: number;
      public handle: number;
      /**
      * @brief set flipbook image uri
      * @param uri uri
      */
      public setImageUri(uri: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FloatValue extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Float curve value
    */
    class FloatValueCurved extends FloatValue {
      constructor();
      public iType: ValueCurveInterpolationType;
      public cpList: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Float fixed value
    */
    class FloatValueFixed extends FloatValue {
      constructor();
      public floatValue: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Float random value
    */
    class FloatValueRandom extends FloatValue {
      constructor();
      public minFloatValue: number;
      public maxFloatValue: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FlockCenteringAffector extends Affector {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class FollowManager extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FontDecorationType {
      NONE,
      UNDERLINE,
      OVERLINE,
      LINE_THROUGH,
    }
    namespace FontDecorationType {
      let RTTI: RTTIDescriptor;
    }
    enum FontStyle {
      NORMAL,
      BOLD,
      ITALIC,
      BOLD_ITALIC,
    }
    namespace FontStyle {
      let RTTI: RTTIDescriptor;
    }
    class FrameContext extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum FrontFace {
      COUNTER_CLOCKWISE,
      CLOCKWISE,
    }
    namespace FrontFace {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief PointJoint3D component
    */
    class GenericJoint3D extends Joint3D {
      constructor();
      /**
      * @brief get lower limit for linear translation
      * @return const Vector3f&
      */
      public linearLowerLimit: Vector3f;
      /**
      * @brief get upper limit for linear translation
      * @return const Vector3f&
      */
      public linearUpperLimit: Vector3f;
      /**
      * @brief get lower limit for angular rotation
      * @return const Vector3f&
      */
      public angularLowerLimit: Vector3f;
      /**
      * @brief get upper limit for angular rotation
      * @return const Vector3f&
      */
      public angularUpperLimit: Vector3f;
      /**
      * @brief get erp for the constraint
      * @return const float&
      */
      public erpLinear: number;
      /**
      * @brief get cfm for the constraint
      * @return const float&
      */
      public cfmLinear: number;
      /**
      * @brief get erp for the constraint
      * @return const float&
      */
      public erpAngular: number;
      /**
      * @brief get cfm for the constraint
      * @return const float&
      */
      public cfmAngular: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class GeometryMesh extends Mesh {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class GeometryProcessor extends AObject {
      constructor();
      public handle: number;
      public contourEvalNormals(arg0: ContourSet): void;
      public contourSample(arg0: ContourSet, arg1: ContourSamplingOption): Vec2Vector;
      public contourDecimation(arg0: ContourSet, arg1: ContourDecimationOption): ContourSet;
      public marchingSquares(arg0: Image): ContourSet;
      public meshSubdivision(arg0: TriMesh): TriMesh;
      public meshUVClip(arg0: TriMesh, arg1: Vector): TriMesh;
      public meshDecimation(arg0: TriMesh, arg1: MeshDecimationOption): TriMesh;
      public meshSmoothing(arg0: TriMesh, arg1: MeshSmoothingOption): void;
      public meshBand(arg0: ContourSet, arg1: MeshBandOption): TriMesh;
      public meshExtrusion(arg0: ContourSet, arg1: MeshExtrudeOption, arg2: Int32Vector, arg3: TriMesh): void;
      public meshMerge(arg0: Vector): TriMesh;
      public meshTransform(arg0: TriMesh, arg1: Matrix4x4f): void;
      public meshFracture(arg0: TriMesh, arg1: MeshFractureOption): Vector;
      public meshTriangulation(arg0: ContourSet, arg1: number): TriMesh;
      public meshTriangulationEx(arg0: ContourSet, arg1: Int32Vector, arg2: number): TriMesh;
      public genTexCoords(arg0: TriMesh, arg1: TextureOption): Vec2Vector;
      public genSmoothNormals(arg0: TriMesh): Vec3Vector;
      public toTriMesh(arg0: Mesh): TriMesh;
      public toMesh(arg0: TriMesh, arg1: number): Mesh;
      public toModel(arg0: Mesh, arg1: MeshSkeleton): Model;
      public imageToMeshAsync(arg0: Image, arg1: ImagePreprocessOption, arg2: MeshExtrudeOption, arg3: ContourDecimationOption): void;
      public imageToSkinnedMeshAsync(arg0: Image, arg1: ImagePreprocessOption, arg2: MeshExtrudeOption, arg3: ContourDecimationOption, arg4: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief This is a base class for all of Gesture type. It's generated by a gesture detected.
    */
    class Gesture extends AObject {
      constructor();
      /**
      * @brief The type of the gesture.
      */
      public type: GestureType;
      /**
      * @brief The time of the gesture generated.
      */
      public time: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief The Gesture Event
    */
    enum GestureEvent {
      ANY_SUPPORTED,
      GESTURE_TAP,
      GESTURE_SWIPE,
      GESTURE_PINCH,
      GESTURE_LONG_TAP,
      GESTURE_DRAG,
      GESTURE_DROP,
      GESTURE_DOUBLE_CLICK,
    }
    namespace GestureEvent {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief GestureInfo
    */
    class GestureInfo extends AObject {
      constructor();
      /**
      * @brief evt: the gesture type
      */
      public type: GestureEvent;
      /**
      * @brief x: the horizontal coordinate[0, 1] on screen associated with
      * this gesture
      */
      public x: number;
      /**
      * @brief y: the vertical coordinate[0, 1] on screen associated with
      * this gesture
      */
      public y: number;
      /**
      * @brief the horizontal coordinate[0,1] on screen for the start point
      */
      public xStart: number;
      /**
      * @brief the vertical coordinate[0,1] on screen for the start point
      */
      public yStart: number;
      /**
      * @brief the flag represents whether the gestureInfo is the first frame of the whole gesture
      */
      public firstTrigger: boolean;
      /**
      * @brief duration: gesture LONG_TAP & DRAG duration
      */
      public duration: number;
      /**
      * @brief scale: gesture PINCH scale
      */
      public scale: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class GestureRecognizer extends AObject {
      constructor();
      public gestureName: string;
      public userData: Map;
      public state: GestureRecognizerState;
      public handle: number;
      public implement(script: AObject, callback: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum GestureRecognizerState {
      Possible,
      Began,
      Changed,
      Ended,
      Cancelled,
      Failed,
    }
    namespace GestureRecognizerState {
      let RTTI: RTTIDescriptor;
    }
    class GestureSystem extends System {
      constructor();
      public handle: number;
      public subscribe(script: AObject, name: string, callback: string, priority: number): void;
      public unsubscribe(script: AObject, name: string, callback: string): void;
      public createRecognizer(name: string): GestureRecognizer;
      public removeRecognizer(name: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum GestureSystemListenerType {
      OnTouchGesture,
    }
    namespace GestureSystemListenerType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Device Gesture type
    */
    enum GestureType {
      CLICK,
      PAN,
      SCALE,
      ROTATE,
    }
    namespace GestureType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief gif animation component
    */
    class GifAnimSeq extends Component {
      constructor();
      /**
      * @brief get the relative path of the resource file (only for GIF)
      * @return const std::string& relative path
      */
      public giffilename: string;
      /**
      * @brief get Texture Sampler Name
      * @return const std::string& Texture Sampler name
      */
      public texName: string;
      /**
      * @brief get playback mode
      * @return AMGPlayMode playback mode
      */
      public playmode: PlayMode;
      /**
      * @brief get the number of cycles
      * @return float Cycles
      */
      public loopCount: number;
      /**
      * @brief get Play speed
      * @return float Play speed
      */
      public speed: number;
      /**
      * @brief get whether to play automatically
      * @return bool whether to play automatically
      */
      public autoplay: boolean;
      public handle: number;
      /**
      * @brief play
      */
      public play(): void;
      /**
      * @brief pause
      */
      public pause(): void;
      /**
      * @brief Stop, the animation will reset to the initial state, frame 0
      */
      public stop(): void;
      /**
      * @brief seek to a frame
      * @param index index
      */
      public seek(index: number): void;
      /**
      * @brief seek to a certain time
      * @param localTime time
      */
      public seekToTime(localTime: number): void;
      /**
      * @brief The animation is reset to the initial state, frame 0
      */
      public resetAnim(): void;
      /**
      * @brief get texture
      * @param index index
      * @return const SharePtr<Texture>&
      */
      public getOrCreateTexture(): Texture;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class GifAnimSeqSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class GifAsset extends AObject {
      constructor();
      public loadConfig: Map;
      public processMaterials: Map;
      public controller: GifController;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class GifController extends AObject {
      constructor();
      public scene: Scene;
      public handle: number;
      public gifInfo(): GifInfo;
      public seekFrame(index: number): Texture;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class GifInfo extends AObject {
      constructor();
      public width: number;
      public height: number;
      public duration: number;
      public framesNum: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief gradient color constitutes by at most 3 colors, you can adjust the gradient mode and gradient direction
    * @deprecated may be deprecated in the future
    */
    class GradientChange extends AObject {
      constructor();
      /**
      * < determin the outline's position int the text
      */
      public scale: number;
      /**
      * < the direction of gradient color
      */
      public angle: number;
      public gradient_type: GradientType;
      /**
      * < first color
      */
      public color1: ColorChange;
      /**
      * < the color change position between color1 and color2
      */
      public percent1_2: number;
      /**
      * < seconnd color
      */
      public color2: ColorChange;
      /**
      * < the color change position between color2 and color3
      */
      public percent2_3: number;
      /**
      * < third color
      */
      public color3: ColorChange;
      /**
      * < linear gradient change, change slowly
      */
      public linear: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum GradientType {
      WORD_GRADIENT,
      OVERALL_GRADIENT,
    }
    namespace GradientType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine GravityAffector
    * Not Really Gravity Function
    */
    class GravityAffector extends Affector {
      constructor();
      /**
      * @brief Gravity Factor Getter
      * @return Real Gravity
      */
      public gravity: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class GravitySensorAgent extends SensorAgent {
      constructor();
      public handle: number;
      public getData(): Vector3f;
      public isValidData(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class GyroSensorAgent extends SensorAgent {
      constructor();
      public handle: number;
      public getData(): Vector3f;
      public isValidData(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum HandAction {
      HEART_A,
      HEART_B,
      HEART_C,
      HEART_D,
      OK,
      HAND_OPEN,
      THUMB_UP,
      THUMB_DOWN,
      ROCK,
      NAMASTE,
      PLAM_UP,
      FIST,
      INDEX_FINGER_UP,
      DOUBLE_FINGER_UP,
      VICTORY,
      BIG_V,
      PHONECALL,
      BEG,
      THANKS,
      UNKNOWN,
      CABBAGE,
      THREE,
      FOUR,
      PISTOL,
      ROCK2,
      SWEAR,
      HOLDFACE,
      SALUTE,
      SPREAD,
      PRAY,
      QIGONG,
      SLIDE,
      PALM_DOWN,
      PISTOL2,
      NARUTO1,
      NARUTO2,
      NARUTO3,
      NARUTO4,
      NARUTO5,
      NARUTO7,
      NARUTO8,
      NARUTO9,
      NARUTO10,
      NARUTO11,
      NARUTO12,
      SPIDERMAN,
      AVENGERS,
      MAX_COUNT,
      /**
      * 
      */
      UNDETECT,
    }
    namespace HandAction {
      let RTTI: RTTIDescriptor;
    }
    class HandGestureResult extends AlgorithmResultEvent {
      constructor();
      public handIndex: number;
      public handAction: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class HandInfoResult extends AlgorithmResultEvent {
      constructor();
      public handle: number;
      public getHandKeyPoint(hand_index: number, point_index: number): HandKeyPoint;
      public getHandExtensionPoints(hand_index: number, point_index: number): HandKeyPoint;
      public getHandRect(hand_index: number): BEFRect;
      public getHandCount(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class HandKeyPoint extends AObject {
      constructor();
      public x: number;
      public y: number;
      public is_detect: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief hinge joint
    */
    class HingeJoint2D extends Joint2D {
      constructor();
      /**
      * @brief Set the Motorized
      * enable or disable motorized
      * @param motorized motorized
      */
      public motorized: boolean;
      /**
      * @brief Set the Motor Speed
      * the standard speed the motor want to keep
      * @param motorSpeed motor speed
      */
      public motorSpeed: number;
      /**
      * @brief Set the Motor Max Force
      * max torque the motor can provide, sometimes motor can't keep the standard
      * speed because torque has exceeded the max limit
      * @param maxForce max force
      */
      public motorMaxForce: number;
      /**
      * @brief enable or disable the Angle Limited
      * @param limited limited
      */
      public limited: boolean;
      /**
      * @brief Set the Lower Angle of limit
      * @param lowerLimit lower limit
      */
      public lowerLimit: number;
      /**
      * @brief Set the Upper Angle of limit
      * @param upperLimit upper limit
      */
      public upperLimit: number;
      /**
      * @brief set the reference angle
      * @param angle radian unit
      */
      public referenceAngle: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class HitEmptyPlaneResult extends AlgorithmResultEvent {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief HitInfo
    */
    class HitInfo extends AObject {
      constructor();
      /**
      * @brief hit point in the world
      */
      public point: Vector3f;
      /**
      * @brief distance from screen
      */
      public distance: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFAnchorAlignment extends Component {
      constructor();
      public pseudo3DType: IFPseudo3DType;
      public targetNum: number;
      public alignType: IFAnchorAlignmentType;
      public indexs1: Int32Vector;
      public weights1: FloatVector;
      public anchor1: Vector2f;
      public indexs2: Int32Vector;
      public weights2: FloatVector;
      public anchor2: Vector2f;
      public indexs3: Int32Vector;
      public weights3: FloatVector;
      public anchor3: Vector2f;
      public indexs4: Int32Vector;
      public weights4: FloatVector;
      public anchor4: Vector2f;
      public useScaleX: boolean;
      public scaleXStartIndex: number;
      public scaleXEndIndex: number;
      public scaleXFactor: number;
      public useScaleY: boolean;
      public scaleYStartIndex: number;
      public scaleYEndIndex: number;
      public scaleYFactor: number;
      public rotationType: IFRotationType;
      public rotation: number;
      public presetScale: Vector2f;
      public sendLocation: boolean;
      public arcAlign: boolean;
      public arcProportion: number;
      public trackOptions: IFAnchorAlignmentTrackOption;
      public IdorIndexNumber: Int32Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFAnchorAlignmentSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFAnchorAlignmentTrackOption {
      TrackWithTargetNum,
      TrackWithId,
      TrackWithIndex,
      TrackWithTrackId,
    }
    namespace IFAnchorAlignmentTrackOption {
      let RTTI: RTTIDescriptor;
    }
    enum IFAnchorAlignmentType {
      AlignOneAnchor,
      AlignTwoAnchor,
      AlignThreeAnchor,
      AlignFourAnchor,
    }
    namespace IFAnchorAlignmentType {
      let RTTI: RTTIDescriptor;
    }
    class IFAnimSpriteSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFBlendMode {
      Normal,
      Add,
      Average,
      Burn,
      Dodge,
      Darken,
      Difference,
      Exclusion,
      Glow,
      Hardlight,
      Hardmix,
      Lighten,
      Linearburn,
      Lineardodge,
      Linearlight,
      Multiply,
      Negation,
      Overlay,
      Phoenix,
      Pinlight,
      Reflect,
      Screen,
      Softlight,
      Substract,
      Vividlight,
      Snowcolor,
      Snowhue,
      EndFlag,
    }
    namespace IFBlendMode {
      let RTTI: RTTIDescriptor;
    }
    class IFBone2d extends Component {
      constructor();
      public enable: boolean;
      public indexes: Int32Vector;
      public meshVertices: Vec2Vector;
      public meshUV: Vec2Vector;
      public meshIndexes: UInt16Vector;
      public weights: Vector;
      public alpha: number;
      public templateVertices: Vec2Vector;
      public templateSize: Vector2f;
      public initPos: Vector2f;
      public initRotation: number;
      public initScale: Vector2f;
      public initShowSize: Vector2f;
      public initPivot: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFBoxCollider extends IFCollider {
      constructor();
      public center: Vector3f;
      public size: Vector3f;
      public pixelSize: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFCanvas2d extends BehaviorComponent {
      constructor();
      public resolutionType: IFResolutionType;
      public resolutionSize: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFCollider extends Component {
      constructor();
      public autoAdjustCollider: boolean;
      public autoAdjustByPixelSize: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFEventDistributor extends BehaviorComponent {
      constructor();
      public EventMask: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFFaceAnchorAlignment extends IFAnchorAlignment {
      constructor();
      public gender: IFGenderType;
      public useBorder: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFFilledType {
      Horizontal,
      Vertical,
      Radial,
    }
    namespace IFFilledType {
      let RTTI: RTTIDescriptor;
    }
    class IFForegroundAnchorAlignment extends IFAnchorAlignment {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFGenderType {
      None,
      Woman,
      Man,
    }
    namespace IFGenderType {
      let RTTI: RTTIDescriptor;
    }
    class IFHandAnchorAlignment extends IFAnchorAlignment {
      constructor();
      public useBorder: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFJointAnchorAlignment extends IFAnchorAlignment {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFLayer2d extends Renderer {
      constructor();
      public renderOrderMode: IFLayer2dRenderOrderMode;
      public blendMode: IFBlendMode;
      public blendAlpha: number;
      public blendAlphaCkeck: boolean;
      public drawCallNum: number;
      public maskType: IFMaskType;
      public inverted: boolean;
      public scissorRectMask: boolean;
      public updateFlag: boolean;
      public updateSortFlag: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFLayer2dRenderOrderMode {
      /**
      * Default, Auto UI Order, base Order >= 100000
      */
      ScreenOverlay,
      /**
      * Scene Order, user can custom
      */
      SceneCustom,
    }
    namespace IFLayer2dRenderOrderMode {
      let RTTI: RTTIDescriptor;
    }
    class IFLayer2dSystem extends RendererSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFListenerTypeOffset {
      ResponderStart,
      UIControlStart,
      UserListenerStart,
    }
    namespace IFListenerTypeOffset {
      let RTTI: RTTIDescriptor;
    }
    enum IFMaskType {
      None,
      Rect,
      Ellipse,
      MaskSprites,
    }
    namespace IFMaskType {
      let RTTI: RTTIDescriptor;
    }
    class IFMugAnchorAlignment extends IFAnchorAlignment {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFNailAnchorAlignment extends IFAnchorAlignment {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFObjectAnchorAlignment extends IFAnchorAlignment {
      constructor();
      public objectType: IFObjectType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFObjectType {
      Red,
      Dumplings,
      Feast,
    }
    namespace IFObjectType {
      let RTTI: RTTIDescriptor;
    }
    class IFPetAnchorAlignment extends IFAnchorAlignment {
      constructor();
      public petType: number;
      public useBorder: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFPseudo3DType {
      None,
      Horizontal,
      Vertical,
      HorizontalAndVertical,
    }
    namespace IFPseudo3DType {
      let RTTI: RTTIDescriptor;
    }
    enum IFResolutionType {
      Origin,
      FitWidth,
      FitHeight,
      Fit,
      Fill,
      FitOut,
    }
    namespace IFResolutionType {
      let RTTI: RTTIDescriptor;
    }
    class IFResponder extends BehaviorComponent {
      constructor();
      public swallowTouch: boolean;
      public touchEnabled: boolean;
      public scriptComponent: Transform;
      public hitOnTouchMoved: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFRootSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFRotationType {
      None,
      Device,
      Algorithm,
    }
    namespace IFRotationType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief This a component save the script path, properties, class name and cache.
    */
    class IFScriptComponent extends ScriptComponent {
      constructor();
      public target: Transform;
      public LuaObjRef: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFSkeletonAnchorAlignment extends IFAnchorAlignment {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFSprite2d extends IFWidget {
      constructor();
      public type: IFSprite2dType;
      public sizeMode: IFSprite2dSizeMode;
      public colorTint: Color;
      public blendMode: IFBlendMode;
      public texture: Texture;
      public sharedSpriteShader: XShader;
      public imageAtlas: ImageAtlas;
      public atlasIndex: number;
      public filledType: IFFilledType;
      public filledStartPos: number;
      public filledRange: number;
      public ellipseX: number;
      public ellipseY: number;
      public topLeftPoint: Vector2f;
      public topRightPoint: Vector2f;
      public bottomLeftPoint: Vector2f;
      public bottomRightPoint: Vector2f;
      public slicedLeft: number;
      public slicedRight: number;
      public slicedBottom: number;
      public slicedTop: number;
      public fillCenter: boolean;
      public gridVertices: Vec2Vector;
      public gridUVs: Vec2Vector;
      public gridIndexes: Vector;
      public topLeft: number;
      public topRight: number;
      public bottomLeft: number;
      public bottomRight: number;
      public lineWidth: number;
      public lineColor: Color;
      public outer: boolean;
      public sizeInited: boolean;
      public freeInited: boolean;
      public notPremultAlpha: boolean;
      public alphaPreMultiplication: boolean;
      public handle: number;
      /**
      * Get current frame pixel size.
      */
      public getImageFrameSize(): Vector2f;
      public getFilledRange(): number;
      public setFilledRange(range: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFSprite2dSizeMode {
      Custom,
      Image,
    }
    namespace IFSprite2dSizeMode {
      let RTTI: RTTIDescriptor;
    }
    enum IFSprite2dType {
      Normal,
      Tiled,
      Sliced,
      Filled,
      Ellipse,
      Free,
      Grid,
      Corner,
      Outline,
    }
    namespace IFSprite2dType {
      let RTTI: RTTIDescriptor;
    }
    class IFTeethAnchorAlignment extends IFAnchorAlignment {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFTimerSystem extends System {
      constructor();
      public start: boolean;
      public handle: number;
      public invokeOnce(obj: AObject, method: string, delay: number, userdata: Map, id: number): boolean;
      public invokeRepeating(obj: AObject, method: string, delay: number, interval: number, repeat: number, userdata: Map, id: number): boolean;
      public invokeInfinite(obj: AObject, method: string, delay: number, interval: number, userdata: Map, id: number): boolean;
      public cancelAll(): void;
      public cancel(obj: AObject, method: string, id: number): void;
      public isInvoking(obj: AObject, method: string, id: number): boolean;
      public pause(obj: AObject, method: string, id: number): void;
      public pauseAll(): void;
      public continue(obj: AObject, method: string, id: number): void;
      public continueAll(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFTransform2d extends Transform {
      constructor();
      public useFixedViewSize: boolean;
      public fixedViewSize: Vector2f;
      public position: Vector2f;
      public rotation: number;
      public scale: Vector2f;
      public size: Vector2f;
      public pivot: Vector2f;
      public flipX: boolean;
      public flipY: boolean;
      public depth: number;
      public position2dLock: boolean;
      public scale2dLock: boolean;
      public rotate2dLock: boolean;
      public handle: number;
      public convertPosition2dToPosition3d(pos2d: Vector2f): Vector3f;
      public getWorldRectPosArray(): Vec3Vector;
      public getViewSize(): Vector2f;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFTween extends BehaviorComponent {
      constructor();
      public CurveType: IFTweenCurveType;
      public Duration: number;
      public Delay: number;
      public PlayStyle: IFTweenStyle;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFTweenControlMode {
      PosXY,
      PosX,
      PosY,
    }
    namespace IFTweenControlMode {
      let RTTI: RTTIDescriptor;
    }
    enum IFTweenCurveType {
      Linear,
      QuadIn,
      QuadOut,
      QuadInOut,
      CubicIn,
      CubicOut,
      CubicInOut,
      QuartIn,
      QuartOut,
      QuartInOut,
      SineIn,
      SineOut,
      SineInOut,
      CircIn,
      CircOut,
      CircInOut,
      BackIn,
      BackOut,
      BackInOut,
      ElasticIn,
      ElasticOut,
      ElasticInOut,
      BounceIn,
      BounceOut,
      BounceInOut,
    }
    namespace IFTweenCurveType {
      let RTTI: RTTIDescriptor;
    }
    class IFTweenPosition extends IFTween {
      constructor();
      public ControlMode: IFTweenControlMode;
      public "2dPostion_From": Vector2f;
      public "2dPostion_To": Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFTweenStyle {
      Once,
      Loop,
      PingPong,
    }
    namespace IFTweenStyle {
      let RTTI: RTTIDescriptor;
    }
    class IFUIAnchor extends BehaviorComponent {
      constructor();
      public leftAnchorPercent: number;
      public leftAnchorAbs: number;
      public rightAnchorPercent: number;
      public rightAnchorAbs: number;
      public topAnchorPercent: number;
      public topAnchorAbs: number;
      public bottomAnchorPercent: number;
      public bottomAnchorAbs: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFUIButton extends IFUIControl {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFUIConstraints extends Component {
      constructor();
      public mode: IFUIConstraintsMode;
      public execute: IFUIConstraintsExecute;
      public target: IFTransform2d;
      public leftTarget: IFTransform2d;
      public leftRange: number;
      public leftOffset: number;
      public rightTarget: IFTransform2d;
      public rightRange: number;
      public rightOffset: number;
      public bottomTarget: IFTransform2d;
      public bottomRange: number;
      public bottomOffset: number;
      public topTarget: IFTransform2d;
      public topRange: number;
      public topOffset: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFUIConstraintsExecute {
      Once,
      Update,
    }
    namespace IFUIConstraintsExecute {
      let RTTI: RTTIDescriptor;
    }
    enum IFUIConstraintsMode {
      Basic,
      Advanced,
    }
    namespace IFUIConstraintsMode {
      let RTTI: RTTIDescriptor;
    }
    class IFUIConstraintsSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFUIControl extends IFResponder {
      constructor();
      public stateTextures: Vector;
      public normalSprite: number;
      public pressedSprite: number;
      public disabledSprite: number;
      public normalColor: Color;
      public pressedColor: Color;
      public disabledColor: Color;
      public enabled: boolean;
      public touchMoveRespond: boolean;
      public onSprite: number;
      public offSprite: number;
      public onColor: Color;
      public offColor: Color;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFUIControlState {
      Normal,
      Pressed,
      Disabled,
    }
    namespace IFUIControlState {
      let RTTI: RTTIDescriptor;
    }
    enum IFUIControlTouchType {
      TouchDown,
      TouchDownRepeat,
      DragInside,
      DragOutside,
      DragEnter,
      DragExit,
      TouchUpInside,
      TouchUpOutside,
      TouchCancel,
    }
    namespace IFUIControlTouchType {
      let RTTI: RTTIDescriptor;
    }
    class IFUIDropdown extends IFUIControl {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFUIGrid extends Component {
      constructor();
      public type: IFUIGridType;
      public resizeMode: IFUIGridResizeMode;
      public cellSize: Vector2f;
      public startAxis: IFUIGridStartAxis;
      public paddingLeft: number;
      public paddingRight: number;
      public paddingTop: number;
      public paddingBottom: number;
      public spacingX: number;
      public spacingY: number;
      public verticalDirection: IFUIGridVerticalDirection;
      public horizontalDirection: IFUIGridHorizontalDirection;
      public affectedByScale: boolean;
      public filterInvisibleChildren: boolean;
      public sortingType: IFUIGridSortingType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFUIGridHorizontalDirection {
      LEFT_TO_RIGHT,
      RIGHT_TO_LEFT,
    }
    namespace IFUIGridHorizontalDirection {
      let RTTI: RTTIDescriptor;
    }
    enum IFUIGridResizeMode {
      NONE,
      CONTAINER,
      CHILDREN,
    }
    namespace IFUIGridResizeMode {
      let RTTI: RTTIDescriptor;
    }
    enum IFUIGridSortingType {
      NONE,
      ALPHABETIC,
    }
    namespace IFUIGridSortingType {
      let RTTI: RTTIDescriptor;
    }
    enum IFUIGridStartAxis {
      HORIZONTAL,
      VERTICAL,
    }
    namespace IFUIGridStartAxis {
      let RTTI: RTTIDescriptor;
    }
    enum IFUIGridType {
      NONE,
      HORIZONTAL,
      VERTICAL,
      GRID,
    }
    namespace IFUIGridType {
      let RTTI: RTTIDescriptor;
    }
    enum IFUIGridVerticalDirection {
      TOP_TO_BOTTOM,
      BOTTOM_TO_TOP,
    }
    namespace IFUIGridVerticalDirection {
      let RTTI: RTTIDescriptor;
    }
    class IFUIJoyStick extends IFUIControl {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFUILabel extends IFWidget {
      constructor();
      public text: string;
      public textColor: Color;
      public fontPath: string;
      public fontSize: number;
      public fontType: IFUILabelFontType;
      public alignment: IFUILabelAlignment;
      public fitType: IFUILabelFitType;
      public spacing: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFUILabelAlignment {
      Left,
      Right,
      Center,
    }
    namespace IFUILabelAlignment {
      let RTTI: RTTIDescriptor;
    }
    enum IFUILabelFitType {
      AutoSize,
      FitWidth,
      FitSize,
    }
    namespace IFUILabelFitType {
      let RTTI: RTTIDescriptor;
    }
    enum IFUILabelFontType {
      System,
      TrueType,
      Bitmap,
      SystemV2,
    }
    namespace IFUILabelFontType {
      let RTTI: RTTIDescriptor;
    }
    enum IFUIMoveDirection {
      LEFT_TO_RIGHT,
      RIGHT_TO_LEFT,
      BOTTOM_TO_TOP,
      TOP_TO_BOTTOM,
    }
    namespace IFUIMoveDirection {
      let RTTI: RTTIDescriptor;
    }
    class IFUISafeArea extends Component {
      constructor();
      public type: IFUISafeAreaType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFUISafeAreaType {
      Device,
      UI,
    }
    namespace IFUISafeAreaType {
      let RTTI: RTTIDescriptor;
    }
    class IFUIScrollBar extends IFResponder {
      constructor();
      public direction: IFUIMoveDirection;
      public handleTrans: Transform;
      public handleSize: Vector2f;
      public displayTime: number;
      public disappearTime: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFUIScrollDirection {
      Horizontal,
      Vertical,
      Both,
    }
    namespace IFUIScrollDirection {
      let RTTI: RTTIDescriptor;
    }
    class IFUIScrollView extends IFResponder {
      constructor();
      public content: Transform;
      public direction: IFUIScrollDirection;
      public horizontalScrollBar: Transform;
      public verticalScrollBar: Transform;
      public bounce: boolean;
      public bounceDuration: number;
      public inertia: number;
      public offset: Vector2f;
      public minOffset: Vector2f;
      public maxOffset: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFUISlider extends IFUIControl {
      constructor();
      public direction: IFUIMoveDirection;
      public mode: IFUISliderMode;
      public minValue: number;
      public maxValue: number;
      public steps: number;
      public fillTrans: IFTransform2d;
      public thumbTrans: IFTransform2d;
      public value: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFUISliderMode {
      FOLLOW,
      OFFSET,
      DRAG_THUMB,
    }
    namespace IFUISliderMode {
      let RTTI: RTTIDescriptor;
    }
    class IFUISliderThumb extends IFUIControl {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFUISwitch extends IFUIControl {
      constructor();
      public on: boolean;
      public thumb: IFTransform2d;
      public AnimScale: number;
      public AnimTime: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFUISystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IFUITab extends IFUIControl {
      constructor();
      public groupEnabled: boolean;
      public groupCancelSelf: boolean;
      public groupID: number;
      public index: number;
      public Selected: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum IFUITabState {
      SELECTED,
      UNSELECTED,
    }
    namespace IFUITabState {
      let RTTI: RTTIDescriptor;
    }
    class IFWidget extends Component {
      constructor();
      public alpha: number;
      public cascadeAlphaEnabled: boolean;
      public sharedMaterial: Material;
      public targetTexture: RenderTexture;
      public handle: number;
      public getInstantiatedMaterial(): Material;
      public setInstantiatedMaterial(material: Material): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class IVideoFrameReader extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Image
    */
    class Image extends AObject {
      constructor();
      /**
      * Set image width
      */
      public width: number;
      /**
      * Set image height
      */
      public height: number;
      /**
      * Set image format
      */
      public format: PixelFormat;
      /**
      * Set date type
      */
      public dataType: DataType;
      /**
      * Whether to initialize the memory data for transparency premultiplication
      */
      public alphaPermul: boolean;
      /**
      * Whether to initialize the external storage data for transparency premultiplication
      */
      public outerAlphaPermul: boolean;
      public needFlipY: boolean;
      /**
      * Set external storage data, only used for deserialization
      */
      public origData: MemoryView;
      public handle: number;
      /**
      * Load png data from memory to Image
      */
      public loadPNG(pngData: string, pixelFormat: PixelFormat, dataType: DataType): void;
      /**
      * Convert Image to PNG string
      */
      public convertToPNG(): string;
      public loadPNGBin(pngData: UInt8Vector, pixelFormat: PixelFormat, dataType: DataType): void;
      public convertToPNGBin(): UInt8Vector;
      public convertToJPGBin(arg0: number): UInt8Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ImageArrayProvider extends ImageProvider {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief image atlas, single picture
    *
    */
    class ImageAtlas extends ImageAtlasBase {
      constructor();
      /**
      * @brief get the relative path of the picture
      *
      * @return std::string
      */
      public uri: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief ImageAtlas base class
    *
    */
    class ImageAtlasBase extends AObject {
      constructor();
      /**
      * @brief Get the Frames object
      *
      * @return const Vector&
      */
      public frames: Vector;
      /**
      * @brief Get the Texture object
      *
      * @return Texture*
      */
      public texture: Texture;
      public handle: number;
      /**
      * @brief add frame to atlas
      *
      * @param frame frame
      */
      public addFrame(frame: ImageFrame): void;
      /**
      * @brief Get the Frame Count object
      *
      * @return int32_t frame count
      */
      public getFrameCount(): number;
      public getOrLoadTexture(asset_manager: AssetManager): Texture;
      public clearTexture(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief image atlas, cube
    *
    */
    class ImageCubeAtlas extends ImageAtlasBase {
      constructor();
      /**
      * @brief get the relative path of the picture
      *
      * @return const Vector&
      */
      public uris: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief The description atlas is concentrated in a small frame
    *
    */
    class ImageFrame extends AObject {
      constructor();
      /**
      * @brief Get the Rotate Type object
      *
      * @return AMGRotateType
      */
      public rotate: RotateType;
      /**
      * @brief whether to crop
      *
      * @return true
      * @return false
      */
      public trimed: boolean;
      /**
      * @brief Get the Outer Rect object
      *
      * @return Vector4f
      */
      public outerRect: Vector4f;
      /**
      * @brief Get the Inner Rect object
      *
      * @return Vector4f
      */
      public innerRect: Vector4f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Options related to image preprocessing (for ImageToMesh)
    */
    class ImagePreprocessOption extends AObject {
      constructor();
      /**
      * Whether to do pre-process
      */
      public doPrefilter: boolean;
      /**
      * Smooth kernel half size
      */
      public smoothKernelHalfSize: number;
      /**
      * Grayscale to binary threshold
      */
      public threshold: number;
      /**
      * + expand - shrink
      */
      public offsetPercentage: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Base class of image provider for building a cubemap
    */
    class ImageProvider extends AObject {
      constructor();
      public imagesUri: Vector;
      public InnerAlphaPremul: boolean;
      public OuterAlphaPremul: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ImageRenderer extends Renderer {
      constructor();
      public texture: Texture;
      public opacity: number;
      public color: Color;
      public size: Vector2f;
      public pivot: Vector2f;
      public flipX: boolean;
      public flipY: boolean;
      public stretchMode: ImageStretchMode;
      public imageMaterialProperties: Map;
      public handle: number;
      public getWorldCornersOfSize(): Vec3Vector;
      public getWorldCornersOfRealSize(): Vec3Vector;
      public getImageMaterialPropertiesValue(key: string): void;
      public setImageMaterialPropertiesValue(key: string, arg1: any): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ImageRendererSystem extends RendererSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum ImageStretchMode {
      Fit,
      FitWidth,
      FitHeight,
      Stretch,
      Fill,
      FillAndCut,
    }
    namespace ImageStretchMode {
      let RTTI: RTTIDescriptor;
    }
    class IndexBuffer extends Buffer {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Input
    */
    class Input extends AObject {
      constructor();
      public frameTimestamp: number;
      public handle: number;
      /**
      * @brief Get touch count for current frame.
      * @return int The count of touches.
      */
      public getTouchCount(): number;
      /**
      * @brief Get gesture count for current frame.
      * @return int The count of Gestures.
      */
      public getGestureCount(): number;
      /**
      * @brief Get touch data with index.
      * @param index The index of touch array.
      * @return Touch* The touch information.
      */
      public getTouch(index: number): Touch;
      /**
      * @brief Get gesture data with index.
      * @param index The index of gesture array.
      * @return Gesture* The gesture information.
      */
      public getGesture(index: number): Gesture;
      /**
      * @brief Get current loaded sticker rect.
      * @return const Rect& The rect of sticker.
      */
      public getStickerRect(): Rect;
      /**
      * @brief Set sticker rect for current loaded sticker.
      * @param rect The rect of sticker.
      */
      public setStickerRect(rect: Rect): void;
      /**
      * @brief Get the position of device camera.
      * @return AMGCameraPosition The position of device camera.
      */
      public getCameraPosition(): CameraPosition;
      /**
      * @brief Get the orientation of device.
      * @return AMGDeviceOrientation The orientation of device.
      */
      public getDeviceOrientation(): DeviceOrientation;
      /**
      * @brief Get location of device.
      * @return const std::string& The location of device.
      */
      public getLocation(): string;
      /**
      * @brief Add script listener for Input
      * @param script the script which linstener in
      * @param listenerType listenerType for listener
      * @param callback the callback function name in script for the listener
      * @param scriptUserData user data for this listener
      */
      public addScriptListener(script: Script, listenerType: number, funcName: string, scriptUserData: AObject): void;
      public removeScriptListener(script: Script, listenerType: number, funcName: string, scriptUserData: AObject): void;
      /**
      * @brief Create a Device Sensor Hub
      */
      public createDeviceSensorHub(): DeviceSensorHub;
      /**
      * @brief get current frame time
      */
      public getFrameTimestamp(): number;
      public buildAccelerationSensorAgent(filterType: SensorFilterType): AccelerationSensorAgent;
      public buildGravitySensorAgent(filterType: SensorFilterType): GravitySensorAgent;
      public buildGyroSensorAgent(filterType: SensorFilterType): GyroSensorAgent;
      public buildRotationSensorAgent(filterType: SensorFilterType): RotationSensorAgent;
      public buildRateSensorAgent(): RateSensorAgent;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class InputInternal extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief InputListener
    */
    enum InputListener {
      ON_TOUCH,
      ON_GESTURE_TAP,
      ON_GESTURE_SWIPE,
      ON_GESTURE_PINCH,
      ON_GESTURE_LONG_TAP,
      ON_GESTURE_DRAG,
      ON_GESTURE_DROP,
      ON_GESTURE_DOUBLE_CLICK,
    }
    namespace InputListener {
      let RTTI: RTTIDescriptor;
    }
    class InputSettings extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class InputSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Texture internal format
    */
    enum InternalFormat {
      /**
      * @brief ETC1 RGB8
      */
      ETC1,
      /**
      * @brief ETC2 RGB8
      */
      ETC2,
      /**
      * @brief ETC2 RGBA8
      */
      ETC2A,
      /**
      * @brief ETC2 RGB8A1
      */
      ETC2A1,
      /**
      * @brief PVRTC1 RGB 2BPP
      */
      PTC12,
      /**
      * @brief PVRTC1 RGB 4BPP
      */
      PTC14,
      /**
      * @brief PVRTC1 RGBA 2BPP
      */
      PTC12A,
      /**
      * @brief PVRTC1 RGBA 4BPP
      */
      PTC14A,
      /**
      * @brief PVRTC2 RGBA 2BPP
      */
      PTC22,
      /**
      * @brief PVRTC2 RGBA 4BPP
      */
      PTC24,
      /**
      * @brief R1
      */
      R1,
      /**
      * @brief A8
      */
      A8,
      /**
      * @brief R8
      */
      R8,
      /**
      * @brief R8I
      */
      R8I,
      /**
      * @brief R8U
      */
      R8U,
      /**
      * @brief R8S
      */
      R8S,
      /**
      * @brief R16
      */
      R16,
      /**
      * @brief R16I
      */
      R16I,
      /**
      * @brief R16U
      */
      R16U,
      /**
      * @brief R16F
      */
      R16F,
      /**
      * @brief R16S
      */
      R16S,
      /**
      * @brief R32I
      */
      R32I,
      /**
      * @brief R32U
      */
      R32U,
      /**
      * @brief R32F
      */
      R32F,
      /**
      * @brief RG8
      */
      RG8,
      /**
      * @brief RG8I
      */
      RG8I,
      /**
      * @brief RG8U
      */
      RG8U,
      /**
      * @brief RG8S
      */
      RG8S,
      /**
      * @brief RG16
      */
      RG16,
      /**
      * @brief RG16I
      */
      RG16I,
      /**
      * @brief RG16U
      */
      RG16U,
      /**
      * @brief RG16F
      */
      RG16F,
      /**
      * @brief RG16S
      */
      RG16S,
      /**
      * @brief RG32I
      */
      RG32I,
      /**
      * @brief RG32U
      */
      RG32U,
      /**
      * @brief RG32F
      */
      RG32F,
      /**
      * @brief RGB8
      */
      RGB8,
      /**
      * @brief RGB8I
      */
      RGB8I,
      /**
      * @brief RGB8U
      */
      RGB8U,
      /**
      * @brief RGB8S
      */
      RGB8S,
      /**
      * @brief RGB9E5F
      */
      RGB9E5F,
      /**
      * @brief BGRA8
      */
      BGRA8,
      /**
      * @brief RGBA8
      */
      RGBA8,
      /**
      * @brief RGBA8I
      */
      RGBA8I,
      /**
      * @brief RGBA8U
      */
      RGBA8U,
      /**
      * @brief RGBA8S
      */
      RGBA8S,
      /**
      * @brief RGBA16
      */
      RGBA16,
      /**
      * @brief RGBA16I
      */
      RGBA16I,
      /**
      * @brief RGBA16U
      */
      RGBA16U,
      /**
      * @brief RGBA16F
      */
      RGBA16F,
      /**
      * @brief RGBA16S
      */
      RGBA16S,
      /**
      * @brief RGBA32I
      */
      RGBA32I,
      /**
      * @brief RGBA32U
      */
      RGBA32U,
      /**
      * @brief RGBA32F
      */
      RGBA32F,
      /**
      * @brief R5G6B5
      */
      R5G6B5,
      /**
      * @brief RGBA4
      */
      RGBA4,
      /**
      * @brief RGB5A1
      */
      RGB5A1,
      /**
      * @brief RGB10A2
      */
      RGB10A2,
      /**
      * @brief RG11B10F
      */
      RG11B10F,
      /**
      * @brief D16
      */
      D16,
      /**
      * @brief D24
      */
      D24,
      /**
      * @brief D24S8
      */
      D24S8,
      /**
      * @brief D32
      */
      D32,
      /**
      * @brief D16F
      */
      D16F,
      /**
      * @brief D24F
      */
      D24F,
      /**
      * @brief D32F
      */
      D32F,
    }
    namespace InternalFormat {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Types of interpolation.
    * Defines how the points in the curve are connected.
    * Note: AMGInterpolationType::BEZIER requires control points and AMGInterpolationType::HERMITE requires tangents.
    */
    enum InterpolationType {
      /**
      * @brief Bezier Interpolation.
      * Requires that two control points are set for each segment.
      */
      BEZIER,
      /**
      * @brief Bezier Path Interpolation & LINEAR SPEED.
      * Requires that two control points are set for each segment.
      */
      BEZIER_LINEAR,
      /**
      * @brief Bezier Path Interpolation & LINEAR SPEED.
      * Requires that two cubic control point(x,y ~ 0-1) are set for speed.
      */
      LINEAR_BEZIER,
      /**
      * @brief Point LINETO Point Path Interpolation & cubic BEZIER SPEED.
      * Requires that two control points are set for each segment and two cubic control point(x,y ~ 0-1) are set for speed.
      */
      BEZIER_BEZIER,
      /**
      * @brief B-Spline Interpolation.
      * Uses the points as control points, and the curve is guaranteed to only pass through the
      * first and last point.
      */
      BSPLINE,
      /**
      * @brief Flat Interpolation.
      * @brief A form of Hermite interpolation that generates flat tangents for you. The tangents have a value equal to 0.
      */
      HERMITE_FLAT,
      /**
      * @brief Hermite Interpolation.
      * Requires that two tangents for each segment.
      */
      HERMITE,
      /**
      * @brief Linear Interpolation.
      */
      LINEAR,
      /**
      * @brief Immediate Interpolation.
      */
      IMMEDIATE,
      /**
      * @brief Round Interpolation.
      */
      ROUND,
      /**
      * @brief Floor Interpolation.
      */
      FLOOR,
      /**
      * @brief Ceil Interpolation.
      */
      CEIL,
    }
    namespace InterpolationType {
      let RTTI: RTTIDescriptor;
    }
    class JSManager extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief JS script object of AmazingEngine. It's generated by JSManager::load.
    */
    class JSScript extends AObject {
      constructor();
      /**
      * @brief set attached scene.
      * @param scene the pointer of the scene.
      */
      public scene: Scene;
      public className: string;
      public handle: number;
      /**
      * @brief add event type the script listening.
      * @param type the event type.
      */
      public addEventType(type: number): void;
      /**
      * @brief remove listening for the event type.
      * @param type the event type.
      */
      public removeEventType(type: number): void;
      /**
      * @brief listening all event type for the script.
      */
      public addAllEventType(): void;
      /**
      * @brief remove all event type the script listening.
      */
      public clearAllEventType(): void;
      public addScriptListener(object: AObject, listenerType: number, funcName: string, scriptUserData: AObject): void;
      public removeScriptListener(object: AObject, listenerType: number, funcName: string, scriptUserData: AObject): void;
      /**
      * @brief Add a component rtti type name that this script should handle. This method is called from script. Handling a component means this script will call onComponentAdded and onComponentRemoved functions when a component is added or removed.
      * @param compName the name of the component.
      */
      public handleComponentName(compName: string): void;
      /**
      * @brief This script will not handle any types of components. This method is called from script
      */
      public handleNoComponent(): void;
      /**
      * @brief This script will handle all types of component. This Method is called from script.
      */
      public handleAllComponent(): void;
      public setRunInEditMode(ret: boolean): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief This a component save the script path, properties, class name and cache.
    */
    class JSScriptComponent extends Component {
      constructor();
      public path: string;
      /**
      * @brief Set the properties of script.
      * @param props the properties of script.
      */
      public properties: Map;
      public handle: number;
      /**
      * @brief Get script object.
      * @return Script*
      */
      public getScript(): JSScript;
      public setProperty(name: string, arg1: any): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class JSScriptMethodInfo extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class JSScriptSystem extends System {
      constructor();
      public handle: number;
      public getSystemScriptByName(arg0: string): JSScript;
      public stopJSScriptModule(): void;
      public setRestartJSModuleFlag(arg0: boolean): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class JSWrapNetworkCenter extends NetworkCenter {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class JSWrapNetworkListener extends NetworkListener {
      constructor();
      public handle: number;
      public addScriptListener(listenerType: number, script: JSScript, funcName: string, scriptUserData: AObject): void;
      public removeScriptListener(listenerType: number, script: JSScript, funcName: string, scriptUserData: AObject): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine Jet Affector
    * Jet Affector change particles'accelration by timeFraction
    */
    class JetAffector extends Affector {
      constructor();
      /**
      * @brief JetAffector acceleration getter
      * @return Value* acceleration key-value curve
      */
      public acceleration: Value;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Base class for joint.
    */
    class Joint extends AObject {
      constructor();
      /**
      * @brief get the inverse bind pose matrix
      * @return Matrix4x4f& Matrix representing the bone space transform
      */
      public invBindPosMatrix: Matrix4x4f;
      /**
      * @brief get the bounding box
      * @return AABB&  the bounding box
      */
      public boundingBox: AABB;
      /**
      * @brief get the binding transform
      * @return Transform*  the binding transform
      */
      public jointTransform: Transform;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief joint 2d interface for Box2D joints
    */
    class Joint2D extends Component {
      constructor();
      /**
      * @brief Set the Connected RigidBody2D
      * set connected body property will force recreating joint, be carefuls
      * @param connectedBody connected rigidbody2D comp
      */
      public connectedBody: RigidBody2D;
      /**
      * @brief Set the Collide Connected property
      * set collide connected property will force recreatings joint, be careful
      * @param collideConnected whether to collide Connected rigidbody2Ds
      */
      public collideConnected: boolean;
      /**
      * @brief Set the Anchor of attached rigidbody2D
      * @param anchor anchor
      */
      public anchor: Vector2f;
      /**
      * @brief Set the Anchor of connected rigidbody2D
      * @param connectedAnchor connected anchor
      */
      public connectedAnchor: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Joint3D extends Component {
      constructor();
      /**
      * @brief get connected rigidbody3D
      * @return RigidBody3D*
      */
      public connectedBody: RigidBody3D;
      /**
      * @brief get local position anchor in Body A
      * @return const Vector3f&
      */
      public posAnchorA: Vector3f;
      /**
      * @brief get rotation anchor in Body A
      * @return const Quaternionf&
      */
      public rotAnchorA: Quaternionf;
      /**
      * @brief get local position anchor in Body B
      * @return const Vector3f&
      */
      public posAnchorB: Vector3f;
      /**
      * @brief get rotation anchor in Body B
      * @return const Quaternionf&
      */
      public rotAnchorB: Quaternionf;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class JsAlgorithmInput extends AObject {
      constructor();
      public type: JsAlgorithmInputType;
      public width: number;
      public height: number;
      public format: number;
      public rotateMode: number;
      public flipMode: number;
      public texture: Texture;
      public textureID: number;
      public buffer: UInt8Vector;
      public blitImage: AEAlgorithmResult;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class JsAlgorithmInputMulti extends JsAlgorithmInput {
      constructor();
      public handle: number;
      public addInput(key: string, input: JsAlgorithmInput): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum JsAlgorithmInputType {
      NONE,
      GPU_NORMAL,
      CPU_NORMAL,
      MULTI,
    }
    namespace JsAlgorithmInputType {
      let RTTI: RTTIDescriptor;
    }
    enum JsDownloadStatus {
      IDLE,
      RUNNING,
      BUSY,
    }
    namespace JsDownloadStatus {
      let RTTI: RTTIDescriptor;
    }
    enum JsTaskStatus {
      INIT,
      WAITING,
      RUNNIG,
      FINISHED,
      CANCELED,
    }
    namespace JsTaskStatus {
      let RTTI: RTTIDescriptor;
    }
    class JsWrapAlgorithmOutput extends AObject {
      constructor();
      public algorithmResult: AEAlgorithmResult;
      public extraInfo: AEAlgorithmResult;
      public pipelineIndex: number;
      public status: JsTaskStatus;
      public key: string;
      public type: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class JsWrapAlgorithmTask extends AObject {
      constructor();
      public status: JsTaskStatus;
      public algorithmResult: AEAlgorithmResult;
      public inputTexture: Texture2D;
      public inputBuffer: UInt8Vector;
      public pipelineIndex: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class KeyboardHideInfo extends AObject {
      constructor();
      public finished: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class KeyboardInputInfo extends AObject {
      constructor();
      public textInput: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief A Profile class for Shader Variants.
    * You can use this class to construct a ShaderKeywordProgram which
    * is the unified shader asset handle held by AGFX.
    */
    class KeywordProgramProfile extends AObject {
      constructor();
      /**
      * @brief containing all the keywords supported by this KeywordProgram.
      */
      public keywordSets: Vector;
      /**
      * @brief containing all the renderer types supported by this KeywordProgram.
      */
      public targetApis: Vector;
      /**
      * @brief containing all the shader stages that this KeywordProgram has.
      */
      public stagets: Vector;
      /**
      * @brief containing all the shader variants of this KeywordProgram.
      */
      public shaderSnippets: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief LatLong image provider for a cubemap
    */
    class LatLongImageProvider extends ImageProvider {
      constructor();
      public handle: number;
      /**
      * @brief Set image file's URI
      * @param uri current side's image URI
      */
      public setImageUri(uri: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief animation layer type
    */
    enum LayerType {
      /**
      * @brief lerp layer, blend with other lerp layers according to blending weight
      */
      LERP,
      /**
      * @brief additive layer, added on other layers according to blending weight, will not affect other layers
      */
      ADDITIVE,
      /**
      * @brief override layer, will rewrite the value of other layers if has same target
      */
      OVERRIDE,
    }
    namespace LayerType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief LayoutBufferDesc
    */
    class LayoutBufferDesc extends AObject {
      constructor();
      /**
      * @brief todo
      */
      public buffer: Buffer;
      /**
      * @brief todo
      */
      public stride: number;
      /**
      * @brief todo
      */
      public pointer: number;
      /**
      * @brief todo
      */
      public attributes: Vector;
      /**
      * @brief todo
      */
      public bufferName: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Letter extends AObject {
      constructor();
      public utf8: string;
      public initialPosition: Vector2f;
      public position: Vector2f;
      public rotate: Vector3f;
      public scale: Vector2f;
      public anchor: Vector2f;
      public extraMatrix: Matrix4x4f;
      public rowth: number;
      public idInRow: number;
      public rect: Rect;
      public instanceColor: Color;
      public letterStyle: LetterStyle;
      public handle: number;
      public getUTF16Size(): number;
      public getTopLine(): number;
      public getBaseLine(): number;
      public getBottomLine(): number;
      public getDirection(): TextDirection;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class LetterStyle extends AObject {
      constructor();
      public version: number;
      public fontId: string;
      public fontfamily: string;
      public fontSize: number;
      public fontStyle: FontStyle;
      public italicAngle: number;
      public boldValue: number;
      public fontDecoration: FontDecorationType;
      public decorationWidth: number;
      public decorationOffset: number;
      public fill: LetterStyleLayer;
      public strokes: Vector;
      public effectStyleId: string;
      public effectStylePath: string;
      public effectStyleParams: string;
      public shadows: Vector;
      public innerShadows: Vector;
      public letterBgColorRGBA: Color;
      public letterBgAlpha: number;
      public selected: boolean;
      public pixelFontSize: number;
      public letterColorRGBA: Color;
      public letterAlpha: number;
      public outlineEnabled: boolean;
      public outlineColorRGBA: Color;
      public outlineAlpha: number;
      public outlineWidth: number;
      public shadowEnabled: boolean;
      public shadowColorRGBA: Color;
      public shadowAlpha: number;
      public shadowDistance: number;
      public shadowAngle: number;
      public shadowSmooth: number;
      public shadowDiffuse: number;
      public letterColor: Vector3f;
      public letterBgColor: Vector4f;
      public outlineColor: Vector4f;
      public shadowColor: Vector4f;
      public handle: number;
      public hasResLink(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class LetterStyleLayer extends AObject {
      constructor();
      public type: LetterStyleLayerType;
      public enable: boolean;
      public alpha: number;
      public renderType: LetterStyleLayerRenderType;
      public color: Color;
      public gradientColors: Vector;
      public gradientPoints: FloatVector;
      public gradientAngle: number;
      public gradientMode: LetterStyleLayerGradientMode;
      public gradientTexture: Texture;
      public texturePath: string;
      public textureFlipX: boolean;
      public textureFlipY: boolean;
      public textureScale: number;
      public textureAlpha: number;
      public textureAngle: number;
      public textureRange: number;
      public textureBlend: LetterStyleLayerTextureBlend;
      public texture: Texture;
      public strokeWidth: number;
      public shadowDistance: number;
      public shadowAngle: number;
      public shadowFeather: number;
      public shadowDiffuse: number;
      public shadowStrokes: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum LetterStyleLayerGradientMode {
      CHARACTER,
      ALL,
    }
    namespace LetterStyleLayerGradientMode {
      let RTTI: RTTIDescriptor;
    }
    enum LetterStyleLayerRenderType {
      SOLID,
      GRADIENT,
      TEXTURE,
    }
    namespace LetterStyleLayerRenderType {
      let RTTI: RTTIDescriptor;
    }
    enum LetterStyleLayerTextureBlend {
      NONE,
      SOLID,
      GRADIENT,
    }
    namespace LetterStyleLayerTextureBlend {
      let RTTI: RTTIDescriptor;
    }
    enum LetterStyleLayerType {
      FILL,
      STROKE,
      SHADOW,
      SHADOW_STROKE,
      INNER_SHADOW,
    }
    namespace LetterStyleLayerType {
      let RTTI: RTTIDescriptor;
    }
    class LetterUVRect extends AObject {
      constructor();
      public isSdf: boolean;
      public x0: number;
      public x1: number;
      public y0: number;
      public y1: number;
      public texIdx: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Base Class of Light
    */
    class Light extends Component {
      constructor();
      /**
      * @brief get current light's Color
      * @return const Vector3f& m_color
      */
      public color: Vector3f;
      /**
      * @brief get current light's Intensity
      * @return float m_intensity
      */
      public intensiy: number;
      /**
      * @brief dummy getter for deprecated bool properties
      */
      public shadowEnable: boolean;
      /**
      * @brief get current light's Shdow Enable.
      * @return bool m_shadowEnabled
      */
      public shadowEnableNew: boolean;
      /**
      * @brief get Current Light's ShadowResolution
      * @return const Vector2f& m_shadowResolution
      */
      public shadowResolution: Vector2f;
      /**
      * @brief get current light's shadowBias
      * @return float m_shadowBias
      */
      public shadowBias: number;
      /**
      * @brief get current light's shadowStrength
      * @return float m_shadowStrength
      */
      public shadowStrength: number;
      /**
      * @brief get current light's useSoftShadow Enable
      * @return bool m_isUseSoftShadow
      */
      public useSoftShadow: boolean;
      /**
      * @brief get current light's shadowSoftness
      * @return float m_shadowSoftness
      */
      public shadowSoftness: number;
      /**
      * @brief get current light's shadow blur Radius
      * @return float m_blurRadius
      */
      public blurRadius: number;
      /**
      * @brief get current light's Shadow Blur Num
      * @return int m_blurNum
      */
      public blurNum: number;
      /**
      * @brief get current light's SelfShadowGradient
      * @return float m_selfShadowGradient
      */
      public selfShadowGradient: number;
      /**
      * @brief get current light's ShadowColor
      * @return Color ShadowColor
      */
      public shadowColor: Vector3f;
      /**
      * @brief get current light's InitStrength
      * @return float m_InitStrength
      */
      public InitStrength: number;
      /**
      * @brief set current light's Esmc
      * @param esmc the esmc set to current light
      */
      public EsmC: number;
      /**
      * @brief get current light's cookieTexture
      * @return const SharePtr<Texture>& m_cookieTexture
      */
      public cookieTexture: Texture;
      /**
      * < layers that affected by this light
      */
      public lightingLayers: DynamicBitset;
      /**
      * < Rendering mode for the light
      */
      public renderMode: LightRenderMode;
      public mainCamera: Transform;
      public shadowArea: number;
      public autoShadowFrustum: boolean;
      public autoShadowFrustumSize: boolean;
      public shadowFrustumZNear: number;
      public shadowFrustumZFar: number;
      public shadowTexture: Texture;
      public useFastShadow: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Lightmode for multipass
    */
    enum LightMode {
      /**
      * @brief Not enable light multipass
      */
      NONE,
      /**
      * @brief Brightest directional light(per-pixel) and per-vertex lights are applied
      */
      FORWARD_BASE,
      /**
      * @brief Additive per-pixel lights are applied, one pass per light
      */
      FORWARD_ADD,
    }
    namespace LightMode {
      let RTTI: RTTIDescriptor;
    }
    class LightProbe extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum LightProbeBlendMode {
      OFF,
      BLEND_PROBES,
    }
    namespace LightProbeBlendMode {
      let RTTI: RTTIDescriptor;
    }
    class LightProbeGroup extends Component {
      constructor();
      public densityX: number;
      public densityY: number;
      public densityZ: number;
      public lightingData: LightingData;
      public handle: number;
      public getLightProbeNum(): number;
      public getLightProbePos(index: number): Vector3f;
      public getCubeMapTexArray(index: number): RenderTextureArray;
      public setSliceData(arg0: any, i: number, j: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class LightProbeSystem extends System {
      constructor();
      public isBakeLightProbesTriggered: boolean;
      public isCubeMapGenerated: boolean;
      public combinedLightProbeGroup: LightProbeGroup;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Rendering mode of light
    */
    enum LightRenderMode {
      AUTO,
      IMPORTANT,
      NOT_IMPORTANT,
    }
    namespace LightRenderMode {
      let RTTI: RTTIDescriptor;
    }
    class LightSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief the physical unit
    */
    enum LightUnit {
      /**
      * not use, but as the unit of the light base class
      */
      Unitless,
      /**
      * cd, default unit for spot and point light
      */
      Candelas,
      /**
      * cd * sr
      */
      Lumens,
      /**
      * cd / m^2 , default unit for directional light
      */
      Lux,
    }
    namespace LightUnit {
      let RTTI: RTTIDescriptor;
    }
    class LightingData extends AObject {
      constructor();
      public lightProbePoss: Vec3Vector;
      public coefficients: Vector;
      public hullRays: Vec3Vector;
      public tetrahedra: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine LineAffector
    * update particles' position at regular timesteps
    * update particles' position follow one line
    */
    class LineAffector extends Affector {
      constructor();
      /**
      * @brief line affector max deviation getter
      * @return float : max deviation
      */
      public maxDeviation: number;
      /**
      * @brief line direction getter
      * @return const Vector3f&: line end position
      */
      public end: Vector3f;
      /**
      * @brief update timestep interval getter
      * @return float update interval
      */
      public timeStep: number;
      /**
      * @brief particle position update weight
      * @return float update weight
      */
      public drift: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum LineBreakType {
      AUTO_LINEBREAK,
      CUT_OFF,
    }
    namespace LineBreakType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine Line Emitter
    */
    class LineEmitter extends Emitter {
      constructor();
      /**
      * @brief Emitter line start point getter
      * @return const Vector3f&:start
      */
      public start: Vector3f;
      /**
      * @brief Emitter line end point getter
      * @return const Vector3f&:end
      */
      public end: Vector3f;
      /**
      * @brief Emitter line segments getter
      * @return unsigned int: line segments
      */
      public lineSegments: number;
      /**
      * @brief Whether use random segments range
      * @return bool isUseRandomRange
      */
      public isUseRandomRange: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class LinearForceAffector extends BaseForceAffector {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum LogicOp {
      CLEAR,
      AND,
      AND_REVERSE,
      COPY,
      AND_INVERTED,
      NO_OP,
      XOR,
      OR,
      NOR,
      EQUIVALENT,
      INVERT,
      OR_REVERSE,
      COPY_INVERTED,
      OR_INVERTED,
      NAND,
      SET,
      MAX_ENUM,
    }
    namespace LogicOp {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief look at component to decide current object's orientation by target's position or orientation
    */
    class LookAt extends Component {
      constructor();
      /**
      * @brief get target object transform
      * @return Transform* target transform
      */
      public target: Transform;
      /**
      * @brief get look at mode
      * @return AMGLookAtMode mode: See AMGLookAtMode
      */
      public mode: LookAtMode;
      /**
      * @brief get result world up vector mode
      * @return AMGLookAtWorldUp see AMGLookAtWorldUp
      */
      public worldUp: LookAtWorldUp;
      /**
      * @brief get aim direction of result orientation matrix
      * @return AMGLookAtDirection direction: See AMGLookAtDirection
      */
      public aim: LookAtDirection;
      /**
      * @brief get up direction of result orientation matrix
      * @return AMGLookAtDirection direction: See AMGLookAtDirection
      */
      public up: LookAtDirection;
      /**
      * @brief get additional offset rotation
      * @return Vector3f euler angle of rotation
      */
      public offsetRotation: Vector3f;
      public flipAimUp: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief look direction definition
    */
    enum LookAtDirection {
      /**
      * @brief X axis
      */
      X,
      /**
      * @brief Y axis
      */
      Y,
      /**
      * @brief Z axis
      */
      Z,
      /**
      * @brief MINUS X axis
      */
      MINUS_X,
      /**
      * @brief MINUS Y axis
      */
      MINUS_Y,
      /**
      * @brief MINUS Z axis
      */
      MINUS_Z,
    }
    namespace LookAtDirection {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief look at mode
    */
    enum LookAtMode {
      /**
      * @brief look torward a direction decided by target's direction
      */
      LOOK_AT_DIRECTION,
      /**
      * @brief look at a position decided by target's position
      */
      LOOK_AT_POINT,
    }
    namespace LookAtMode {
      let RTTI: RTTIDescriptor;
    }
    class LookAtSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief up direction of result rotation matrix
    */
    enum LookAtWorldUp {
      /**
      * @brief fixed scene up vector (0,1,0)
      */
      SCENE_Y,
      /**
      * @brief target's up vector
      */
      TARGET_Y,
      OBJECT_X,
      OBJECT_Y,
      OBJECT_Z,
      SCENE_X,
      SCENE_Z,
      TARGET_X,
      TARGET_Z,
    }
    namespace LookAtWorldUp {
      let RTTI: RTTIDescriptor;
    }
    class LuaScript extends Script {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Lut3DProvider extends ImageProvider {
      constructor();
      public handle: number;
      public setImageUri(uri: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum MSAAMode {
      NONE,
      MSAA_4X,
      _4X,
      _16X,
      MSAA_16X,
    }
    namespace MSAAMode {
      let RTTI: RTTIDescriptor;
    }
    class ManipulateResult extends AlgorithmResultEvent {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ManualObjectRendererSystem extends RendererSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Material. This class exposes all properties from a material, allowing you to animate them. You can also use it to set custom shader properties that can't be accessed through the inspector.
    */
    class Material extends AObject {
      constructor();
      /**
      * @brief Set XShader.
      * @param xs XShader.
      */
      public xshader: XShader;
      public properties: PropertySheet;
      public renderQueue: number;
      public passes: Vector;
      public enabledMacros: Map;
      /**
      * @brief m_MShaderPath
      */
      public mshaderPath: string;
      public handle: number;
      /**
      * @brief Sets a named float value.
      * @param name The name of the property.
      * @param f Float value to set.
      */
      public setFloat(name: string, f: number): void;
      /**
      * @brief Get a named float value.
      * @param name The name of the property.
      * @return float The value of the property.
      */
      public getFloat(name: string): number;
      /**
      * @brief Sets a named vec4 value.
      * @param name The name of the property.
      * @param c Vec4 value to set.
      */
      public setVec4(name: string, c: Vector4f): void;
      /**
      * @brief Get a named vec4 value.
      * @param name The name of the property.
      * @return const Vector4f& The value of the property.
      */
      public getVec4(name: string): Vector4f;
      /**
      * @brief Sets a named vec3 value.
      * @param name The name of the property.
      * @param c Vec3 value to set.
      */
      public setVec3(name: string, c: Vector3f): void;
      /**
      * @brief Get a named vec3 value.
      * @param name The name of the property.
      * @return const Vector3f& The value of the property.
      */
      public getVec3(name: string): Vector3f;
      /**
      * @brief Sets a named vec2 value.
      * @param name The name of the property.
      * @param c Vec2 value to set.
      */
      public setVec2(name: string, c: Vector2f): void;
      /**
      * @brief Get a named vec2 value.
      * @param name The name of the property.
      * @return const Vector2f& The value of the property.
      */
      public getVec2(name: string): Vector2f;
      /**
      * @brief Sets a named matrix value.
      * @param name The name of the property.
      * @param m Matrix value to set.
      */
      public setMat4(name: string, m: Matrix4x4f): void;
      /**
      * @brief Get a named matrix value.
      * @param name The name of the property.
      * @return const Matrix4x4f& The value of the property.
      */
      public getMat4(name: string): Matrix4x4f;
      /**
      * @brief Sets a named texture value.
      * @param name The name of the property.
      * @param tex Texture value to set.
      */
      public setTex(name: string, tex: Texture): void;
      /**
      * @brief Get a named texture value.
      * @param name The name of the property.
      * @return Texture* The value of the property.
      */
      public getTex(name: string): Texture;
      /**
      * @brief Sets a named multi value.
      * @param name The name of the property.
      * @param val Multi value to set. FloatVector
      * @param rows Rows of multi value.
      * @param cols Cols of multi value.
      * @param count Count of multi value. float count = rows * cols * count.
      */
      public setMultiValue(name: string, val: FloatVector, rows: number, cols: number, count: number): void;
      /**
      * @brief Sets a named buffer value.
      * @param name The name of the property.
      * @param buffer Buffer value to set.
      */
      public setBuffer(name: string, tex: Buffer): void;
      /**
      * @brief Get a named buffer value.
      * @param name The name of the property.
      * @return Buffer* The value of the property.
      */
      public getBuffer(name: string): Buffer;
      /**
      * @brief Sets a named integer value.
      * @param name The name of the property.
      * @param i Integer value to set.
      */
      public setInt(name: string, tex: number): void;
      /**
      * @brief Get a named integer value.
      * @param name The name of the property.
      * @return const int& The value of the property.
      */
      public getInt(name: string): number;
      /**
      * @brief Sets a shader macro that is enabled by this material.
      * @param macro Macro to set.
      * @param value Macro value to set. Default is 1.
      */
      public enableMacro(macro: string, value: number): void;
      /**
      * @brief Unset a shader macro.
      * @param macro Macro to unset.
      */
      public disableMacro(macro: string): void;
      /**
      * @brief Set if this pass will allow rendering.
      * @param passIndex The pass index.
      * @param enabled set false will cause this render pass to be skipped.
      */
      public setPassEnabled(passIndex: number, enabled: boolean): void;
      /**
      * @brief Get if this pass will allow rendering.
      * @param passIndex The pass index.
      * @return bool default true. false means this render pass will be skipped.
      */
      public getPassEnabled(passIndex: number): boolean;
      /**
      * @brief Instantiate this material and returns the instantiated material.
      * @return Material* The instantiated material.
      */
      public instantiate(): Material;
      /**
      * @brief set texture from device texture manager map by key
      */
      public setTexFromKey(name: string, key: string): void;
      public setFloatVector(name: string, data: FloatVector): void;
      public setVec2Vector(name: string, data: Vec2Vector): void;
      public setVec3Vector(name: string, data: Vec3Vector): void;
      public setVec4Vector(name: string, data: Vec4Vector): void;
      public markNeedToInstantiated(): void;
      public markInstantiated(): void;
      public setXShaderDirty(dirty: boolean): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief MaterialArray
    */
    class MaterialArray extends AObject {
      constructor();
      public materials: Vector;
      public handle: number;
      /**
      * @brief Push back a material.
      * @param material Material
      */
      public pushMaterial(material: Material): void;
      public getMaterials(): Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief A block of material values to apply.\n
    *  MaterialPropertyBlock is used by Renderer.PropertyBlock.\n
    *  Use it in situations where you want to draw multiple objects with the same material, but slightly different properties.\n
    *  For example, if you want to slightly change the color of each mesh drawn. Changing the render state is not supported.
    */
    class MaterialPropertyBlock extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief Set a float property.
      * @param name The name of the property.
      * @param val The float value to set.
      */
      public setFloat(name: string, val: number): void;
      /**
      * @brief Set a float vector property.
      * @param name The name of the property.
      * @param data The float vector value to set.
      */
      public setFloatVector(name: string, data: FloatVector): void;
      /**
      * @brief Set a vec2 vector property.
      * @param name The name of the property.
      * @param data The vec2 vector value to set.
      */
      public setVec2Vector(name: string, data: Vec2Vector): void;
      public setVec3Vector(name: string, data: Vec3Vector): void;
      public setVec4Vector(name: string, data: Vec4Vector): void;
      public setVec2(name: string, vec2: Vector2f): void;
      public setVec3(name: string, vec3: Vector3f): void;
      /**
      * @brief Set a vec4 property.
      * @param name The name of the property.
      * @param vec4 The vec4 value to set.
      */
      public setVec4(name: string, vec4: Vector4f): void;
      /**
      * @brief Set a matrix property.
      * @param name The name of the property.
      * @param mat The matrix value to set.
      */
      public setMatrix(name: string, mat: Matrix4x4f): void;
      /**
      * @brief Set a texture property.
      * @param name The name of the property.
      * @param texture The texture to set.
      */
      public setTexture(name: string, texture: Texture): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class MaterialSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class MemoryView extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief mesh
    */
    class Mesh extends AObject {
      constructor();
      public boundingBox: AABB;
      public dontRecalculateBounds: boolean;
      /**
      * @brief get the vertex data
      * @return FloatVector& the vertex data
      */
      public vertices: FloatVector;
      /**
      * @brief get the instance data
      * @return FloatVector& the instance data
      */
      public instanceData: FloatVector;
      /**
      * @brief get the instance data stride
      * @return uint32_t the instance data stride
      */
      public instanceDataStride: number;
      /**
      * @brief get the material index
      * @return uint32_t the material index
      */
      public materialIndex: number;
      /**
      * @brief get the description of vertex attribute
      * @return Vector& the description of vertex attribute
      */
      public vertexAttribs: Vector;
      /**
      * @brief get skin
      * @return SharePtr<Skin>& skin
      */
      public skin: Skin;
      /**
      * @brief get seqMesh
      * @return SharePtr<SeqMesh>& seqMesh
      */
      public seqMesh: SeqMesh;
      /**
      * @brief get the Morphers
      * @return Vector& the Morphers
      */
      public morphers: Vector;
      /**
      * @brief get the OriginalVerties
      * @return SharePtr<OriginalVertex>& the OriginalVerties
      */
      public originalVertices: OriginalVertex;
      /**
      * @brief get the sub meshes
      * @return Vector& the sub meshes
      */
      public submeshes: Vector;
      /**
      * @brief set the clear state after upload
      * @param clear clear state
      */
      public clearAfterUpload: boolean;
      /**
      * the select vertex id
      */
      public selectedVertId: UInt16Vector;
      public handle: number;
      /**
      * @brief add sub mesh
      * @param submesh the sub mesh
      */
      public addSubMesh(submesh: SubMesh): void;
      /**
      * @brief add morpher
      * @param morpher morpher
      */
      public addMorpher(morpher: Morpher): void;
      /**
      * @brief set the vertex array
      * @param data  the vertex array data
      * @param offest offest
      * @param count count
      */
      public setVertexArray(data: Vec3Vector, offset: number, count: number, calculateBounds: boolean): void;
      /**
      * @brief set the normal array
      * @param data  the normal array data
      * @param offest offest
      * @param count count
      */
      public setNormalArray(data: Vec3Vector, offset: number, count: number): void;
      /**
      * @brief set the tangent array
      * @param data  the tangent array data
      * @param offest offest
      * @param count count
      */
      public setTangentArray(data: Vec4Vector, offset: number, count: number): void;
      /**
      * @brief set the color array
      * @param data  the color array data
      * @param offest offest
      * @param count count
      */
      public setColorArray(data: Vec4Vector, offset: number, count: number): void;
      /**
      * @brief set the uv array
      * @param uvIndex the uv index
      * @param data  the uv array data
      * @param offest offest
      * @param count count
      */
      public setUvArray(uvIndex: number, data: Vec2Vector, offset: number, count: number): void;
      /**
      * @brief set the uv3D array
      * @param uvIndex the uv3D index
      * @param data  the uv3D array data
      * @param offest offest
      * @param count count
      */
      public setUv3DArray(uvIndex: number, data: Vec3Vector, offset: number, count: number): void;
      /**
      * @brief set the user define array
      * @param Index the user define index
      * @param data  the user define array data
      * @param offest offest
      * @param count count
      */
      public setUserDefineArray(userIndex: number, data: Vec4Vector, offset: number, count: number): void;
      /**
      * @brief set the vertex count
      * @param count count number
      */
      public setVertexCount(count: number): void;
      public setIndicesArray(data: Vec4Vector, offset: number, count: number): void;
      public setWeightArray(data: Vec4Vector, offset: number, count: number): void;
      /**
      * @brief get the vertex array
      * @param offest offest
      * @param count count
      * @return Vec3Vector the vertex array
      */
      public getVertexArray(offset: number, count: number): Vec3Vector;
      /**
      * @brief get the normal array
      * @param offest offest
      * @param count count
      * @return Vec3Vector the normal array
      */
      public getNormalArray(offset: number, count: number): Vec3Vector;
      /**
      * @brief get the Tangent array
      * @param Index index
      * @param offest offest
      * @param count count
      * @return Vec4Vector the Tangent array
      */
      public getTangentArray(offset: number, count: number): Vec4Vector;
      /**
      * @brief get the color array
      * @param offest offest
      * @param count count
      * @return Vec4Vector the color array
      */
      public getColorArray(offset: number, count: number): Vec4Vector;
      /**
      * @brief get the uv array
      * @param uvIndex index of uv
      * @param offest offest
      * @param count count
      * @return Vec2Vector the uv array
      */
      public getUvArray(uvIndex: number, offset: number, count: number): Vec2Vector;
      /**
      * @brief get the uv3D array
      * @param uvIndex index of uv
      * @param offest offest
      * @param count count
      * @return Vec3Vector the uv3D array
      */
      public getUv3DArray(uvIndex: number, offset: number, count: number): Vec3Vector;
      public getUserDefineArray(userIndex: number, offset: number, count: number): Vec4Vector;
      /**
      * @brief get count number of vertex
      * @return int count number of vertex
      */
      public getVertexCount(): number;
      /**
      * @brief get the vertex
      * @param index the index of vertex
      * @return Vector3f the vertex data
      */
      public getVertex(index: number): Vector3f;
      /**
      * @brief get the normal
      * @param index the index of normal
      * @return Vector3f the normal data
      */
      public getNormal(index: number): Vector3f;
      /**
      * @brief get the color
      * @param index the index of color
      * @return Vector4f the color data
      */
      public getColor(index: number): Vector4f;
      /**
      * @brief get the tangent
      * @param index the index
      * @return Vector4f the tangent
      */
      public getTangent(index: number): Vector4f;
      /**
      * @brief get the uv
      * @param uvIndex the uvindex
      * @param index the index
      * @return Vector2f the uv data
      */
      public getUv(uvIndex: number, index: number): Vector2f;
      /**
      * @brief get the uv3D
      * @param uvIndex the uvindex
      * @param index the index
      * @return Vector3f the uv3D data
      */
      public getUv3D(uvIndex: number, index: number): Vector3f;
      /**
      * @brief get the user define array
      * @param Index index
      * @param offest offest
      * @param count count
      * @return Vec4Vector the user define array
      */
      public getUserDefine(userIndex: number, index: number, count: number): Vec4Vector;
      /**
      * @brief get the submesh
      * @param index the index
      * @return SubMesh* the submesh
      */
      public getSubMesh(index: number): SubMesh;
      /**
      * @brief set the atttribute by type
      * @param type attribute type
      * @param data  the atttribute data
      * @param offest offest
      * @param count count
      */
      public setAttributeData(attributeType: VertexAttribType, data: FloatVector, offset: number, count: number): void;
      /**
      * @brief get the atttribute by type
      * @param type attribute type
      * @param offest offest
      * @param count count
      * @return FloatVector the atttribute data
      */
      public getAttributeData(attributeType: VertexAttribType, offset: number, count: number): FloatVector;
      /**
      * @brief get indices by color
      * @param color color
      * @param threshold threshold
      * @return UInt32Vector
      */
      public getIndicesByColor(color: Color, threshold: number): UInt32Vector;
      /**
      * @brief Recalculate normals
      */
      public reCalculateNormals(): void;
      /**
      * @brief Recalculate tangents
      */
      public reCalculateTangents(): void;
      public getTriangles(): UInt16Vector;
      public getTriangleIndices(): UInt32Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief General option for mesh band generation
    */
    class MeshBandOption extends AObject {
      constructor();
      public offset: number;
      public width: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief enum for the center position of a mesh
    */
    enum MeshCenter {
      /**
      * bbox center
      */
      Baseline,
      Center,
    }
    namespace MeshCenter {
      let RTTI: RTTIDescriptor;
    }
    enum MeshCurve {
      /**
      * @brief dynamics number of segments over a curve
      */
      Adaptive,
      /**
      * @brief fixed number of segments over a curve
      */
      Uniform,
    }
    namespace MeshCurve {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Options related to mesh decimation
    */
    class MeshDecimationOption extends AObject {
      constructor();
      /**
      * Maximum nr of triangles in output mesh; 0 will disable contraction
      */
      public maxTris: number;
      /**
      * Maximum error allowed when contracting; Making it too small will prevent
      * decimation to small number of triangles.
      */
      public maxError: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine Mesh Emitter
    */
    class MeshEmitter extends Emitter {
      constructor();
      /**
      * @brief surface vertices getter
      * @return const std::vector<Vector3f>&: mesh surface
      */
      public mesh: Mesh;
      /**
      * @brief surface vertices setter
      * @param vertices  mesh surface
      */
      public useMeshOrientation: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief General option for extrusion
    */
    class MeshExtrudeOption extends AObject {
      constructor();
      public offset: number;
      /**
      * What part of extruded space should be taken by middle segments (all except the sides)
      * Instead of adding 10 segments, you can add 3 segments and set midSegment to 0.8 ;
      * After loop subdivision the final mesh should look the same but have way less triangles
      */
      public midSegment: number;
      public side: number;
      public segments: number;
      public normal: MeshNormal;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Option related to mesh fracturing
    */
    class MeshFractureOption extends AObject {
      constructor();
      /**
      * Random seed: affects voronoi diagram and in the end
      * shapes and locations of fragments
      */
      public randomSeed: number;
      /**
      * Number of fractured pieces
      */
      public piecesCount: number;
      /**
      * Whether pieces should be divided further
      * if they contain disconnected parts
      */
      public splitDisconnectedParts: boolean;
      /**
      * Can be used to limit triangles for Voronoi site generation
      * Only triangles which are facing in similar direction as normal
      * will be selected.
      */
      public normal: Vector3f;
      /**
      * All pieces which have smaller volume will be discarded
      */
      public minimumVolume: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Normal type for extruded shape
    */
    enum MeshNormal {
      /**
      * every face has its own normal
      */
      Side,
      /**
      * every vertex has smooth normal
      */
      Face,
      Smooth,
    }
    namespace MeshNormal {
      let RTTI: RTTIDescriptor;
    }
    class MeshQuad extends GeometryMesh {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class MeshRectangle extends GeometryMesh {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief class for the mesh renderer
    */
    class MeshRenderer extends Renderer {
      constructor();
      /**
      * @brief get mesh
      * @return Mesh*  the mesh
      */
      public mesh: Mesh;
      /**
      * @brief get if cast shadow or not
      * @return bool
      * @retval true cast shadow
      * @retval false not cast shadow
      */
      public castShadow: boolean;
      public handle: number;
      public getBoundingBox(): AABB;
      public getMorphedMesh(): Mesh;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class MeshRendererSystem extends RendererSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class MeshSkeleton extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Options related to image preprocessing (for ImageToMesh)
    */
    class MeshSmoothingOption extends AObject {
      constructor();
      /**
      * Number of smoothing steps
      */
      public numSteps: number;
      /**
      * Strength of smoothing in a single step
      */
      public lambda: number;
      /**
      * Set > 0.0 (but typically in the range of 0.01 - 0.1) to enable Taubin smoothing (volume preserving)
      */
      public passband: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class MeshTriangleSortSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief class for the mesh MeshTriangleSorter
    */
    class MeshTriangleSorter extends Component {
      constructor();
      /**
      * @brief set the indices of the sub mesh that needs to be sorted
      * @param indices the indices
      */
      public subMeshIndices: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Texture projection type
    */
    enum MeshUVType {
      /**
      * projected onto a unit sphere
      */
      Planar,
      /**
      * same as planar but takes a user specific bbox
      */
      Spherical,
      Square,
    }
    namespace MeshUVType {
      let RTTI: RTTIDescriptor;
    }
    class Meta extends AObject {
      constructor();
      public assetImporter: AssetImporter;
      public assetRedirectData: AssetRedirectData;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum Mobility {
      Dynamic,
      Static,
      Stationary,
    }
    namespace Mobility {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief model
    */
    class Model extends AObject {
      constructor();
      /**
      * @brief set model node
      * @param node node
      */
      public ModelNode: ModelNode;
      /**
      * @brief set mesh array
      * @param meshes mesh array
      */
      public Meshes: Vector;
      /**
      * @brief Get the Animazes object
      * @return Vector animazes
      */
      public Animazes: Vector;
      public Materials: Vector;
      public Cameras: Vector;
      public Lights: Vector;
      public handle: number;
      /**
      * @brief add mesh to model
      * @param mesh mesh
      */
      public AddMesh(mesh: Mesh): void;
      public AddMaterial(material: string): void;
      public AddCamera(camera: Camera): void;
      public AddLight(light: Light): void;
      /**
      * @brief create entity of model instance, add to scene
      * @param scene scene
      * @param name root name
      * @return Entity*
      */
      public createModelInstance(scene: Scene, name: string): Entity;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ModelDownloadTask extends DownloadTask {
      constructor();
      public requirements: StringVector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ModelManipulator3D extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief model node
    */
    class ModelNode extends AObject {
      constructor();
      /**
      * @brief set mesh indices
      * @param indexs mesh indices
      */
      public mesh_index: UInt32Vector;
      /**
      * @brief set children of node
      * @param children children node
      */
      public children: Vector;
      /**
      * @brief set parent node
      * @param parent parent node
      */
      public parent: ModelNode;
      /**
      * @brief get transform
      * @return const SharePtr<Transform>&
      */
      public transform: Transform;
      public materialIndices: UInt32Vector;
      public cameraIndices: UInt32Vector;
      public lightIndices: UInt32Vector;
      public handle: number;
      /**
      * @brief add mesh index
      * @param index mesh index
      */
      public AddMeshIndex(index: number): void;
      public AddMaterialIndex(index: number): void;
      public AddCameraIndex(index: number): void;
      public AddLightIndex(index: number): void;
      /**
      * @brief add child of node
      * @param node child
      */
      public AddChild(node: ModelNode): void;
      public FindNode(name: string): ModelNode;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum ModuleEventType {
      ADD_MODULE,
      ADD_MODULE_TRANSACTION_END,
      REMOVE_MODULE,
      ADD_PREFAB,
      REMOVE_PREFAB,
    }
    namespace ModuleEventType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief morpher
    */
    class Morpher extends AObject {
      constructor();
      /**
      * @brief Get the channels
      * @return Vector of  channels
      */
      public channels: Vector;
      public handle: number;
      /**
      * @brief Get the channels count
      * @return channels count
      */
      public getMorpherChannelsCount(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief morpher channel
    */
    class MorpherChannel extends AObject {
      constructor();
      /**
      * @brief Get the morpher targets
      * @return morpher targets
      */
      public targets: Vector;
      public weight: number;
      public handle: number;
      /**
      * @brief Get the morpher target count
      * @return morpher target count
      */
      public getMorpherTargetsCount(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief morpher component
    */
    class MorpherComponent extends Component {
      constructor();
      /**
      * @brief Set original mesh vertices
      * @param orignalMeshVertices orignal mesh vertices
      */
      public originalVertices: FloatVector;
      /**
      * @brief Get the related mesh
      */
      public basemesh: Mesh;
      /**
      * @brief Get if use avatarDrive
      * @return bool if use avatarDrive
      */
      public useAvatarDrive: boolean;
      /**
      * @brief Get if use face background fitting
      * @return bool if use face background fitting
      */
      public useFaceBackgroundFitting: boolean;
      /**
      * @brief Get if use pos attr only
      * @return bool if use pos attr only
      */
      public usePosAttrOnly: boolean;
      /**
      * @brief Get if split pos and offset
      * @return boolif split pos and offset
      */
      public splitPosAndOffset: boolean;
      /**
      * @brief Get if recalculate normal
      * @return bool if recalculate normal
      */
      public recalcNormal: boolean;
      public updateOriginalMesh: boolean;
      /**
      * @brief Set the morpher channels
      * @param weights the weight of morpher channels
      */
      public channelWeights: Map;
      /**
      * @brief Set the morpher channels' amplifier
      * @param amplifiers the amplifier of morpher channels
      */
      public channelAmplifiers: Map;
      public handle: number;
      /**
      * @brief Whether it has channel : name
      * @param name name
      * @return true
      * @return false
      */
      public hasChannel(name: string): boolean;
      /**
      * @brief Get channel weight from channel name
      * @param channel channel
      * @return float
      */
      public getChannelWeight(name: string): number;
      /**
      * @brief Set weight value of channel
      * @param channel channel
      * @param weight weight
      */
      public setChannelWeight(name: string, weight: number): void;
      /**
      * @brief Reset morpher component
      */
      public reset(): void;
      /**
      * @brief Get the related morpher
      */
      public getMorpher(): Morpher;
      public getMorphedMesh(): Mesh;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class MorpherSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief morpher target
    */
    class MorpherTarget extends AObject {
      constructor();
      /**
      * @brief Get the full weight
      * @return full weight
      */
      public fullweight: number;
      /**
      * @brief Get the control point count
      * @return control point num
      */
      public indices: UInt16Vector;
      /**
      * @brief Get the control point offset
      * @return control point offset
      */
      public offsetdata: FloatVector;
      /**
      * @brief Get the vertex attribute desc
      * @return vertex attribute desc
      */
      public vertexAttribs: Vector;
      public handle: number;
      /**
      * @brief Get the control point count
      * @return control point num
      */
      public getCtrlPointsCount(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class MultisampleState extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class NetworkCenter extends AObject {
      constructor();
      public handle: number;
      public initClient(requestWaitingInit: boolean): void;
      public get(listener: NetworkListener, url: string, headers: Map): number;
      public get_with_params(listener: NetworkListener, url: string, headers: Map, params: Map): number;
      public post(listener: NetworkListener, url: string, headers: Map, postContent: string): number;
      public post_with_params(listener: NetworkListener, url: string, headers: Map, postContent: string, params: Map): number;
      public postBinary(listener: NetworkListener, url: string, headers: Map, postContent: UInt8Vector): number;
      public postBinary_with_params(listener: NetworkListener, url: string, headers: Map, postContent: UInt8Vector, params: Map): number;
      public postSync(listener: NetworkListener, url: string, headers: Map, postContent: string): number;
      public postSync_with_params(listener: NetworkListener, url: string, headers: Map, postContent: string, params: Map): number;
      public postBinarySync(listener: NetworkListener, url: string, headers: Map, postContent: UInt8Vector): number;
      public postBinarySync_with_params(listener: NetworkListener, url: string, headers: Map, postContent: UInt8Vector, params: Map): number;
      public cancelRequest(requestId: number): number;
      public addNetworkListener(listener: NetworkListener): void;
      public removeNetworkListener(listener: NetworkListener): void;
      public update(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class NetworkCenterWS extends AObject {
      constructor();
      public handle: number;
      public connect(listener: NetworkListenerWS, url: string): number;
      public disconnect(wsid: number): boolean;
      public isConnected(wsid: number): boolean;
      public sendMessage(wsid: number, msg: string): boolean;
      public sendBinaryMessage(wsid: number, msg: UInt8Vector): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class NetworkListener extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class NetworkListenerWS extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class NetworkResult extends AObject {
      constructor();
      public requestId: number;
      public status: number;
      public body: string;
      public binaryBody: UInt8Vector;
      public statusCode: number;
      public statusDesc: string;
      public headers: Map;
      public newBytesNum: number;
      public errorDesc: string;
      public contentLength: number;
      public succeed: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum NetworkStatus {
      NETWORK_START,
      NETWORK_UPDATE,
      NETWORK_SUCCESS,
      NETWORK_FAIL,
      NETWORK_CANCEL,
    }
    namespace NetworkStatus {
      let RTTI: RTTIDescriptor;
    }
    enum NetworkStatusWS {
      NETWORK_WS_STATE_CHANGED,
      NETWORK_WS_ERROR,
      NETWORK_WS_FEEDBACKLOG,
      NETWORK_WS_MESSAGE,
    }
    namespace NetworkStatusWS {
      let RTTI: RTTIDescriptor;
    }
    class NetworkWSError extends AObject {
      constructor();
      public url: string;
      public error: string;
      public state: number;
      public wsid: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class NetworkWSFeedbackLog extends AObject {
      constructor();
      public log: string;
      public wsid: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class NetworkWSMessage extends AObject {
      constructor();
      public message: string;
      public size: number;
      public wsid: number;
      public binaryMessage: UInt8Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class NetworkWSStateChanged extends AObject {
      constructor();
      public url: string;
      public state: number;
      public wsid: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class NewPlaneResult extends AlgorithmResultEvent {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class NodeExclusionSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine NoiseAffector
    */
    class NoiseAffector extends Affector {
      constructor();
      /**
      * @brief Noise Strength Getter
      * @return float strength
      */
      public strength: number;
      /**
      * @brief Scale X Getter
      * @return Value*  Scale X
      */
      public Xstrength: Value;
      /**
      * @brief Scale Y Getter
      * @return Value*  Scale Y
      */
      public Ystrength: Value;
      /**
      * @brief Scale Z Getter
      * @return Value*  Scale Z
      */
      public Zstrength: Value;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum ObjectType {
      /**
      * < 
      */
      DET_RED,
      /**
      * < 
      */
      DET_DUMPLINGS,
      /**
      * < 
      */
      DET_FEAST,
    }
    namespace ObjectType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Orignal Vertex
    *
    */
    class OriginalVertex extends AObject {
      constructor();
      /**
      * @brief Get the Position Serialized object
      *
      * @return const Vec3Vector& positions
      */
      public position: Vec3Vector;
      /**
      * @brief Get the Indices object
      *
      * @return const UInt16Vector& indices
      */
      public indices: UInt32Vector;
      /**
      * @brief init OriginalIndexToAmgIndex for serialized
      *
      * @param m convertmap
      */
      public convertMap: Map;
      /**
      * @brief Get the Position Runtime object
      *
      * @return const Vec3Vector&
      */
      public positionRuntime: Vec3Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Gesture type of pan.
    */
    class PanGesture extends Gesture {
      constructor();
      /**
      * @brief The position of pan.
      */
      public point: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief  AmazingEngine Particle Object
    * All Copy From Effect SDK
    */
    class Particle extends AObject {
      constructor();
      public lifeRemaining: number;
      public linearVel: Vector3f;
      /**
      * @brief particle current color
      */
      public color: Vector4f;
      /**
      * @brief particle emitted color
      */
      public originalColor: Vector4f;
      /**
      * @brief particle time to death
      */
      public timeToLive: number;
      /**
      * @brief particle timeToLive/totalTimeToLive
      */
      public timeFraction: number;
      /**
      * @brief  particle time from start to death
      */
      public totalTimeToLive: number;
      /**
      * @brief particle current position
      */
      public position: Vector3f;
      /**
      * @brief particle emitted position
      */
      public originalPosition: Vector3f;
      /**
      * @brief particle current orientation
      */
      public orientation: Quaternionf;
      /**
      * @brief particle emitted orientation
      */
      public originalOrientation: Quaternionf;
      /**
      * @brief particle current direction
      */
      public direction: Vector3f;
      /**
      * @brief particle emitted direction
      */
      public originalDirection: Vector3f;
      /**
      * @brief particle current width
      */
      public width: number;
      /**
      * @brief particle original width
      */
      public originalWidth: number;
      /**
      * @brief particle current height
      */
      public height: number;
      /**
      * @brief particle original height
      */
      public originalHeight: number;
      /**
      * @brief particle current depth
      */
      public depth: number;
      /**
      * @brief particle original depth
      */
      public originalDepth: number;
      /**
      * @brief particle original velocity
      */
      public originalVelocity: number;
      /**
      * @brief particle disturbance mainly used by NoiseAffector
      * particle disturbance would be added to particle position
      */
      public disturbance: Vector3f;
      /**
      * @brief texture animation time step mainly used by TextureAnimationAffector
      */
      public textureAnimationTimeStep: number;
      /**
      * @brief texture animation time step count mainly used by TextureAnimationAffector
      */
      public textureAnimationTimeStepCount: number;
      /**
      * @brief texture current coord mainly used by TextureAnimationAffector
      */
      public textureCoordsCurrent: number;
      /**
      * @brief texture animation lookup type mainly used by TextureAnimationAffector
      */
      public textureAnimationDirectionUp: boolean;
      /**
      * @brief particle rotation value
      */
      public rotation: Vector3f;
      /**
      * @brief particle rotationSpeed value
      */
      public rotationSpeed: Vector3f;
      /**
      * @brief customData1
      */
      public customData1: Vector4f;
      /**
      * @brief customData2
      */
      public customData2: Vector4f;
      /**
      * @brief mainly used in GravityAffector
      */
      public mass: number;
      /**
      * @brief how much the particle is affected by affectors, range 0~1
      */
      public affectorRatio: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine Particle Component
    * Particle component include emitters, affectors and renderer
    * Particle component has different run state
    * Particle component could be affected by physics module
    * Particle component has a particle quota
    */
    class ParticleComponent extends Renderer {
      constructor();
      public emitters: Vector;
      public affectors: Vector;
      /**
      * @brief ParticleRenderer Getter
      * @return ParticleRenderer* ParticleRenderer
      */
      public renderer: ParticleRenderer;
      /**
      * @brief Particle Quota Getter
      * @return unsigned int: Particle Quota
      */
      public particleQuota: number;
      /**
      * @brief Particle TextureBlockWidthSize Getter (be not really used)
      * @return unsigned short: TextureBlockWidthSize
      */
      public textureBlockWidth: number;
      /**
      * @brief Particle TextureBlockHeightSize Getter (be not really used)
      * @return unsigned short: TextureBlockHeightSize
      */
      public textureBlockHeight: number;
      public flipY: boolean;
      /**
      * @brief return is default start
      * @return bool
      */
      public autoStart: boolean;
      /**
      * @brief return is Prewarm
      * @return bool
      */
      public prewarm: boolean;
      /**
      * @brief return simulation space
      * @return AMGParticleSimulationSpace
      */
      public simulationSpace: ParticleSimulationSpace;
      /**
      * @brief return oritation display space
      * @return AMGParticleSimulationSpace
      */
      public oritationDisplayMode: ParticleOritationDisplay;
      /**
      * @brief return oritation space
      * @return AMGParticleOritation
      */
      public oritationMode: ParticleOritationMode;
      /**
      * @brief return simulation space
      * @return AMGParticleSimulationSpace
      */
      public simulationSpeed: number;
      /**
      * @brief return ring buffer mode
      * @return AMGParticleRingBufferMode
      */
      public ringBufferMode: ParticleRingBufferMode;
      /**
      * @brief return loop range
      * @return float
      */
      public loopRange: Value;
      /**
      * @brief return sub emitters
      * @return Vector sub emitters
      */
      public subEmitters: Vector;
      /**
      * @brief Set whether use physics
      * @param use_physics physics state
      */
      public use_physics: number;
      /**
      * @brief Set gravity scale for particles in physics system
      * @param scale gravity acceleration scale
      */
      public gravityScale: number;
      /**
      * @brief Set collider scale for particles in physics system
      * @param scale collider scale value
      */
      public colliderScale: number;
      /**
      * @brief Set collider offset for particles in physics system
      * @param scale collider offset value
      */
      public colliderOffset: Vector3f;
      /**
      * @brief enable fixed rotation (PHYSICS_2D)
      * @param enabled enable flag
      */
      public fixedRotate: boolean;
      /**
      * @brief Set the Friction
      * @param dynamicFriction dynamic friction
      */
      public friction: number;
      /**
      * @brief Set the Bounciness(also elasticity)
      * range [0-1]
      * @param bounciness bounciness
      */
      public bounciness: number;
      /**
      * @brief set linear damping for particles in physics system
      * @param damping damping ratio
      */
      public linearDamping: number;
      /**
      * @brief set angular damping for particles in physics system
      * @param damping damping ratio
      */
      public angularDamping: number;
      /**
      * @brief set linear factor for particles in physics system
      * @param linearFactor vector3f
      */
      public linearFactor: Vector3f;
      /**
      * @brief set angular factor for particles in physics system
      * @param angularFactor vector3f
      */
      public angularFactor: Vector3f;
      /**
      * @brief Set the Category Bits
      * collider's category, will matched by mask
      * @param bits bits
      */
      public colliderCategoryBits: number;
      /**
      * @brief Set the Mask Bits
      * collider can collider with which categories.
      * @param bits bits
      */
      public colliderMaskBits: number;
      /**
      * @brief enable transform(position/rotation/velocity) affecto
      * @param enabled enable flag
      */
      public enableTransformAffector: boolean;
      public handle: number;
      /**
      * @brief Call all emitters, affectors notifyStart when state is STOP
      */
      public start(): void;
      /**
      * @brief Update m_updateState to STOP , not clear existed particles. Use forceStop if you want to clear existed particles.
      */
      public stop(): void;
      /**
      * @brief Call all emitters, affectors notifyStop when state is PAUSE
      */
      public resume(): void;
      /**
      * @brief Call all emitters, affectors notifyStop when state is RESUME
      */
      public pause(): void;
      /**
      * @brief Call all emitters, affectors notifyStop. Clear existed particles.
      */
      public forceStop(): void;
      /**
      * @brief Check whether state is STOP
      * @return bool stop
      */
      public isStopped(): boolean;
      /**
      * @brief  Check whether state is START
      * @return bool start
      */
      public isStarted(): boolean;
      /**
      * @brief Check whether state is RESUME
      * @return bool pause
      */
      public isPaused(): boolean;
      /**
      * @brief get particle iterator
      * @return ParticleIterator*
      */
      public getParticleIterator(): ParticleIterator;
      /**
      * @brief Trigger sub emitter with a particle
      * @param index particle sub emitter index
      * @param particle particle data, nullptr means a normal emission
      */
      public triggerSubEmitter(arg0: number, arg1: Particle): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Particle Iterator. Only used in script
    *  Usage: in lua
    *   local iter = self.particleComp:getParticleIterator()
    *   local particle = iter:getFirst()
    *   while(not iter:isEnd())
    *   do
    *       xxxxxx do something
    *       particle = iter:getNext()
    *   end
    */
    class ParticleIterator extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief get first particle in pool
      */
      public getFirst(): Particle;
      /**
      * @brief get next particle in pool
      */
      public getNext(): Particle;
      /**
      * @brief is current particle end
      * @return bool is iterator End
      */
      public isEnd(): boolean;
      /**
      * @brief get current particle
      * @return Particle*
      */
      public getParticle(): Particle;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine ParticleMeshRenderer
    */
    class ParticleMeshRenderer extends ParticleRenderer {
      constructor();
      /**
      * @brief Get current template Mesh
      * @return Mesh* current template Mesh
      */
      public templateMesh: Mesh;
      /**
      * @brief AMGParticleMeshRendererType getter
      * @return AMGParticleMeshRendererType
      */
      public displayMode: ParticleMeshRendererType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine MeshRenderer Type
    */
    enum ParticleMeshRendererType {
      /**
      * @brief Always scaled by width/height/depth
      */
      SIZE_BY_PARTICLE,
      /**
      * @brief Always particle oritation
      */
      SCALE_BY_PARTICLE,
    }
    namespace ParticleMeshRendererType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief ParticleSystem Oritation Display Mode
    */
    enum ParticleOritationDisplay {
      /**
      * update all rotation value and do not sync to oritation
      */
      ONLY_Z,
      /**
      * update all rotation value and sync to oritation
      */
      ALL_AXIS,
      ALL_AXIS_WITH_ORITATION,
    }
    namespace ParticleOritationDisplay {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief ParticleSystem Oritation Display Mode
    */
    enum ParticleOritationMode {
      /**
      * update oritation only by property
      */
      AFFECT_BY_ENTITY,
      NONE,
    }
    namespace ParticleOritationMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine Particle Quat Renderer
    */
    class ParticleQuatRenderer extends ParticleRenderer {
      constructor();
      /**
      * @brief AMGParticleQuatRendererOrientationType getter
      * @return AMGParticleQuatRendererOrientationType
      */
      public orientationType: ParticleQuatRendererOrientationType;
      /**
      * @brief AMGParticleQuatRendererAlignType Getter
      * @return AMGParticleQuatRendererAlignType
      */
      public alignType: ParticleQuatRendererAlignType;
      /**
      * @brief Fix Direction Getter(only valid when OT_FIXED)
      * @return const Vector3f&: fix direction
      */
      public fixedDirection: Vector3f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine QuatRenderer Align Type
    */
    enum ParticleQuatRendererAlignType {
      /**
      * @brief Center-Top
      */
      TOP,
      /**
      * @brief CenterLine - Center
      */
      CENTER,
      /**
      * @brief CenterLine - Bottom
      */
      BOTTOM,
    }
    namespace ParticleQuatRendererAlignType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine Orientation Type
    */
    enum ParticleQuatRendererOrientationType {
      /**
      * @brief Always camera oritation
      */
      BILLBOARD,
      /**
      * @brief Always particle oritation
      */
      DIRECTION,
      /**
      * @brief Always shaped oritation
      */
      SHAPE,
      /**
      * @brief Always fixd oritation
      */
      FIXED,
    }
    namespace ParticleQuatRendererOrientationType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief ParticleSystem Particles Sorting Mode
    */
    enum ParticleRenderSortingMode {
      NONE,
      BY_DISTANCE,
      OLDEST_IN_FRONT,
      YOUNGEST_IN_FRONT,
    }
    namespace ParticleRenderSortingMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief  AmazingEngine Particle Renderer Base Class
    */
    class ParticleRenderer extends AObject {
      constructor();
      /**
      * @brief AMGParticleQuatRendererAlignType Getter
      * @return AMGParticleQuatRendererAlignType
      */
      public sortingMode: ParticleRenderSortingMode;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ParticleRendererSystem extends RendererSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief ParricleSystem Ring Buffer Mode
    */
    enum ParticleRingBufferMode {
      DISABLED,
      PAUSE_UNTIL_REPLACED,
      LOOP_UNTIL_REPLACED,
    }
    namespace ParticleRingBufferMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief ParticleSystem Simulation Space
    */
    enum ParticleSimulationSpace {
      LOCAL,
      WORLD,
      LOCAL_WITHOUT_PARENT_SCALE,
      WORLD_WITHOUT_PARENT_SCALE,
    }
    namespace ParticleSimulationSpace {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine Particle Spherer Renderer
    */
    class ParticleSphereRenderer extends ParticleRenderer {
      constructor();
      /**
      * @brief SphererRenderer rings getter
      * @return float m_numberOfRings
      */
      public numberOfRings: number;
      /**
      * @brief SphererRenderer segments getter
      * @return size_t: segments num
      */
      public numberOfSegments: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Particle SubEmitter propety
    * use transform to ref particleComponent
    */
    class ParticleSubEmitter extends AObject {
      constructor();
      public parentParticleComponent: ParticleComponent;
      /**
      * @brief getter for rtti sciprt binding
      * @return ParticleComponent* particle component
      */
      public particleComponent: ParticleComponent;
      /**
      * @brief SubEmitter entity's transform
      */
      public subEmitter: Transform;
      /**
      * @brief SubEmitter type
      */
      public type: SubEmitterType;
      /**
      * @brief SubEmitter probability
      */
      public probability: number;
      /**
      * @brief SubEmitter inherit emit particle propertys
      */
      public inheritType: DynamicBitset;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine Particle Trail Renderer
    */
    class ParticleTrailRenderer extends ParticleRenderer {
      constructor();
      /**
      * @brief Trail max elements getter
      * @return int trail max elements
      */
      public maxTrailElements: number;
      /**
      * @brief Trail length getter
      * @return float trail length
      */
      public trailLength: number;
      /**
      * @brief Trail change color getter
      * @return Vector4f: trail change color
      */
      public trailChangeColor: Vector4f;
      /**
      * @brief Trail change width getter
      * @return float trail change width
      */
      public trailChangeWidth: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Particle Trail Renderer V2
    */
    class ParticleTrailRendererV2 extends ParticleRenderer {
      constructor();
      /**
      * @brief Max trail segments
      */
      public trailSegments: number;
      /**
      * @brief A value between 0 and 1, describing the proportion of particles that have a Trail assigned to them. Unity assigns trails randomly, so this value represents a probability.
      */
      public ratio: number;
      /**
      * @brief A value between 0 and 1, describing the proportion of particles that have a Trail assigned to them. Unity assigns trails randomly, so this value represents a probability.
      */
      public lifeTime: Value;
      /**
      * @brief Define the distance a particle must travel before its Trail receives a new vertex.
      */
      public minimumVertexDistance: number;
      /**
      * @brief If this box is checked, Trails vanish instantly when their particles die. If this box is not checked, the remaining Trail expires naturally based on its own remaining lifetime.
      */
      public dieWithParticle: boolean;
      /**
      * @brief Choose whether the Texture applied to the Trail is stretched along its entire length, or if it repeats every N units of distance
      */
      public textureMode: TrailTextureMode;
      /**
      * @brief If enabled (the box is checked), the Trail width is multiplied by the particle size.
      */
      public sizeAffectWidth: boolean;
      /**
      * @brief If enabled (the box is checked), the Trail lifetime is multiplied by the particle size.
      */
      public sizeAffectLifeTime: boolean;
      /**
      * @brief If enabled (the box is checked), the Trail color is modulated by the particle color.
      */
      public inheritColor: boolean;
      /**
      * @brief A curve to control the width of the Trail over its length.
      */
      public widthOverTrail: Value;
      /**
      * @brief A curve to control the color of the entire Trail over the lifetime of the particle it is attached to.
      */
      public colorOverLifeTime: Vec4Value;
      /**
      * @brief A curve to control the color of the Trail over its length.
      */
      public colorOverTrail: Vec4Value;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief ParticleAffector Update Mode
    */
    enum ParticleUpdateMode {
      PARTICLE,
      PARTICLE_FRACTION,
      PS_SYSTEM,
    }
    namespace ParticleUpdateMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Pass
    */
    class Pass extends AObject {
      constructor();
      public shaders: Map;
      public angleBinaryPrograms: Map;
      /**
      * @brief Set attribute type map.
      * @param s key: attribute name, value: VertexAttribType.
      */
      public semantics: Map;
      public renderTexture: RenderTexture;
      /**
      * @brief set the clear color
      * @param c Color
      */
      public clearColor: Color;
      /**
      * @brief set the clear depth
      * @param c float
      */
      public clearDepth: number;
      /**
      * @brief set the clear type
      * @param ct AMGCameraClearType
      */
      public clearType: CameraClearType;
      /**
      * @brief Set render state.
      * @param rs RenderState to set.
      */
      public renderState: RenderState;
      public useFBOTexture: boolean;
      public useCameraRT: boolean;
      public useFBOFetch: boolean;
      public enableFBOFetch: boolean;
      public isFullScreenShading: boolean;
      public macrosMap: Map;
      public preprocess: boolean;
      /**
      * @brief Set the Pass Type
      * @param pt AMGPassType
      */
      public passType: PassType;
      /**
      * @brief Get Unified Shader Profile Asset of this pass.
      * @return SharePtr<KeywordProgram> : Unified Shader Descriptor Asset
      */
      public keywordProgram: KeywordProgramProfile;
      public lightMode: LightMode;
      public clearMoment: PassClearMoment;
      public instanceCount: number;
      public useGrabTexture: boolean;
      public useGrabTextureMipmap: boolean;
      public grabTextureName: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum PassClearMoment {
      CLEAR_BEFORE_RENDERING,
      CLEAR_ON_RENDERING,
    }
    namespace PassClearMoment {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief pass type
    */
    enum PassType {
      NORMAL,
      PIXELSELECT,
      PURECOLOR,
      SHADOW,
      SRPSPECIAL,
    }
    namespace PassType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine PathFollowerAffector
    * particle move following line segments
    */
    class PathFollowerAffector extends Affector {
      constructor();
      public spline: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class PathInfo extends AObject {
      constructor();
      public curvesInfoAry: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief physics2D system
    */
    class Physics2DSystem extends System {
      constructor();
      public handle: number;
      /**
      * @brief start to run simulation
      */
      public runSimulation(): void;
      /**
      * @brief stop simulation
      */
      public stopSimulation(): void;
      /**
      * @brief edit simulation
      */
      public editSimulation(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief bullet physics 3d system
    */
    class Physics3DSystem extends System {
      constructor();
      public autoStart: boolean;
      public handle: number;
      /**
      * @brief start to run simulation
      */
      public runSimulation(): void;
      /**
      * @brief stop simulation
      */
      public stopSimulation(): void;
      /**
      * @brief edit simulation
      */
      public editSimulation(): void;
      /**
      * @brief raytest for all object in physics system
      * @param from ray from point
      * @param to ray to point
      * @return Vector all hitting rigidbodys
      */
      public rayTest(from: Vector3f, to: Vector3f): Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief START status is the initial status.
    * RUN will enable the physics animation, STOP will pause the animation.
    */
    enum PhysicsDriverStatus {
      /**
      * @brief edit status, need do initialization from EDIT to RUN.
      */
      EDIT,
      /**
      * @brief running status
      */
      RUN,
      /**
      * @brief stop status
      */
      STOP,
    }
    namespace PhysicsDriverStatus {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief physics material
    */
    class PhysicsMaterial extends AObject {
      constructor();
      /**
      * @brief Set the Static Friction
      * @param staticFriction static friction
      */
      public staticFriction: number;
      /**
      * @brief Set the Dynamic Friction
      * @param dynamicFriction dynamic friction
      */
      public dynamicFriction: number;
      /**
      * @brief Set the Bounciness(also elasticity)
      * range [0-1]
      * @param bounciness bounciness
      */
      public bounciness: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum PinOrientation {
      LOCAL,
      POSITION,
      POSITION_ORIENTATION,
    }
    namespace PinOrientation {
      let RTTI: RTTIDescriptor;
    }
    class PinToMesh extends Component {
      constructor();
      public target: Transform;
      public uv: Vector2f;
      public offsetPosition: Vector3f;
      public offsetRotation: Vector3f;
      public modelScale: Vector3f;
      public orientation: PinOrientation;
      public useVertexNormal: boolean;
      public version: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class PinToMeshSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum PixelFormat {
      Invalid,
      A8Unorm,
      L8Unorm,
      LA8Unorm,
      GR4Unorm,
      ABGR4Unorm,
      ARGB4Unorm,
      RGBA4Unorm,
      BGRA4Unorm,
      B5G6R5Unorm,
      R5G6B5Unorm,
      A1BGR5Unorm,
      A1RGB5Unorm,
      RGB5A1Unorm,
      BGR5A1Unorm,
      R8Unorm,
      R8Snorm,
      R8Uscaleld,
      R8Sscaled,
      R8Uint,
      R8Sint,
      R8_sRGB,
      RG8Unorm,
      RG8Snorm,
      RG8Uscaled,
      RG8Sscaled,
      RG8Uint,
      RG8Sint,
      RG8_sRGB,
      RGB8Unorm,
      RGB8Snorm,
      RGB8Uscaled,
      RGB8Sscaled,
      RGB8Uint,
      RGB8Sint,
      RGB8_sRGB,
      BGR8Unorm,
      BGR8Snorm,
      BGR8Uscaled,
      BGR8Sscaled,
      BGR8Uint,
      BGR8Sint,
      BGR8_sRGB,
      RGBA8Unorm,
      RGBA8Snorm,
      RGBA8Uscaled,
      RGBA8Sscaled,
      RGBA8Uint,
      RGBA8Sint,
      RGBA8_sRGB,
      BGRA8Unorm,
      BGRA8Snorm,
      BGRA8Uscaled,
      BGRA8Sscaled,
      BGRA8Uint,
      BGRA8Sint,
      BGRA8_sRGB,
      ABGR8Unorm,
      ABGR8Snorm,
      ABGR8Uscaled,
      ABGR8Sscaled,
      ABGR8Uint,
      ABGR8Sint,
      ABGR8_sRGB,
      BGR10A2Unorm,
      BGR10A2Snorm,
      BGR10A2Uscaled,
      BGR10A2Sscaled,
      BGR10A2Uint,
      BGR10A2Sint,
      RGB10A2Unorm,
      RGB10A2Snorm,
      RGB10A2Uscaled,
      RGB10A2Sscaled,
      RGB10A2Uint,
      RGB10A2Sint,
      R16Unorm,
      R16Snorm,
      R16Uscaleld,
      R16Sscaled,
      R16Uint,
      R16Sint,
      R16Sfloat,
      RG16Unorm,
      RG16Snorm,
      RG16Uscaled,
      RG16Sscaled,
      RG16Uint,
      RG16Sint,
      RG16Sfloat,
      RGB16Unorm,
      RGB16Snorm,
      RGB16Uscaled,
      RGB16Sscaled,
      RGB16Uint,
      RGB16Sint,
      RGB16Sfloat,
      RGBA16Unorm,
      RGBA16Snorm,
      RGBA16Uscaled,
      RGBA16Sscaled,
      RGBA16Uint,
      RGBA16Sint,
      RGBA16Sfloat,
      R32Uint,
      R32Sint,
      R32Sfloat,
      RG32Uint,
      RG32Sint,
      RG32Sfloat,
      RGB32Uint,
      RGB32Sint,
      RGB32Sfloat,
      RGBA32Uint,
      RGBA32Sint,
      RGBA32Sfloat,
      R64Uint,
      R64Sint,
      R64Sfloat,
      RG64Uint,
      RG64Sint,
      RG64Sfloat,
      RGB64Sint,
      RGB64Sfloat,
      RGBA64Uint,
      RGBA64Sint,
      RGBA64Sfloat,
      RG11B10Ufloat,
      RGB9E5Ufloat,
      D16Unorm,
      D24X8Unorm,
      D32Sfloat,
      S8Uint,
      D16UnormS8Uint,
      D24UnormS8Uint,
      D32SfloatS8Uint,
      BC1_RGBUnorm,
      BC1_RGB_sRGB,
      BC1_RGBAUnorm,
      BC1_RGBA_sRGB,
      BC2_RGBAUnorm,
      BC2_RGBA_sRGB,
      BC3_RGBAUnorm,
      BC3_RGBA_sRGB,
      BC4_RUnorm,
      BC4_RSnorm,
      BC5_RGUnorm,
      BC5_RGSnorm,
      BC6H_RGBUfloat,
      BC6H_RGBSfloat,
      BC7_RGBAUnorm,
      BC7_RGBAUnorm_sRGB,
      ETC1_RGB8Unorm,
      ETC2_RGB8Unorm,
      ETC2_RGB8_sRGB,
      ETC2_RGB8A1Unorm,
      ETC2_RGB8A1_sRGB,
      ETC2_RGBA8Unorm,
      ETC2_RGBA8_sRGB,
      EAC_R11Unorm,
      EAC_R11Snorm,
      EAC_RG11Unorm,
      EAC_RG11Snorm,
      ASTC_4x4_LDR,
      ASTC_4x4_sRGB,
      ASTC_5x4_LDR,
      ASTC_5x4_sRGB,
      ASTC_5x5_LDR,
      ASTC_5x5_sRGB,
      ASTC_6x5_LDR,
      ASTC_6x5_sRGB,
      ASTC_6x6_LDR,
      ASTC_6x6_sRGB,
      ASTC_8x5_LDR,
      ASTC_8x5_sRGB,
      ASTC_8x6_LDR,
      ASTC_8x6_sRGB,
      ASTC_8x8_LDR,
      ASTC_8x8_sRGB,
      ASTC_10x5_LDR,
      ASTC_10x5_sRGB,
      ASTC_10x6_LDR,
      ASTC_10x6_sRGB,
      ASTC_10x8_LDR,
      ASTC_10x8_sRGB,
      ASTC_10x10_LDR,
      ASTC_10x10_sRGB,
      ASTC_12x10_LDR,
      ASTC_12x10_sRGB,
      ASTC_12x12_LDR,
      ASTC_12x12_sRGB,
      PVRTC1_RGB_2BPP,
      PVRTC1_RGB_4BPP,
      PVRTC1_RGBA_2BPP,
      PVRTC1_RGBA_4BPP,
      PVRTC2_RGBA_2BPP,
      PVRTC2_RGBA_4BPP,
      PVRTC1_RGB_2BPP_sRGB,
      PVRTC1_RGB_4BPP_sRGB,
      PVRTC1_RGBA_2BPP_sRGB,
      PVRTC1_RGBA_4BPP_sRGB,
      PVRTC2_RGBA_2BPP_sRGB,
      PVRTC2_RGBA_4BPP_sRGB,
    }
    namespace PixelFormat {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine PlaneColliderAffector
    */
    class PlaneColliderAffector extends BaseColliderAffector {
      constructor();
      public plane: Vector4f;
      public PLANE: Vector3f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief play mode
    */
    enum PlayMode {
      once,
      loop,
      pingpong,
      random,
    }
    namespace PlayMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief PNG Meta
    */
    class PngMeta extends Meta {
      constructor();
      /**
      * @brief init whether needed alpha premul at runtime
      * @param innerAlphaPremul alpha premul
      */
      public innerAlphaPremul: boolean;
      /**
      * @brief init whether had alpha premuled
      * @param outerAlphaPremul alpha premul
      */
      public outerAlphaPremul: boolean;
      /**
      * @brief Set whether to enable mipmap
      */
      public enableMipmap: boolean;
      /**
      * @brief get minimization filter mode
      */
      public filterMin: FilterMode;
      /**
      * @brief get magnification filter mode
      */
      public filterMag: FilterMode;
      /**
      * @brief set mipmap mode
      */
      public filterMipmap: FilterMipmapMode;
      /**
      * @brief get wrap mode S
      */
      public wrapModeS: WrapMode;
      /**
      * @brief get wrap mode T
      */
      public wrapModeT: WrapMode;
      /**
      * @brief get wrap mode R
      */
      public wrapModeR: WrapMode;
      /**
      * @brief get max anisotropy
      */
      public maxAnisotropy: number;
      /**
      * @brief whether this png is a color texture
      */
      public isColorTexture: boolean;
      public maxTextureSize: TextureResizeLevel;
      public needFlipY: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class PointCache extends AObject {
      constructor();
      public mesh: Mesh;
      public skinUniformName: string;
      public skin: Skin;
      public triangleUniformName: string;
      public triangleCount: number;
      public handle: number;
      public setSkinData(skin: Skin): void;
      public getPointsCount(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class PointEmitter extends Emitter {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of PointLight.
    */
    class PointLight extends Light {
      constructor();
      public range: number;
      /**
      * @brief get current pointlight's Attenuation Range
      * @return float m_attenuationRange
      */
      public attenuationRange: number;
      /**
      * @brief get light unit
      * @return lightunit
      */
      public lightUnit: LightUnit;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum PolygonMode {
      FILL,
      LINE,
      POINT,
    }
    namespace PolygonMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief port value type
    */
    enum PortValueType {
      NONE,
      /**
      * 0-1(vs width and height)
      */
      PERCENT,
      PIXEL,
    }
    namespace PortValueType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AR PoseTracker Component
    */
    class PoseTracker extends Component {
      constructor();
      /**
      * @brief  the local pose state of this PoseTracker
      * @return Vector3f pose
      */
      public pose: Vector3f;
      /**
      * @brief the local scale state of this PoseTracker
      * @return Vector3f scale
      */
      public scale: Vector3f;
      /**
      * @brief the local euler angles of the PoseTracker's orientation
      * @return Vector3f degrees
      */
      public degrees: Vector3f;
      /**
      * @brief Get the pose of this PoseTracker
      * @return const Matrix4x4f& the pose of the anchor associated with this PoseTracker
      */
      public state: Matrix4x4f;
      /**
      * @brief get the algorithm result of this PoseTracker
      * @return const Matrix4x4f& result
      */
      public result: Matrix4x4f;
      /**
      * @brief Obtain the anchor index of this PoseTracker
      * @return int the achor index
      */
      public anchorIndex: number;
      /**
      * @brief whether it should dirty the state of this PoseTracker
      * @return bool
      */
      public dirty: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class PostProcessor extends Component {
      constructor();
      public cameraName: string;
      public handle: number;
      public record(camera: Camera, commands: CommandBuffer): void;
      public process(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Prefab
    */
    class Prefab extends AObject {
      constructor();
      /**
      * @brief Set entities.
      * @param entities Entities to set.
      */
      public entities: Vector;
      public standaloneResources: Map;
      public handle: number;
      /**
      * @brief Init prefab from root entity, for lua use
      * @return bool
      */
      public init(): boolean;
      /**
      * @brief Get root entity.
      * @return Entity*
      */
      public getRootEntity(): Entity;
      /**
      * @brief instantiate prefab to scene
      * @param scene Scene
      * @param shouldUnpack When set to true, detach the created entity from the prefab resource
      * @return Entity* root entity
      */
      public instantiateToScene(scene: Scene, shouldUnpack: boolean): Entity;
      /**
      * @brief instantiate prefab to entity
      * @param scene Scene
      * @param Entity ent
      * @param shouldUnpack When set to true, detach the created entity from the prefab resource
      * @return Entity* root entity
      */
      public instantiateToEntity(scene: Scene, ent: Entity, shouldUnpack: boolean): Entity;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Express the instantiation of the prefab in the scene.
    */
    class PrefabInstance extends AObject {
      constructor();
      public overrides: Vector;
      /**
      * @brief set Prefab to current prefabInstance.
      * @param pre SharePtr for Prefab
      */
      public prefab: Prefab;
      public prefabInstancId: Guid;
      public parentId: Guid;
      public handle: number;
      /**
      * @brief Add Override. If an override can't be applied to the prefab instance, return false.
      */
      public addOverride(ov: PrefabOverride): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Store the PrefabInstance info, and the contrast relationship of object.
    */
    class PrefabInstanceConfig extends AObject {
      constructor();
      public configVersion: string;
      public prefabInstanceIdMap: Map;
      public prefabInstanceList: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief This class is to describe nested Prefab.
    */
    class PrefabInstanceOverride extends PrefabOverride {
      constructor();
      public addPrefabInstance: PrefabInstance;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Provide load/manage of prefab funcs
    */
    class PrefabLoader extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief get prefab's status
      * @param prefabPath string
      * @return AMGPrefabStatus prefab's status
      */
      public getStatus(prefabPath: string): PrefabStatus;
      /**
      * @brief get a prefab from prefabLoader
      * @param prefabPath string
      * @return Prefab* prefab
      */
      public get(prefabPath: string): Prefab;
      /**
      * @brief remove a prefab from prefabLoader
      * @param prefabPath string
      */
      public remove(prefabPath: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief PrefabManager, load / create prefab.
    */
    class PrefabManager extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief Load a prefab from file.
      * @param path Absolute directory path.
      * @param name Prefab file relative path.
      * @return Prefab*
      */
      public loadPrefab(path: string, name: string): Prefab;
      /**
      * @brief Submit a prefab loading task.
      * @param path Absolute directory path.
      * @param name Prefab file relative path.
      * @return AsyncLoadingHandle
      */
      public loadPrefabAsync(path: string, name: string): AsyncLoadHandle;
      /**
      * @brief Create a prefab by file path.
      * @param path Absolute directory path.
      * @param name Prefab file relative path.
      * @return Prefab*
      */
      public getOrCreatePrefab(path: string, name: string): Prefab;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief  Override base class, include all type to prefab.
    */
    class PrefabOverride extends AObject {
      constructor();
      public overrideObjectGuid: Guid;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief PrefabOverrideType
    */
    enum PrefabOverrideType {
      None,
      ComponentOverride,
      EntityOverride,
      PrefabInstanceOverride,
    }
    namespace PrefabOverrideType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Prefab status
    */
    enum PrefabStatus {
      INIT,
      LOADING,
      LOADED,
      ERROR,
      NO_EXIST,
    }
    namespace PrefabStatus {
      let RTTI: RTTIDescriptor;
    }
    class Preset extends AObject {
      constructor();
      public properties: Map;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum Primitive {
      POINTS,
      LINES,
      LINE_LOOP,
      LINE_STRIP,
      TRIANGLES,
      TRIANGLE_STRIP,
      TRIANGLE_FAN,
      UNKOWN,
    }
    namespace Primitive {
      let RTTI: RTTIDescriptor;
    }
    class Profiler extends AObject {
      constructor();
      public handle: number;
      public calcFPS(): void;
      public beginFrame(): void;
      public getFPS(): number;
      public endFrame(): void;
      public getNumOfVerticees(): number;
      public getNumOfIndices(): number;
      public getNumOfJoints(): number;
      public getNumOfMorpherCount(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief PropertySheet
    */
    class PropertySheet extends AObject {
      constructor();
      /**
      * @brief Set float property map.
      * @param props Float map.
      */
      public floatmap: Map;
      /**
      * @brief Set vec4 property map.
      * @param props Vec4 map.
      */
      public vec4map: Map;
      /**
      * @brief Set vec3 property map.
      * @param props Vec3 map.
      */
      public vec3map: Map;
      /**
      * @brief Set vec2 property map.
      * @param props Vec2 map.
      */
      public vec2map: Map;
      /**
      * @brief set matrix property map.
      * @param props Matrix map.
      */
      public mat4map: Map;
      /**
      * @brief Set texture property map.
      * @param props Texture map.
      */
      public texmap: Map;
      /**
      * @brief Set integer property map.
      * @param props Integer map.
      */
      public intmap: Map;
      public handle: number;
      /**
      * @brief Get a named texture value.
      * @param name The name of the property.
      * @return Texture* The value of the property.
      */
      public getTex(name: string): Texture;
      /**
      * @brief Sets a named texture value.
      * @param name The name of the property.
      * @param tex Texture value to set.
      */
      public setTex(name: string, tex: Texture): void;
      public getImage(name: string): Texture;
      public setImage(name: string, image: Texture): void;
      /**
      * @brief Get a named buffer value.
      * @param name The name of the property.
      * @return Buffer* The value of the property.
      */
      public getBuffer(name: string): Buffer;
      /**
      * @brief Sets a named buffer value.
      * @param name The name of the property.
      * @param buffer Buffer value to set.
      */
      public setBuffer(name: string, buffer: Buffer): void;
      /**
      * @brief Get a named float value.
      * @param name The name of the property.
      * @return const float&  The value of the property.
      */
      public getFloat(name: string): number;
      /**
      * @brief Sets a named float value.
      * @param name The name of the property.
      * @param f Float value to set.
      */
      public setFloat(name: string, value: number): void;
      /**
      * @brief Get a named vec4 value.
      * @param name The name of the property.
      * @return const Vector4f& The value of the property.
      */
      public getVec4(name: string): Vector4f;
      /**
      * @brief Sets a named vec4 value.
      * @param name The name of the property.
      * @param c Vec4 value to set.
      */
      public setVec4(name: string, v: Vector4f): void;
      /**
      * @brief Get a named vec3 value.
      * @param name The name of the property.
      * @return const Vector3f& The value of the property.
      */
      public getVec3(name: string): Vector3f;
      /**
      * @brief Sets a named vec3 value.
      * @param name The name of the property.
      * @param c Vec3 value to set.
      */
      public setVec3(name: string, v: Vector3f): void;
      /**
      * @brief Get a named vec2 value.
      * @param name The name of the property.
      * @return const Vector2f& The value of the property.
      */
      public getVec2(name: string): Vector2f;
      /**
      * @brief Sets a named vec2 value.
      * @param name The name of the property.
      * @param c Vec2 value to set.
      */
      public setVec2(name: string, v: Vector2f): void;
      /**
      * @brief Get a named matrix value.
      * @param name The name of the property.
      * @return const Matrix4x4f& The value of the property.
      */
      public getMat4(name: string): Matrix4x4f;
      /**
      * @brief Sets a named matrix value.
      * @param name The name of the property.
      * @param c Matrix value to set.
      */
      public setMat4(name: string, v: Matrix4x4f): void;
      /**
      * @brief Get a named integer value.
      * @param name The name of the property.
      * @return const int& The value of the property.
      */
      public getInt(name: string): number;
      /**
      * @brief Sets a named integer value.
      * @param name The name of the property.
      * @param c Integer value to set.
      */
      public setInt(name: string, v: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum PropertyType {
      RIGID_BODY_MASS,
      RIGID_BODY_INERTIA_TENSOR_DIAGONAL,
      RIGID_BODY_LINEAR_DAMPING,
      RIGID_BODY_ROTATIONAL_DAMPING,
      RIGID_BODY_EXTERNAL_FORCE,
      COLLIDER_RESTITUTION_COEF,
      COLLIDER_DYNAMIC_FRICTION_COEF,
      BOX_COLLIDER_HALF_EXTENT,
      SPHERE_COLLIDER_RADIUS,
      DISTANCE_JOINT_COMPRESS_COMPLIANCE,
      DISTANCE_JOINT_STRETCH_COMPLIANCE,
      DISTANCE_JOINT_DAMPING_COEF,
      FIXED_RELATIVE_ROTATION_JOINT_COMPLIANCE,
      FIXED_RELATIVE_ROTATION_JOINT_DAMPING_COEF,
      RIGID_BODY_EXTERNAL_TORQUE,
      COLLIDER_OFFSET,
      CAPSULE_COLLIDER_RADIUS,
      CAPSULE_COLLIDER_HEIGHT,
      RIGID_BODY_REST_POSITION,
      RIGID_BODY_RELATIVE_POS_ENTITY_SPACE,
      RIGID_BODY_VELOCITY,
    }
    namespace PropertyType {
      let RTTI: RTTIDescriptor;
    }
    class ProxyBase extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ProxyColor extends ProxyBase {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ProxyMatrix3x3f extends ProxyBase {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ProxyMatrix4x4f extends ProxyBase {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ProxyQuaternionf extends ProxyBase {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ProxyRect extends ProxyBase {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ProxyVector2f extends ProxyBase {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ProxyVector3f extends ProxyBase {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ProxyVector4f extends ProxyBase {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Pulse extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Quad extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief rasterization state
    */
    class RasterizationState extends AObject {
      constructor();
      /**
      * @brief set dpeth clamp enable
      * @param enable bool
      */
      public depthClampEnable: boolean;
      /**
      * @brief depth clamp enable name
      */
      public depthClampEnableName: string;
      /**
      * @brief set rasterizer discard enable
      * @param enable bool
      */
      public rasterizerDiscardEnable: boolean;
      /**
      * @brief rasterizer discard enable name
      */
      public rasterizerDiscardEnableName: string;
      /**
      * @brief set polygon mode
      * @param mode AMGPolygonMode
      */
      public polygonMode: PolygonMode;
      /**
      * @brief polygon mode name
      */
      public polygonModeName: string;
      /**
      * @brief set cull mode
      * @param mode AMGCullFace
      */
      public cullMode: CullFace;
      /**
      * @brief cull mode name
      */
      public cullModeName: string;
      /**
      * @brief set front face
      * @param face AMGFrontFace
      */
      public frontFace: FrontFace;
      /**
      * @brief front face name
      */
      public frontFaceName: string;
      /**
      * @brief set depth bias enable
      * @param enable bool
      */
      public depthBiasEnable: boolean;
      /**
      * @brief depth bias enable name
      */
      public depthBiasEnableName: string;
      /**
      * @brief set depth bias constant factor
      * @param factor float
      */
      public depthBiasConstantFactor: number;
      /**
      * @brief depth bias constant factor name
      */
      public depthBiasConstantFactorName: string;
      /**
      * @brief set depth bias clamp
      * @param clamp float
      */
      public depthBiasClamp: number;
      /**
      * @brief depth bias clamp name
      */
      public depthBiasClampName: string;
      /**
      * @brief set depth bias slope factor
      * @param factor float
      */
      public depthBiasSlopeFactor: number;
      /**
      * @brief depth bias slope factor name
      */
      public depthBiasSlopeFactorName: string;
      /**
      * @brief set line width
      * @param lineWidth float
      */
      public lineWidth: number;
      /**
      * @brief line width name
      */
      public lineWidthName: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class RateSensorAgent extends SensorAgent {
      constructor();
      public handle: number;
      public setRate(arg0: number): void;
      public getRate(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Raycaster extends Component {
      constructor();
      public layer: DynamicBitset;
      public raycasterType: RaycasterType;
      public handle: number;
      public isTouchInIF(viewPos: Vector2f): boolean;
      public raycastIF(viewPos: Vector2f): Vector;
      public raycast3D(viewPos: Vector2f): Vector;
      public viewPointHitPlane(viewPos: Vector2f, normal: Vector3f, d: number): Vector3f;
      public viewPointHitPlanes(multiPlanes: Vector, viewPos: Vector2f): Vec3Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum RaycasterType {
      AR,
      UI,
      ThreeD,
      TwoD,
      Other,
    }
    namespace RaycasterType {
      let RTTI: RTTIDescriptor;
    }
    class RecodeVideoResult extends AlgorithmResultEvent {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class RectTransform extends Component {
      constructor();
      public pivot: Vector2f;
      public anchorMax: Vector2f;
      public anchorMin: Vector2f;
      public width: number;
      public height: number;
      public rect: Vector4f;
      public position: Vector3f;
      public scale: Vector3f;
      public rotation: Vector3f;
      public parent: RectTransform;
      public children: Vector;
      public handle: number;
      public removeTransform(childTrans: RectTransform): boolean;
      public addTransform(childTrans: RectTransform): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief rectangle class define
    */
    class Rectangle extends AObject {
      constructor();
      /**
      * @brief get left coordinate
      */
      public left: number;
      /**
      * @brief get left coordinate
      */
      public right: number;
      /**
      * @brief get left coordinate
      */
      public top: number;
      /**
      * @brief get bottom coordinate
      */
      public bottom: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ReflectionProbe extends Component {
      constructor();
      public boxSize: Vector3f;
      public boxOffset: Vector3f;
      public folderIndex: number;
      public resolution: CubeMapResolution;
      public cubeMapTexArray: RenderTextureArray;
      public isReflectionCubeMapGenerated: boolean;
      public isBakingReflectionProbeTriggered: boolean;
      public boxProjection: boolean;
      public zone: AABB;
      public cubeMapTexture: TextureCube;
      public handle: number;
      public setSliceData(arg0: any, index: number): void;
      public getReflectionProbePosXYZ(): Vector3f;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ReflectionProbeSystem extends System {
      constructor();
      public handle: number;
      public getReflectionProbeNum(): number;
      public getReflectionProbe(index: number): ReflectionProbe;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum RenderCacheEventType {
      RC_TYPE_NONE,
      RC_TYPE_TEXTURE,
      RC_TYPE_STRING,
    }
    namespace RenderCacheEventType {
      let RTTI: RTTIDescriptor;
    }
    enum RenderCacheStatus {
      RC_STATUS_NONE,
      RC_STATUS_MODITY,
      RC_STATUS_REMOVE,
    }
    namespace RenderCacheStatus {
      let RTTI: RTTIDescriptor;
    }
    class RenderContext extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class RenderObject extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class RenderPipelineSetting extends Component {
      constructor();
      public PipelineType: RenderPipelineType;
      public LuaPath: string;
      public handle: number;
      public getPipelineLuaScript(): Script;
      public getPipelineJSScript(): JSScript;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum RenderPipelineType {
      BUILD,
      LUASRP,
      JSSRP,
    }
    namespace RenderPipelineType {
      let RTTI: RTTIDescriptor;
    }
    class RenderQueueRange extends AObject {
      constructor();
      public lowerBound: number;
      public upperBound: number;
      public all: RenderQueueRange;
      public transparent: RenderQueueRange;
      public opaque: RenderQueueRange;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief render state
    */
    class RenderState extends AObject {
      constructor();
      /**
      * @brief set viewport state
      * @param state ViewportState
      */
      public viewport: ViewportState;
      /**
      * @brief set scissor state
      * @param state ScissorState
      */
      public scissor: ScissorState;
      /**
      * @brief set rasterization state
      * @param state RasterizationState
      */
      public rasterization: RasterizationState;
      /**
      * @brief set depth stencil state
      * @param state DepthStencilState
      */
      public depthstencil: DepthStencilState;
      /**
      * @brief set color blend state
      * @param state ColorBlendState*
      */
      public colorBlend: ColorBlendState;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class RenderSystem extends System {
      constructor();
      public handle: number;
      public submitRenderCommand(isFinish: boolean): void;
      public beginFrame(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class RenderTarget extends AObject {
      constructor();
      public attachment: AttachmentTarget;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of render texture
    */
    class RenderTexture extends Texture {
      constructor();
      /**
      * Get render texture attachment type
      */
      public attachment: RenderTextureAttachment;
      /**
      * Set input texture
      */
      public inputTexture: Texture;
      /**
      * Set MSAA mode
      */
      public massMode: MSAAMode;
      public shared: boolean;
      public needInitData: boolean;
      /**
      * @brief Set rt's color format with dirty check
      * @param colorFormat color format
      */
      public colorFormat: PixelFormat;
      public realColorFormat: PixelFormat;
      /**
      * @brief Set the Depth Texture
      * @param depthTexture depth texture
      */
      public depthTexture: DrawTexture;
      /**
      * @brief Set the Stencil Texture
      * @param stencilTexture stencil texture
      */
      public stencilTexture: DrawTexture;
      /**
      * @brief Set the Color Textures
      * @param colorTextures color textures
      */
      public colorTextures: Vector;
      public handle: number;
      /**
      * Get whether this render texture is shared for reusing
      */
      public getShared(): boolean;
      /**
      * Set whether this render texture is shared for reusing
      */
      public setShared(value: boolean): void;
      /**
      * GetPixel at (x, y)
      */
      public getPixel(x: number, y: number): Vector4f;
      /**
      * Get pixels at positions
      */
      public getPixels(positions: UInt16Vector): Vec4Vector;
      public saveToFile(filepath: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class RenderTextureArray extends RenderTexture {
      constructor();
      public handle: number;
      public saveToFileWithSlice(filepath: string, slice: number): void;
      public getTextureData(slice: number, arg1: any): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Enum class of render texture attachment
    */
    enum RenderTextureAttachment {
      /**
      * < NONE
      */
      NONE,
      /**
      * < DEPTH
      */
      DEPTH,
      /**
      * < DEPTH_STENCIL
      */
      DEPTH_STENCIL,
      /**
      * < DEPTH16
      */
      DEPTH16,
      /**
      * < DEPTH24
      */
      DEPTH24,
      /**
      * < DEPTH24_STENCIL8
      */
      DEPTH24_STENCIL8,
      /**
      * < STENCIL8
      */
      STENCIL8,
    }
    namespace RenderTextureAttachment {
      let RTTI: RTTIDescriptor;
    }
    class RenderTextureConfig extends AObject {
      constructor();
      public width: number;
      public height: number;
      public depth: number;
      public builtinType: BuiltInTextureType;
      public internalFormat: InternalFormat;
      public dataType: DataType;
      public attachment: RenderTextureAttachment;
      public filterMag: FilterMode;
      public filterMin: FilterMode;
      public filterMipmap: FilterMipmapMode;
      public colorFormat: PixelFormat;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Renderer base class
    */
    class Renderer extends BehaviorComponent {
      constructor();
      /**
      * @brief set shared materials
      * @param mats materials
      */
      public sharedMaterials: Vector;
      /**
      * @brief set first shared material
      * @param mat material
      */
      public sharedMaterial: Material;
      /**
      * @brief set property block
      * @param props MaterialPropertyBlock
      */
      public props: MaterialPropertyBlock;
      /**
      * @brief set sorting order
      * @param order sorting order
      */
      public sortingOrder: number;
      /**
      * @brief set auto sorting order
      * @param autoSorting auto sorting
      */
      public autoSortingOrder: boolean;
      /**
      * @brief set instantiated materials
      * @param mats materials
      */
      public materials: Vector;
      /**
      * @brief set first instantiated material
      * @param mat material
      */
      public material: Material;
      /**
      * @brief get use frustum culling
      * @return bool use frustum culling?
      */
      public useFrustumCulling: boolean;
      /**
      * @brief is renderer using custom projection matrix
      * @return bool is renderer using custom projection matrix
      */
      public useCustomProjectMatrix: boolean;
      /**
      * @brief get custom projection matrix
      * @return matrix
      */
      public customProjectMatrix: Matrix4x4f;
      public receiveShadow: boolean;
      public lightProbeBlendMode: LightProbeBlendMode;
      public entirePingPong: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class RendererSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum RendererType {
      Null,
      Direct3D9,
      Direct3D10,
      Direct3D11,
      Direct3D12,
      Gnm,
      Metal,
      OpenGLES2,
      OpenGLES30,
      OpenGLES31,
      OpenGLES32,
      OpenGL,
      Vulkan,
      Auto,
      Count,
    }
    namespace RendererType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief rigidbody2D
    */
    class RigidBody2D extends Component {
      constructor();
      /**
      * @brief set initial position
      * @param pos vector3f position
      */
      public initPosition: Vector3f;
      /**
      * @brief set initial rotation, euler angle, unit radian
      * @param rotation vector3f rotation
      */
      public initRotation: Vector3f;
      /**
      * @brief set initial linear velocity
      * @param vel vector3f velocity
      */
      public initLinearVel: Vector3f;
      /**
      * @brief set initial angular velocity
      * @param vel vector3f angular velocity
      */
      public initAngularVel: Vector3f;
      /**
      * @brief Set the world Position
      * @param position position
      */
      public position: Vector3f;
      /**
      * @brief Set the Rotation euler angle, unit radian
      * @param rotation rotation
      */
      public rotation: Vector3f;
      /**
      * @brief Set the Linear Velocity
      * @param linear_vel linear velocity
      */
      public linearVel: Vector3f;
      /**
      * @brief Set the Angular Velocity
      * @param angular_vel angular velocity
      */
      public angularVel: Vector3f;
      /**
      * @brief Set the Linear Damping parameter
      * @param linearDamping linear damping
      */
      public linearDamping: number;
      /**
      * @brief Set the Angular Damping parameter
      * @param angularDamping angular damping
      */
      public angularDamping: number;
      /**
      * @brief Set the Gravity Scale parameter
      * larger gravity scale will increase this rigid body's gravity
      * @param gravityScale gravity scale
      */
      public gravityScale: number;
      /**
      * @brief set external force vector
      * @param Vector3f externalForce
      */
      public externalForce: Vector3f;
      /**
      * @brief set forcePosition vector
      * @param Vector3f forcePosition
      */
      public forcePosition: Vector3f;
      /**
      * @brief Set the Fixed Rotate property
      * set true will force rigid body only have linear movement
      * @param fixedRotate fixed rotate
      */
      public fixedRotate: boolean;
      /**
      * @brief Set the Awake status
      * set true will awake sleeped rigid bodies
      * @param awake awake
      */
      public awake: boolean;
      /**
      * @brief Set the Allow Sleep property
      * @param allow_sleep allow sleep
      */
      public allowSleep: boolean;
      /**
      * @brief Set the Rigid Body Type
      * @param rigidBodyType rigid body type
      */
      public rigidBodyType: RigidBodyType;
      /**
      * @brief Set the Collision Detection Type
      * @param collisionDetectionType collision detection type
      */
      public collisionDetectionType: CollisionDetectionType;
      public minSubSteps: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief rigidbody3D, bullet implementation
    */
    class RigidBody3D extends Component {
      constructor();
      /**
      * @brief get world position of the rigid body
      * @return Vector3f
      */
      public position: Vector3f;
      /**
      * @brief get world rotation
      * @return Quaternionf
      */
      public rotation: Quaternionf;
      /**
      * @brief get linear velocity of the rigid body
      * @return Vector3f
      */
      public linearVel: Vector3f;
      /**
      * @brief get angular velocity
      * @return Vector3f
      */
      public angularVel: Vector3f;
      /**
      * @brief get initial position
      * @return Vector3f
      */
      public initPosition: Vector3f;
      /**
      * @brief get initial orientation
      * @return Quaternionf
      */
      public initRotation: Quaternionf;
      /**
      * @brief get initial linear  velocity
      * @return Vector3f
      */
      public initLinearVel: Vector3f;
      /**
      * @brief get initial angular velocity
      * @return Vector3f
      */
      public initAngularVel: Vector3f;
      /**
      * @brief get mass
      * @return float
      */
      public mass: number;
      /**
      * @brief get physical materail
      * @return SharePtr<PhysicsMaterial>
      */
      public material: PhysicsMaterial;
      /**
      * @brief get linear damping
      * @return float
      */
      public linearDamping: number;
      /**
      * @brief get angular damping
      * @return float
      */
      public angularDamping: number;
      /**
      * @brief set gravity acceleration vector
      * @param Vector3f gravity
      */
      public gravityAcceleration: Vector3f;
      /**
      * @brief set external force vector
      * @param Vector3f externalForce
      */
      public externalForce: Vector3f;
      /**
      * @brief set forcePosition vector
      * @param Vector3f forcePosition
      */
      public forcePosition: Vector3f;
      /**
      * @brief set localInertiaScale of this rigidbody
      * @param float localInertiaScale
      */
      public localInertiaScale: number;
      /**
      * @brief get angular factor
      * @return Vector3f
      */
      public angularFactor: Vector3f;
      /**
      * @brief get linear factor
      * @return Vector3f
      */
      public linearFactor: Vector3f;
      /**
      * @brief get rigid body type
      * @return RigidBodyType
      */
      public rigidBodyType: RigidBodyType;
      /**
      * @brief get collision detection type
      * @return CollisionDetectionType
      */
      public collisionDetectionType: CollisionDetectionType;
      /**
      * @brief set required minimum sub steps of this rigidbody
      * @param int minSubsteps
      */
      public minSubSteps: number;
      /**
      * @brief get sensor enabled flag
      * @return bool
      */
      public sensor: boolean;
      /**
      * @brief Set the Allow Sleep property
      * @param allow_sleep allow sleep
      */
      public allowSleep: boolean;
      /**
      * @brief get category bits
      * @return int
      */
      public categoryBits: number;
      /**
      * @brief get mask bits
      * @return int
      */
      public maskBits: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief rigid body type
    * static means this body can't be move, like ground or some building.
    * kinematic means this body move only according to user's input. it won't be affected by physical world but it can
    * affect other dynamic rigid body. dynamic means this body move according to the physical rule.
    */
    enum RigidBodyType {
      /**
      * @brief static rigid body, can't be move
      */
      STATIC,
      /**
      * @brief kinematic, will collides other rigid body, but its own position is only influenced by users.
      */
      KINEMATIC,
      /**
      * @brief general dynamic rigid body, collide others and collided by others
      */
      DYNAMIC,
      /**
      * @brief use position-constrained dynamic type rigidbody to simulate kinematic type for better collision detection performance when speed is fast.
      */
      KINEMATIC_FAST_MODE,
    }
    namespace RigidBodyType {
      let RTTI: RTTIDescriptor;
    }
    class RotateAction extends BaseAction {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Gesture type rotation.
    */
    class RotateGesture extends Gesture {
      constructor();
      /**
      * @brief The angle of rotation.
      */
      public angle: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief image frame rotate type
    *
    */
    enum RotateType {
      ROTATE_0,
      ROTATE_90,
    }
    namespace RotateType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine RotationAffector
    */
    class RotationAffector extends Affector {
      constructor();
      /**
      * @brief RotationAffector x rotation speed getter
      * @return Value*
      */
      public XRotationSpeed: Value;
      /**
      * @brief RotationAffector y rotation speed getter
      * @return Value*
      */
      public YRotationSpeed: Value;
      /**
      * @brief RotationAffector z rotationspeed getter
      * @return Value*
      */
      public ZRotationSpeed: Value;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief rotation limit component abstract class
    */
    class RotationLimit extends Component {
      constructor();
      /**
      * @brief get limit axis
      * @return Vector3f axis vector
      */
      public axis: Vector3f;
      public handle: number;
      /**
      * @brief set initial local rotation
      * @param q rotation
      */
      public setDefaultLocalRotation(q: Quaternionf): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief limit rotation by swing angle and twist angle
    */
    class RotationLimitAngle extends RotationLimit {
      constructor();
      /**
      * @brief get swing limit angle
      * @return float swing limit angle
      */
      public swing: number;
      /**
      * @brief get twist limit angle
      * @return float twist limit angle
      */
      public twist: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief limit rotation by a hinge struct
    */
    class RotationLimitHinge extends RotationLimit {
      constructor();
      /**
      * @brief set max hinge angle
      * @param max hinge angle
      */
      public maxAngle: number;
      /**
      * @brief set min hinge angle
      * @param min hinge angle
      */
      public minAngle: number;
      /**
      * @brief set whether use min max hinge angle limit
      * @param isUseLimit flag
      */
      public useConstraint: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class RotationSensorAgent extends SensorAgent {
      constructor();
      public handle: number;
      public getData(): Quaternionf;
      public isValidData(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief sdf text component, with normal mode and degenerated.
    * signed distance text component has two modes. Normal mode will render text according to signed distance field, can get
    * high-quality text even when the text is scaled to a large size. Normal mode can also apply the EffectTextParam to get a more
    * colorful and interesting effect. Degenerated mode will render text according to pictures rendered by system api.
    * Text will get blur when scaled to a large size. It can't apply any EffectTextParam, no effect.
    */
    class SDFText extends BaseText {
      constructor();
      public drivenByScript: boolean;
      /**
      * @brief get the text color
      * @return const Vector4f&
      */
      public textColor: Vector4f;
      /**
      * @brief get random texture size, this value is used for EffectText.
      * @deprecated shouldn't use this function
      * @return const Vector2f&
      */
      public randomGridSize: Vector2f;
      /**
      * @brief get the enable flag of shadow rendering
      * @return bool
      */
      public shadowEnabled: boolean;
      /**
      * @brief get the shadow color
      * @return const Vector4f&  rgba
      */
      public shadowColor: Vector4f;
      /**
      * @brief get the text shadow offset deviated from the text itself.
      * @return Vector2f  distance unit is times of text row height
      */
      public shadowOffset: Vector2f;
      /**
      * @brief shadow smoothing is a value determining the length of gradient change between the shadow edge and the background.
      * @return float distance unit is the times of text row height.
      */
      public shadowSmoothing: number;
      /**
      * @brief shadow blur is a value determining the blur radius of the pre-computed signed distance field. We don't compute gauss blur every frame, so we
      * choose to store blurred signed distance field to enhanced the shadow effect.
      * @return float  blur radius is how many times of the row height.
      */
      public shadowBlur: number;
      /**
      * @brief get the enable flag of the outline
      * @return bool
      */
      public outlineEnabled: boolean;
      /**
      * @brief get the outline width;
      * @return float  outline width is how many times of the text row height.
      */
      public outlineWidth: number;
      /**
      * @brief outline max width determine the uplimit of outline width parameter.
      * @return float  outline max width is how many times of the text row height.
      */
      public outlineMaxWidth: number;
      /**
      * @brief get the outline color
      * @return const Vector4f&  rgba
      */
      public outlineColor: Vector4f;
      /**
      * @brief bold width determine the width of char bold.
      * @return float  bold width is how many times of the text row height.
      */
      public boldWidth: number;
      /**
      * @brief italic degree determine the text oblique offset.
      * @return float italic degree is oblique angle in degree.
      */
      public italicDegree: number;
      /**
      * @brief get the enable flag of text underline.
      * @return bool.
      */
      public underlineEnabled: boolean;
      /**
      * @brief get underline width.
      * @return float underline width
      */
      public underlineWidth: number;
      /**
      * @brief get underline offset.
      * @return float underline offset
      */
      public underlineOffset: number;
      /**
      * @brief get the enable flag of background rendering
      * @return bool
      */
      public backgroundEnabled: boolean;
      /**
      * @brief get the background color
      * @return const Vector4f&  rgba
      */
      public backgroundColor: Vector4f;
      public backgroundRoundCornerEnabled: boolean;
      public backgroundRoundRadius: number;
      public backgroundWrappedEnabled: boolean;
      public backgroundRoundRadiusScale: number;
      public backgroundSplitThreshold: number;
      public backgroundSplitPadding: number;
      public backgroundCustomizedEnabled: boolean;
      public backgroundWHCustomized: Vector2f;
      public backgroundOffsetCustomized: Vector2f;
      /**
      * @brief get the overall alpha value for the whole SDFText, including backgound box, text emoji, text, shadow.
      * @return float the transparency, 0 for transparent, 1 for opaque.
      */
      public alpha: number;
      /**
      * @brief get the EffectTextParam pointer
      * @return EffectTextParam*
      */
      public effectTextParam: EffectTextParam;
      /**
      * @brief get ktv mode status
      * @return bool
      */
      public ktvEnabled: boolean;
      public ktvDirection: number;
      /**
      * @brief get the overall alpha for ktv effect, including shadow/ emoji/ text
      * @return float
      */
      public ktvAlpha: number;
      /**
      * @brief get the enable flag of rendering to rt
      * @return bool
      */
      public renderToRT: boolean;
      /**
      * @brief get the target rt extra size
      * @return const Vector2f& x:width y:height
      */
      public targetRTExtraSize: Vector2f;
      /**
      * @brief get ktv transparent ratio for full text.
      * @return float ktv transparent ratio.
      */
      public ktvTransparentRatio: number;
      /**
      * @brief get the max size of rt texture
      */
      public maxRTSize: number;
      public textWrapper: Text;
      public handle: number;
      /**
      * @brief call this function to typesetting text instantly. you can get the bounding box by getRect after.
      * use this if you can't wait the next frame to get the bounding box.
      */
      public forceTypeSetting(): void;
      public resetTypeSetting(): void;
      /**
      * @brief call this function to force update sdftexture
      */
      public forceSdfTexture(): void;
      public getRenderer(): Renderer;
      /**
      * @brief get texttexture object, characters' image data is stored in it.
      */
      public getTextTexture(): TextTexture;
      public getRectExpanded(): Rect;
      public setTextWrapper(text: Text): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SDFTextSystem extends BaseTextSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum SampleCountFlagBits {
      BIT_1,
      BIT_2,
      BIT_4,
      BIT_8,
      BIT_16,
      BIT_32,
      BIT_64,
      BITS_MAX,
    }
    namespace SampleCountFlagBits {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine ScaleAffector
    */
    class ScaleAffector extends Affector {
      constructor();
      /**
      * @brief  AMGAffectorScaleType Getter
      * @return AMGAffectorScaleType AmazingEngine ScaleAffectorType
      */
      public type: AffectorScaleType;
      /**
      * @brief Scale X Getter
      * @return Value*  Scale X
      */
      public scaleX: Value;
      /**
      * @brief Scale Y Getter
      * @return Value*  Scale Y
      */
      public scaleY: Value;
      /**
      * @brief Scale Z Getter
      * @return Value*  Scale Z
      */
      public scaleZ: Value;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Gesture type of scale.
    */
    class ScaleGesture extends Gesture {
      constructor();
      /**
      * @brief The value of scale.
      */
      public scale: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine ScaleVelocityAffector
    */
    class ScaleVelocityAffector extends Affector {
      constructor();
      /**
      * @brief Getter
      * @return const Value*: scale velocity
      */
      public scale: Value;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Scene
    */
    class Scene extends AObject {
      constructor();
      /**
      * @brief get edit scene guid for dual instance mode
      * @return Guid the edit scene guid
      */
      public editSceneGuid: Guid;
      public calibrateVer: string;
      /**
      * @brief Set the Entities object
      * @param entities entity list
      */
      public entities: Vector;
      public visible: boolean;
      public config: Map;
      public msaa: MSAAMode;
      public scriptSystems: StringVector;
      public jsScriptSystems: StringVector;
      public disabledSystems: StringVector;
      public enableMultiTouch: boolean;
      public enableLightMultiPass: boolean;
      public pixelLightCount: number;
      /**
      * @brief set Prefab Instance Config.
      * @param config SharePtr of PrefabInstanceConfig
      */
      public prefabInstanceConfig: PrefabInstanceConfig;
      public resourceRendererType: RendererType;
      public handle: number;
      /**
      * @brief create a new entity in the scene and give it a name
      * @param name entity name
      * @return Entity* new entity
      */
      public createEntity(name: string): Entity;
      /**
      * @brief remove an entity in the scene
      * @param entity entity name
      * @return true
      * @return false
      */
      public removeEntity(entity: Entity): boolean;
      /**
      * @brief remove all entities in the scene
      */
      public removeAllEntity(): void;
      /**
      * @brief clone an entity tree from other entity tree in the scene
      * @param srcEntity the other entity tree
      * @return Entity* cloned entity tree
      */
      public cloneEntityFrom(srcEntity: Entity): Entity;
      /**
      * @brief find entity by name from an entity tree or subtree in the scene
      * @param name entity name
      * @param root root entity of entity tree or subtree
      * @return Entity* found entity
      */
      public findEntityBy(name: string, root: Entity): Entity;
      /**
      * @brief find entities by name from an entity tree or subtree in the scene
      * @param name entity name
      * @param root root entity of entity tree or subtree
      * @return Vector found entity list
      */
      public findEntitiesByName(name: string, root: Entity): Vector;
      /**
      * @brief get system in the scene
      * @param type system type
      * @return System* system
      */
      public getSystem(type: string): System;
      /**
      * @brief get output render texture
      * @return RenderTexture* output render texture
      */
      public getOutputRenderTexture(): RenderTexture;
      public setOutputRenderTexture(texture: RenderTexture): void;
      /**
      * @brief get input texture by type
      * @param inputType input texture type
      * @return Texture* input texture
      */
      public getInputTexture(inputType: BuiltInTextureType): Texture;
      public setInputTexture(inputType: BuiltInTextureType, texture: Texture): void;
      /**
      * @brief broadcast event to all systems in the scene (generally the event will be cached)
      * @param event event
      */
      public postEvent(event: Event): void;
      /**
      * @brief broadcast event to all systems in the scene (generally the event will be responded immediately)
      * @param event event
      */
      public sendEvent(event: Event): void;
      /**
      * @brief lua send message to engine (generally the message will be cached)
      * @param unMsgID message id
      * @param arg1 parameter 1
      * @param arg2 parameter 2
      * @param arg3 parameter 3
      */
      public sendMessage(unMsgID: number, arg1: number, arg2: number, arg3: string): void;
      /**
      * @brief lua send message to engine (generally the message will be responded immediately)
      * @param unMsgID message id
      * @param arg1 parameter 1
      * @param arg2 parameter 2
      * @param arg3 parameter 3
      */
      public postMessage(unMsgID: number, arg1: number, arg2: number, arg3: string): void;
      /**
      * @brief commit command buffer
      * @param buffer command buffer
      */
      public commitCommandBuffer(buffer: CommandBuffer): void;
      /**
      * @brief instantiate prefab in the scene
      * @param prefab prefab
      * @return Entity* instantiated entity tree
      */
      public addInstantiatedPrefab(prefab: Prefab): Entity;
      /**
      * @brief instantiate prefab in the scene and attach to some entity
      * @param prefab prefab
      * @param entity entity
      * @return Entity* instantiated entity tree
      */
      public addInstantiatedPrefabToEntity(prefab: Prefab, entity: Entity): Entity;
      /**
      * @brief remove all systems in the scene
      */
      public removeAllSystems(): void;
      /**
      * @brief add system
      * @param sysName system name
      */
      public addSystem(sysName: string): void;
      /**
      * @brief set asset manager
      * @param assetManager asset manager
      */
      public setAssetManager(assetManager: AssetManager): void;
      public getEffectName(): string;
      public getSettings(): Map;
      public getTempRT(rtConfig: RenderTextureConfig, isScreenRT: boolean): RenderTexture;
      public releaseTempRT(tex: RenderTexture): void;
      /**
      * @brief get OETF of the scene
      * @return SceneOETF enum
      */
      public getSceneOETF(): void;
      /**
      * @brief set the value about whether should enable the multi-touch function
      * @param value true to enable the multi-touch function, otherwise disable
      */
      public setEnableMultiTouch(value: boolean): void;
      public addEntity(entity: Entity, index: number): void;
      public setCustomData(key: string, arg1: any): void;
      public getCustomData(key: string): void;
      public getLaunchMode(): string;
      public addScriptSystemPath(path: string): void;
      public removeScriptSystemPath(path: string): void;
      public addJSScriptSystemPath(path: string): void;
      public removeJSScriptSystemPath(path: string): void;
      public findRootEntityBy(name: string): Entity;
      public resetPrefabInstanceConfig(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SceneOutputRT extends RenderTexture {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief scissor state
    */
    class ScissorState extends AObject {
      constructor();
      /**
      * @brief get rect
      * @return const Rect&
      */
      public rect: Rect;
      /**
      * @brief rect name
      */
      public rectName: string;
      /**
      * @brief get value type
      * @return AMGPortValueType
      */
      public portValueType: PortValueType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of screen render texture
    */
    class ScreenRenderTexture extends RenderTexture {
      constructor();
      /**
      * @brief Get normalized width
      * @return normalized width
      */
      public pecentX: number;
      /**
      * @brief Get normalized height
      * @return normalized height
      */
      public pecentY: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ScreenTransform extends Transform {
      constructor();
      public anchoredPosition: Vector2f;
      public sizeDelta: Vector2f;
      public pivot: Vector2f;
      public anchors: Vector4f;
      public pixelsPerUnit: number;
      public offsets: Vector4f;
      public pivotNoTranslate: Vector2f;
      public localScale2D: Vector2f;
      public localRotation2D: number;
      public enablePivotMatrix: boolean;
      public rect: Rect;
      public parentRect: Rect;
      public handle: number;
      public isValidScreenHierarchy(): boolean;
      public getWorldCorners(): Vec3Vector;
      public calculateRectToAnchors(arg0: Rect): Vector4f;
      public setAnchorsNoTranslate(arg0: Vector4f): void;
      public forceUpdate(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ScreenTransformSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief A external resource
    */
    class Script extends AObject {
      constructor();
      /**
      * @brief set attached scene.
      * @param scene the pointer of the scene.
      */
      public scene: Scene;
      public handle: number;
      /**
      * @brief add event type the script listening.
      * @param type the event type.
      */
      public addEventType(type: number): void;
      /**
      * @brief remove listening for the event type.
      * @param type the event type.
      */
      public removeEventType(type: number): void;
      /**
      * @brief listening all event type for the script.
      */
      public addAllEventType(): void;
      /**
      * @brief remove all event type the script listening.
      */
      public clearAllEventType(): void;
      /**
      * @brief add object listener interface for script
      * @param object the target object to add listener
      * @param listenerType listenerType for listener
      * @param callback the callback function name in script for the listener
      * @param scriptUserData user data for this listener
      */
      public addScriptListener(object: AObject, listenerType: number, funcName: string, scriptUserData: AObject): void;
      public removeScriptListener(object: AObject, listenerType: number, funcName: string, scriptUserData: AObject): void;
      /**
      * @brief Add a component rtti type name that this script should handle. This method is called from script. Handling a component means this script will call onComponentAdded and onComponentRemoved functions when a component is added or removed.
      * @param compName the name of the component.
      */
      public handleComponentName(compName: string): void;
      /**
      * @brief This script will not handle any types of components. This method is called from script
      */
      public handleNoComponent(): void;
      /**
      * @brief This script will handle all types of component. This Method is called from script.
      */
      public handleAllComponent(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief This a component save the script path, properties, class name and cache.
    */
    class ScriptComponent extends BehaviorComponent {
      constructor();
      public path: string;
      /**
      * @brief Set the properties of script.
      * @param props the properties of script.
      */
      public properties: Map;
      /**
      * @brief Set the class name of script.
      * @param name the class name of script.
      */
      public className: string;
      public handle: number;
      /**
      * @brief Get script object.
      * @return Script*
      */
      public getScript(): Script;
      public call(arg0: string, arg1: Vector): void;
      public reloadScript(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ScriptMethodInfo extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ScriptRenderContext extends AObject {
      constructor();
      public attachScene: Scene;
      public isEditView: boolean;
      public handle: number;
      public setRenderTarget(targetRT: RenderTexture): void;
      public setRenderTargetWithSlice(targetRT: RenderTextureArray, slice: number): void;
      public clearRenderTarget(isClearColor: boolean, isClearDepth: boolean, clearColor: Color, clearDepth: number): void;
      public setViewport(viewport: Rect): void;
      public setGlobalFloat(value: string, arg1: number): void;
      public setGlobalVector4f(arg0: string, arg1: Vector4f): void;
      public setGlobalMatrix(arg0: string, arg1: Matrix4x4f): void;
      public setGlobalTexture2D(arg0: string, arg1: Texture2D): void;
      public setGlobalRenderTexture(arg0: string, arg1: RenderTexture): void;
      public setGlobalInt(arg0: string, arg1: number): void;
      public cull(cullParams: ScriptableCullingParameters): CullingResults;
      public drawRenderers(cullingResults: CullingResults, drawingSettings: DrawingSettings, filteringSettings: FilteringSettings): void;
      public drawRenderersWithState(cullingResults: CullingResults, drawingSettings: DrawingSettings, filteringSettings: FilteringSettings, srpRenderSateBlock: RenderState): void;
      public setupCameraProperties(camera: Camera): void;
      public execute(arg0: CommandBuffer): void;
      public submit(): void;
      public blit(src: Texture, dest: RenderTexture): void;
      public blitWithMaterial(src: Texture, dest: RenderTexture, material: Material, shaderPass: number): void;
      public blitWithMaterialAndProperties(src: Texture, dest: RenderTexture, material: Material, shaderPass: number, properties: MaterialPropertyBlock): void;
      public beginPassScope(passName: string): void;
      public endPassScope(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ScriptSerializedProperty extends AObject {
      constructor();
      public properties: Map;
      public handle: number;
      public getProperty(arg0: any): void;
      public setProperty(arg0: any, arg1: any): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ScriptSystem extends System {
      constructor();
      public handle: number;
      public sortScriptCompsByDepth(): void;
      public initAndStartScript(arg0: ScriptComponent): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class ScriptableCullingParameters extends AObject {
      constructor();
      public useCulling: boolean;
      public shadowCasters: boolean;
      public shadowRendererDynamic: boolean;
      public handle: number;
      public getCullingPlane(planeIndex: number): Vector4f;
      public setCullingPlane(planeIndex: number, planeContent: Vector4f): void;
      public setLayersWithVector(vector: Vector): void;
      public getLayersWithVector(): Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SensorAgent extends AObject {
      constructor();
      public handle: number;
      public setEnable(arg0: boolean): void;
      public isEnable(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Sensor Data Space
    */
    enum SensorDataSpace {
      Z_UP,
      Y_UP,
    }
    namespace SensorDataSpace {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief sensor event type
    */
    enum SensorEventType {
      GYRO,
    }
    namespace SensorEventType {
      let RTTI: RTTIDescriptor;
    }
    enum SensorFilterType {}
    namespace SensorFilterType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Sensor Type
    */
    enum SensorType {
      Gravity,
      Rotation,
      Gyro,
      Acceleration,
      Geomagnetic,
      Heading,
    }
    namespace SensorType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief resource type (MP4 unsupported)deprecated since 10.27.0
    */
    enum SeqAssetType {
      atlas,
      gif,
      mp4,
      webp,
    }
    namespace SeqAssetType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief class for SeqMesh
    */
    class SeqMesh extends AObject {
      constructor();
      /**
      * @brief readMask, each binary bit identifies whether a property is modified
      */
      public readMask: number;
      /**
      * @brief keyFrame index
      */
      public currentIndex: number;
      /**
      * @brief readMask & 0x1 >0, position need to be updated
      */
      public vertexDataList: Vector;
      /**
      * @brief readMask & 0x2 >0, uv need to be updated
      */
      public uvDataList: Vector;
      /**
      * @brief readMask & 0x4 >0, color need to be updated
      */
      public colorDataList: Vector;
      /**
      * @brief readMask & 0x8 >0, index need to be updated
      */
      public indexDataList: Vector;
      /**
      * @brief readMask & 0x10 >0, normal need to be updated
      */
      public normalDataList: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief class for the SeqMesh renderer
    */
    class SeqMeshRenderer extends Renderer {
      constructor();
      /**
      * @brief show
      */
      public castShadow: boolean;
      /**
      * @brief set mesh
      * @return Mesh* Mesh
      */
      public mesh: Mesh;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SeqMeshRendererSystem extends RendererSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief vertex/fragment/compute shader
    */
    class Shader extends AObject {
      constructor();
      /**
      * @brief get shader type
      * @return AMGShaderType
      */
      public type: ShaderType;
      /**
      * @brief get shader file path
      * @return const std::string&
      */
      public sourcePath: string;
      /**
      * @brief get this shader support macros
      * @return const StringVector&
      */
      public macros: StringVector;
      /**
      * @brief get shader source
      * @return const std::string& shader source
      */
      public source: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief A ShaderSnippet for referencing the shader source or shader file location.
    */
    class ShaderSnippet extends AObject {
      constructor();
      /**
      * @brief the source code of this ShaderSnippet
      */
      public source: string;
      /**
      * @brief the source code file location
      */
      public location: string;
      public binaryProgram: AngleBinaryProgram;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum ShaderType {
      VERTEX,
      FRAGMENT,
      COMPUTE,
      BINARY_PROGRAM,
    }
    namespace ShaderType {
      let RTTI: RTTIDescriptor;
    }
    class ShadowMapSystem extends System {
      constructor();
      public dirShadowLight: DirectionalLight;
      public dirShadowMap: RenderTexture;
      public spotShadowLight: SpotLight;
      public spotShadowMap: RenderTexture;
      public pointShadowLight: PointLight;
      public pointShadowMap: RenderTextureArray;
      public handle: number;
      public getShadowSystemEnable(): boolean;
      public getShadowLightEnable(light: Light): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SharedRenderTexture extends RenderTexture {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine Sine Force Affector
    */
    class SineForceAffector extends BaseForceAffector {
      constructor();
      /**
      * @brief Sine force frequency min value getter
      * @return float frequency value
      */
      public frequencyMin: number;
      /**
      * @brief Sine force frequency max value getter
      * @return float frequency value
      */
      public frequencyMax: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Skeleton extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief class for skin
    */
    class Skin extends AObject {
      constructor();
      /**
      * @brief set skeleton root name
      * @param name name
      */
      public skelRootName: string;
      /**
      * @brief set joint list
      * @param jointList joint list
      */
      public joints: Vector;
      public rootTransform: Transform;
      /**
      * @brief set mesh
      * @return Mesh* Mesh
      */
      public meshCoarse: Mesh;
      public positionOnly: boolean;
      public useTangent: boolean;
      public meshCoarseTransform: Transform;
      /**
      * @brief set Dynamic Joint List
      * @param dynamicJointList Dynamic Joint List
      */
      public dynamicJoints: Vector;
      /**
      * @brief set Dynamic Joint collider list
      * @param dynamicJointColliderList Dynamic Joint collider list
      */
      public dynamicJointColliders: Vector;
      public rootBoneIndex: number;
      public handle: number;
      /**
      * @brief get skin result
      * @return Vec3Vector
      */
      public getSkinResult(bindMesh: Mesh, attribType: VertexAttribType, W2L: Matrix4x4f): Vec3Vector;
      public getSkinResultTangent(bindMesh: Mesh, W2L: Matrix4x4f): Vec4Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief class for skin mesh renderer
    */
    class SkinMeshRenderer extends Renderer {
      constructor();
      /**
      * @brief get mesh
      * @return Mesh*  the mesh
      */
      public mesh: Mesh;
      /**
      * @brief get the flag of using  texture gpu skinning
      * @return bool
      */
      public gpuTextureSkinning: boolean;
      /**
      * @brief get the flag of using coarse mesh fine mesh mapping,
      * @return bool
      */
      public useCoarseMesh: boolean;
      /**
      * @brief get if cast shadow or not
      * @return bool
      * @retval true cast shadow
      * @retval false not cast shadow
      */
      public castShadow: boolean;
      public useUboBone: boolean;
      /**
      * @brief get skin
      * @return SharePtr<Skin>  skin
      */
      public skin: Skin;
      public handle: number;
      public getBoundingBox(): AABB;
      /**
      * @brief attatch the skin
      * @param skin skin
      * @param skelRootEnt root node entity
      */
      public attachSkin(skin: Skin, skelRootEnt: Entity): void;
      public getMorphedMesh(): Mesh;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SkinMeshRendererSystem extends RendererSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SkyboxComponent extends CameraFollower {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief This class mainly focus on interaction with user and slam
    */
    class SlamHandler extends AObject {
      constructor();
      public viewTracker: ViewTracker;
      public handle: number;
      /**
      * @brief it will interact with plane through the ray casted by the center of the phone screen
      * @param index the index of the PoseTracker
      * @param touchPoint the point that be clicked on the phone screen
      * @return bool if interacts successfully return true, otherwith false
      */
      public rayCastHit(index: number, touchPoint: Vector2f): boolean;
      /**
      * @brief it will generate a tracking pose by the slam algorithm when hitting on the phone screen
      * @param index the index of the PoseTracker
      * @param touchPoint the point that be clicked on the phone screen
      * @return bool if generatesa pose successfully return true, otherwith false
      */
      public hitTest(index: number, touchPoint: Vector2f): boolean;
      /**
      * @brief it will interact with plane through the ray casted by the center of the phone screen
      * @param index the index of the PoseTracker
      * @param touchPoint the point that be clicked on the phone screen
      * @param force force dirty the rayCastHit
      * @return bool if interacts successfully return true, otherwith false
      */
      public rayCastHitWithForce(index: number, touchPoint: Vector2f, force: boolean): boolean;
      /**
      * @brief it will generate a tracking pose by the slam algorithm when hitting on the phone screen
      * @param index the index of the PoseTracker
      * @param touchPoint the point that be clicked on the phone screen
      * @param force force dirty the hitTest
      * @return bool if generatesa pose successfully return true, otherwith false
      */
      public hitTestWithForce(index: number, touchPoint: Vector2f, force: boolean): boolean;
      /**
      * @brief update the logic of the interaction
      */
      public update(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief slider joint 2d
    */
    class SliderJoint2D extends Joint2D {
      constructor();
      /**
      * @brief Set the Motorized
      * enable or disable motorized
      * @param motorized motorized
      */
      public motorized: boolean;
      /**
      * @brief Set the Motor Speed
      * the standard speed the motor want to keep
      * @param motorSpeed motor speed
      */
      public motorSpeed: number;
      /**
      * @brief Set the Motor Max Force
      * max torque the motor can provide, sometimes motor can't keep the standard
      * speed because torque has exceeded the max limit
      * @param maxForce max force
      */
      public motorMaxForce: number;
      /**
      * @brief enable or disable the Angle Limited
      * @param limited limited
      */
      public limited: boolean;
      /**
      * @brief Set the Lower Angle of limit
      * @param lowerLimit lower limit
      */
      public lowerLimit: number;
      /**
      * @brief Set the Upper Angle of limit
      * @param upperLimit upper limit
      */
      public upperLimit: number;
      /**
      * @brief Set the Slider Angle
      * slider angle determine the slider direction
      * @param angle angle
      */
      public sliderAngle: number;
      /**
      * @brief Set the Reference Angle
      * define the initial angle difference between two rigid body
      * @param angle angle
      */
      public referenceAngle: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum SnapShotRet {
      Disable,
      False,
      True,
    }
    namespace SnapShotRet {
      let RTTI: RTTIDescriptor;
    }
    enum SoftShadowType {
      PCF,
      VSM,
      EVSM,
      CSM,
    }
    namespace SoftShadowType {
      let RTTI: RTTIDescriptor;
    }
    class SortingSettings extends AObject {
      constructor();
      public sortingType: SortingType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SortingType extends AObject {
      constructor();
      public renderQueue: boolean;
      public backToFront: boolean;
      public frontToBack: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief sphere collider 3D
    */
    class SphereCollider3D extends Collider3D {
      constructor();
      /**
      * @brief radius
      */
      public radius: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine SphereColliderAffector
    */
    class SphereColliderAffector extends BaseColliderAffector {
      constructor();
      /**
      * @brief Radius Getter
      * @return float radius
      */
      public radius: number;
      /**
      * @brief Getter
      * @return bool innerCollision: true/false
      */
      public innerCollision: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine Particle SphereEmitter
    */
    class SphereEmitter extends Emitter {
      constructor();
      /**
      * @brief Sphere outer radius getter
      * @return Real ( outer radius )
      */
      public radius: number;
      /**
      * @brief Sphere inner radius getter
      * @return Real ( inner radius )
      */
      public inner_radius: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of SpotLight.
    */
    class SpotLight extends Light {
      constructor();
      /**
      * < The range of spotlight
      */
      public range: number;
      /**
      * @brief get current spotLight's Attenuation Range
      * @return float m_attenuationRange
      */
      public attenuationRange: number;
      /**
      * @brief get current spotLight's Inner Angle
      * @return float m_innerAngle
      */
      public innerAngle: number;
      /**
      * @brief get current spotlight's Outer Angle.
      * @return float
      */
      public outerAngle: number;
      /**
      * @brief get light unit
      * @return LightUnit
      */
      public lightUnit: LightUnit;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief spring joint 2d
    */
    class SpringJoint2D extends Joint2D {
      constructor();
      /**
      * @brief Set the distance two rigid body should keep.
      * @param distance distance
      */
      public distance: number;
      /**
      * @brief Set the Frequency
      * the frequency of the spring
      * value range [0,10000] if set to 0, this becomes a constant distance joint 2d
      * @param frequency frequency
      */
      public frequency: number;
      /**
      * @brief Set the Damping Ratio
      * the damping_ratio
      * value range [0,1] 0 means no damping, 1 means critical damping.
      * @param dampingRatio damping ratio
      */
      public dampingRatio: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /*!
    *@class Sprite
    *@brief 2D sprite
    */
    class Sprite extends AObject {
      constructor();
      public textureAtlases: Vector;
      public frameIndex: number;
      public renderMode: CanvasRenderMode;
      public isAtlasCached: boolean;
      public preLoadedCount: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief sprite renderer
    *
    */
    class Sprite2DRenderer extends Renderer {
      constructor();
      /**
      * @brief Set the Stretch Mode object
      *
      * @param mode stretch mode
      */
      public stretchMode: StretchMode;
      /**
      * @brief Set the Pivot object
      *
      * @param pivot center of rotation
      */
      public pivot: Vector2f;
      /**
      * @brief whether to flip
      *
      * @return true
      * @return false
      */
      public flip: boolean;
      /**
      * @brief whether to mirror
      *
      * @return true
      * @return false
      */
      public mirror: boolean;
      /**
      * @brief Set the Color object
      *
      * @param color color
      */
      public color: Vector4f;
      public handle: number;
      /**
      * @brief Get the Base Texture object
      *
      * @return const SharePtr<Texture>&
      */
      public getBaseTexture(): Texture;
      /**
      * @brief Set the Base Texture object
      *
      * @param tex main texture
      * @param outerRect outer rect
      * @param rotate ratate
      */
      public setBaseTexture(tex: Texture, outerRect: Vector4f, rotate: RotateType): void;
      /**
      * @brief Get the Texture Size object
      *
      * @return const Vector2f&
      */
      public getTextureSize(): Vector2f;
      /**
      * @brief set texture from device texture manager map by key
      */
      public setTexFromKey(key: string): void;
      /**
      * @brief Set the Texture Size object
      *
      * @param size texture size
      */
      public setTextureSize(arg0: Vector2f): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Sprite2DRendererSystem extends RendererSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SpriteRenderer extends Renderer {
      constructor();
      public sprite: Sprite;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SpriteRendererSystem extends RendererSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum SpriteType {
      QUAD,
      RECTANGLE,
      POLYGON,
      CIRCLE,
      SQUARE,
    }
    namespace SpriteType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief animation state transition type
    */
    enum StateTransitionType {
      /**
      * @brief lerp layer, blend with other lerp layers according to blending weight
      */
      linear,
    }
    namespace StateTransitionType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief static mesh collider 3D
    */
    class StaticMeshCollider3D extends Collider3D {
      constructor();
      /**
      * @brief static mesh
      */
      public mesh: Mesh;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum StencilOp {
      KEEP,
      ZERO,
      REPLACE,
      INCREMENT_AND_CLAMP,
      DECREMENT_AND_CLAMP,
      INVERT,
      INCREMENT_AND_WRAP,
      DECREMENT_AND_WRAP,
      MAX_ENUM,
    }
    namespace StencilOp {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief stencil op state
    */
    class StencilOpState extends AObject {
      constructor();
      /**
      * @brief set fail op
      * @param failOp AMGStencilOp
      */
      public failOp: StencilOp;
      /**
      * @brief fail op name
      */
      public failOpName: string;
      /**
      * @brief set pass op
      * @param passOp AMGStencilOp
      */
      public passOp: StencilOp;
      /**
      * @brief pass op name
      */
      public passOpName: string;
      /**
      * @brief set depth fail op
      * @param depthFailOp AMGStencilOp
      */
      public depthFailOp: StencilOp;
      /**
      * @brief depth fail op name
      */
      public depthFailOpName: string;
      /**
      * @brief set compare op
      * @param compareOp AMGCompareOp
      */
      public compareOp: CompareOp;
      /**
      * @brief compare op name
      */
      public compareOpName: string;
      /**
      * @brief set compare mask
      * @param compareMask uint32_t
      */
      public compareMask: number;
      /**
      * @brief compare mask name
      */
      public compareMaskName: string;
      /**
      * @brief set write mask
      * @param writeMask uint32_t
      */
      public writeMask: number;
      /**
      * @brief write mask name
      */
      public writeMaskName: string;
      /**
      * @brief set reference
      * @param reference uint32_t
      */
      public reference: number;
      /**
      * @brief reference name
      */
      public referenceName: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Sticker3DV3Component extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Sticker3DV3FaceDetectComponent extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Sticker3DV3System extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class StickerDownloadTask extends DownloadTask {
      constructor();
      public stickerId: string;
      public path: string;
      public progress: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Storage Buffer class
    */
    class StorageBuffer extends Buffer {
      constructor();
      public handle: number;
      /**
      * @brief function wrap for the previous function to avoid template in method bind
      * @return true if succeeded
      */
      public load(data: StructData): boolean;
      /**
      * @brief function wrap for the previous function to avoid template in method bind
      * @param size new size of wrap
      */
      public resize(size: number): void;
      public setData(updateFractionalFlag: boolean, offset: number, data: StructData, vec3vec: Vec3Vector, default_w: number): boolean;
      public getData(dataType: string, indices: Int32Vector): FloatVector;
      public readFromFile(filePath: string, dataType: string, name: string): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief stretch mode
    *
    */
    enum StretchMode {
      fit,
      fill,
      stretch,
      fit_height,
      fit_width,
      fill_cut,
      texture_size,
    }
    namespace StretchMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief StructData loaded to Shader by lua
    */
    class StructData extends AObject {
      constructor();
      public handle: number;
      /**
      * @brief add new bool property for the StructData
      * @param name name of the property
      * @param b value of the property
      * @return this pointer
      */
      public addBool(name: string, b: boolean): StructData;
      /**
      * @brief add new 32bit integer property for the StructData
      * @param name name of the property
      * @param i value of the property
      * @return this pointer
      */
      public addInt32(name: string, i: number): StructData;
      /**
      * @brief add new 32bit float property for the StructData
      * @param name name of the property
      * @param f value of the property
      * @return this pointer
      */
      public addFloat(name: string, f: number): StructData;
      /**
      * @brief add new float32x2-simd property for the StructData
      * @param name name of the property
      * @param vec2 value of the property
      * @return this pointer
      */
      public addVector2f(name: string, vec4: Vector2f): StructData;
      /**
      * @brief add new float32x4-simd property for the StructData
      * @param name name of the property
      * @param vec4 value of the property
      * @return this pointer
      */
      public addVector4f(name: string, vec4: Vector4f): StructData;
      /**
      * @brief add new float32x4x4-matrix property for the StructData
      * @param name name of the property
      * @param mat4 value of the property
      * @return this pointer
      */
      public addMatrix4x4f(name: string, mat4: Matrix4x4f): StructData;
      /**
      * @brief add new 32bit integer vector property for the StructData
      * @param name name of the property
      * @param i value of the property
      * @return this pointer
      */
      public addInt32Vector(name: string, i: Int32Vector): StructData;
      /**
      * @brief add new 32bit float vector property for the StructData
      * @param name name of the property
      * @param f value of the property
      * @return this pointer
      */
      public addFloatVector(name: string, f: FloatVector): StructData;
      /**
      * @brief add new float32x2-simd vector property for the StructData
      * @param name name of the property
      * @param vec2 value of the property
      * @return this pointer
      */
      public addVec2Vector(name: string, vec4: Vec2Vector): StructData;
      /**
      * @brief add new float32x4-simd property vector for the StructData
      * @param name name of the property
      * @param vec4 value of the property
      * @return this pointer
      */
      public addVec4Vector(name: string, vec4: Vec4Vector): StructData;
      /**
      * @brief add new float32x4x4-matrix vector property for the StructData
      * @param name name of the property
      * @param mat4 value of the property
      * @return this pointer
      */
      public addMat4Vector(name: string, mat4: Mat4Vector): StructData;
      /**
      * @brief add new StructData property for the StructData
      * @param name name of the property
      * @param data value of the property SharePtr pointer
      * @return this pointer
      */
      public addStructData(name: string, struct: StructData): StructData;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief SubEmitter type
    */
    enum SubEmitterType {
      /**
      * @brief emit sub emitter when birth
      */
      Birth,
      /**
      * @brief emit sub emitter when death
      */
      Death,
      /**
      * @brief emit sub emitter when collision
      */
      Collision,
      /**
      * @brief emit sub emitter when manual lua script
      */
      Manual,
    }
    namespace SubEmitterType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief class for submesh
    */
    class SubMesh extends AObject {
      constructor();
      /**
      * @brief get the enable flag of indices32
      * @return bool
      */
      public useIndices32: boolean;
      /**
      * @brief get bounding box
      * @return AABB& the bounding box
      */
      public boundingBox: AABB;
      /**
      * @brief get the Indices16
      * @return UInt16Vector& Indices16
      */
      public indices16: UInt16Vector;
      /**
      * @brief get the Indices32
      * @return UInt32Vector& Indices32
      */
      public indices32: UInt32Vector;
      /**
      * @brief set index count
      * @param count index count
      */
      public indicesCount: number;
      /**
      * @brief set instance count
      * @param count instance count
      */
      public instanceCount: number;
      /**
      * @brief get the primitive type
      * @return AMGPrimitive primitive type
      */
      public primitive: Primitive;
      public baseVertex: number;
      /**
      * @brief get mesh
      * @return Mesh* mesh
      */
      public mesh: Mesh;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief system base
    *
    */
    class System extends AObject {
      constructor();
      public scene: Scene;
      public handle: number;
      /**
      * @brief set whether the system is enable
      * @param b whether the system is enable
      */
      public setEnable(b: boolean): void;
      public addEventType(type: number): void;
      public clearAllEventType(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class SystemList extends AObject {
      constructor();
      public systemList: StringVector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief property table for flexible data storage, do not use this if you have other choices
    */
    class TableComponent extends Component {
      constructor();
      /**
      * @brief set property table
      * @param table property table
      */
      public table: Map;
      /**
      * @brief set table type name
      * @param type table type name
      */
      public type: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TableReflection extends AObject {
      constructor();
      public type: string;
      public props: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Gesture type tap.
    */
    class TapGesture extends Gesture {
      constructor();
      /**
      * @brief The position of tap.
      */
      public point: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum TexSeqAssetType {
      image,
      atlas,
      gif,
      mp4,
    }
    namespace TexSeqAssetType {
      let RTTI: RTTIDescriptor;
    }
    class Text extends Component {
      constructor();
      public activeTextStyle: LetterStyle;
      public letters: Vector;
      public str: string;
      public richStr: string;
      public typeSettingParam: TextTypeSettingParam;
      public canvas: TextCanvas;
      public backgrounds: Vector;
      public textLocale: TextLocale;
      public textDirectionLevel: TextDirectionLevel;
      public globalAlpha: number;
      public resolutionAdapt: boolean;
      public outlineMaxWidth: number;
      public rootPath: string;
      public typeSettingDirty: boolean;
      public autoFontSizeRatio: number;
      public selectColor: Vector4f;
      public cutOffPostfix: string;
      public sdfTextAlpha: number;
      public fallbackFontPaths: Vector;
      public fixFontSize: boolean;
      public bloomEnable: boolean;
      public bloomScriptComp: ScriptComponent;
      public bloomPath: string;
      public bloomColorCustomized: boolean;
      public bloomColor: Vector4f;
      public bloomStrength: number;
      public bloomRange: number;
      public bloomDirX: number;
      public bloomDirY: number;
      public bloomBlurDegree: number;
      public bloomRtSize: Vector2f;
      public bloomRtSizeCoeff: number;
      public handle: number;
      public setString(arg0: string, arg1: boolean): void;
      public pushCommand(arg0: TextCommand): void;
      public forceFlushCommandQueue(): void;
      public instantiateLetterStyle(): void;
      public forceTypeSetting(): void;
      public getRenderer(): Renderer;
      public recordReuseStyle(arg0: Letter): void;
      public getCanvasCustomizedExpanded(): Rect;
      public getPlainStr(arg0: number, arg1: number, arg2: number): string;
      public getRichStr(arg0: number, arg1: number, arg2: number, arg3: number, arg4: boolean): string;
      public convertIdUToL(arg0: number): number;
      public convertIdUincodesToLetter(arg0: number, arg1: number): Vector2f;
      public convertIdLToU(arg0: number): number;
      public getCursorRect(): Rect;
      public getTextRect(arg0: number, arg1: number): Rect;
      public getLetterIndexByCursor(arg0: number): number;
      public getTextEditCursorIndex(): number;
      public getTextEditEnable(): boolean;
      public getTextEditHasSelected(): boolean;
      public getTextEditIsInputMethord(): boolean;
      public getSelectRange(): Vector3f;
      public getSelectHandleVisible(): boolean;
      public getgetSelectHandleIndex(): Vector2f;
      public getSelectHandleRect(): Vector;
      public getEditErrorCode(): number;
      public getEditErrorLog(): string;
      public getVisualLetterOrder(): Vector;
      public getLettersRect(startIndex: number, endIndex: number): Rect;
      public getLineNum(): number;
      public getLineIndexRange(arg0: number): Vector2f;
      public getLineVisualOrder(arg0: number): Vector;
      public getBloomMaterial(): Material;
      public setBloomMaterial(mat: Material): void;
      public getRectExpanded(): Rect;
      public applyTextStyle(arg0: string, arg1: Vector): boolean;
      public updateLetters(): void;
      public syncEditCursorIndex(arg0: Text): void;
      public syncTextData(arg0: Text): boolean;
      public updateBloomInfoByPath(arg0: string): void;
      public applyArtTextAsset(arg0: ArtTextAsset): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Text3D component
    */
    class Text3D extends BaseText {
      constructor();
      public charCenter: MeshCenter;
      public curve: MeshCurve;
      public curveSeg: number;
      public subdivisionLevel: number;
      public maxTris: number;
      public maxError: number;
      public extrudeNormal: MeshNormal;
      public extrude: number;
      public extrudeMiddle: number;
      public extrudeCap: number;
      public extrudeSeg: number;
      public genContours: boolean;
      public genTriMeshes: boolean;
      public skipRender: boolean;
      /**
      * @brief get material for this text3D component
      * @return SharePtr<Material>
      */
      public textMat: Material;
      /**
      * @brief get the clearMeshAfterUpload flag
      * @return bool
      */
      public clearMeshAfterUpload: boolean;
      public handle: number;
      /**
      * @brief call this function to typesetting text instantly. you can get the bounding box by getRect after.
      * use this if you can't wait the next frame to get the bounding box.
      */
      public forceTypeSetting(): void;
      /**
      * @brief Returns a vector of ContourSets (one for each glyph)
      */
      public getContours(): Vector;
      /**
      * @brief Returns a vector of TriMeshes (one for each glyph)
      */
      public getTriMeshes(): Vector;
      /**
      * @brief Returns a vector of Meshes (one for each glyph)
      */
      public getMeshes(): Vector;
      /**
      * @bried Returns a vector of transforms (one for each glyph)
      */
      public getLocalMatrices(): Vector;
      /**
      * @brief Returns a vector of Entities (one for each glyph)
      */
      public getEntities(): Vector;
      /**
      * @brief Returns a vector of valid characters (spaces, etc. are excluded)
      */
      public getValidChars(): Vector;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Text3DSystem extends BaseTextSystem {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief five alignments of sdf textsystem
    */
    enum TextAlign {
      /**
      * < left align
      */
      LEFT,
      /**
      * < center align
      */
      CENTER,
      /**
      * < right align
      */
      RIGHT,
      /**
      * < up align
      */
      UP,
      /**
      * < down align
      */
      DOWN,
    }
    namespace TextAlign {
      let RTTI: RTTIDescriptor;
    }
    class TextBackground extends AObject {
      constructor();
      public enabled: boolean;
      public startIndex: number;
      public endIndex: number;
      public loop: boolean;
      public loopGap: number;
      public renderType: TextBackgroundRenderType;
      public color: Color;
      public alpha: number;
      public scale: number;
      public rotation: number;
      public expandX: number;
      public expandY: number;
      public offsetX: number;
      public offsetY: number;
      public roundness: number;
      public texturePath: string;
      public textureFlipX: boolean;
      public textureFlipY: boolean;
      public texture: Texture;
      public extraMatrix: Matrix4x4f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum TextBackgroundRenderType {
      SOLID,
      TEXTURE,
    }
    namespace TextBackgroundRenderType {
      let RTTI: RTTIDescriptor;
    }
    class TextCacheManager extends AObject {
      constructor();
      public handle: number;
      public findProcess(processName: string): Material;
      public addProcess(processName: string, process: Material): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TextCanvas extends AObject {
      constructor();
      public textRect: Rect;
      public canvasRect: Rect;
      public UIRect: Rect;
      public canvasEnabled: boolean;
      public canvasColor: Vector4f;
      public canvasRoundCornerEnabled: boolean;
      public canvasWrappText: boolean;
      public canvasRoundRadius: number;
      public canvasRoundRadiusScale: number;
      public canvasCustomizedEnabled: boolean;
      public canvasWHCustomized: Vector2f;
      public canvasOffsetCustomized: Vector2f;
      public renderToRT: boolean;
      public targetRTExtraSize: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TextCommand extends AObject {
      constructor();
      public type: number;
      public iParam1: number;
      public iParam2: number;
      public iParam3: number;
      public iParam4: number;
      public sParam1: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum TextDirection {
      LTR,
      RTL,
      MIXED,
    }
    namespace TextDirection {
      let RTTI: RTTIDescriptor;
    }
    enum TextDirectionLevel {
      LTR,
      RTL,
      DEFAULT_LTR,
      DEFAULT_RTL,
    }
    namespace TextDirectionLevel {
      let RTTI: RTTIDescriptor;
    }
    enum TextLocale {
      LTRLocale,
      RTLLocale,
    }
    namespace TextLocale {
      let RTTI: RTTIDescriptor;
    }
    class TextMaterialFiller extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TextProceduralTexture extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TextSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief TextTexture manages the sdf texture and bitmap texture uniformly. It automatically handle the character fallback logics.
    */
    class TextTexture extends AObject {
      constructor();
      public sdfTexture: RenderTexture;
      /**
      * @brief rg channels store the sdf value, ba channels store the blurred sdf value.
      */
      public nonsdfTexture: RenderTexture;
      /**
      * @brief store the mapping from character to its texture coordinates.
      */
      public charRectMap: Map;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TextTypeSettingParam extends AObject {
      constructor();
      public textAdaptiveCanvasEnabled: boolean;
      public autoAdaptDpiEnabled: boolean;
      public horizontalPadding: number;
      public verticalPadding: number;
      public letterSpacing: number;
      public lineSpacing: number;
      public wordWrapWidth: number;
      public wordWrapHeight: number;
      public canvasWHFixed: Vector2f;
      public typeSettingKind: TypesettingKind;
      public typeSettingDirect: TypesettingDirect;
      public typeSettingAlign: TypesettingAlign;
      public typeSettingAlignVertical: TypesettingAlignVertical;
      public lineBreakType: LineBreakType;
      public enablePathTypeSetting: boolean;
      public mergingIntoOneLine: boolean;
      public pathTypeSettingParam: PathInfo;
      public arcCurveAngle: number;
      public closestLineSpacing: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Texture base class
    */
    class Texture extends AbstractAsset {
      constructor();
      /**
      * @brief Set texture width
      */
      public width: number;
      /**
      * @brief Set texture height
      */
      public height: number;
      /**
      * @brief Set texture depth
      */
      public depth: number;
      /**
      * @brief Set texture format
      */
      public internalFormat: InternalFormat;
      /**
      * @brief Set texture data type
      */
      public dataType: DataType;
      /**
      * @brief Set texture builtIn type
      */
      public builtinType: BuiltInTextureType;
      /**
      * @brief Set whether to enable mipmap
      */
      public enableMipmap: boolean;
      /**
      * @brief Get minimization filter mode
      */
      public filterMin: FilterMode;
      /**
      * @brief Get magnification filter mode
      */
      public filterMag: FilterMode;
      /**
      * @brief Get mipmap mode
      */
      public filterMipmap: FilterMipmapMode;
      /**
      * @brief Get wrap mode of S dimension
      */
      public wrapModeS: WrapMode;
      /**
      * @brief Get wrap mode of T dimension
      */
      public wrapModeT: WrapMode;
      /**
      * @brief Get wrap mode of R dimension
      */
      public wrapModeR: WrapMode;
      /**
      * @brief Set the max anisotropy of current texture.
      * @param maxAnisotropy max anisotropy
      */
      public maxAnisotropy: number;
      public handle: number;
      /**
      * @brief get image buffer when format is rgba8.
      * @return image buffer
      */
      public getImage(): Image;
      public readImageData(): Image;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of Texture 2D
    */
    class Texture2D extends Texture {
      constructor();
      /**
      * Get image data
      */
      public image: Image;
      /**
      * @brief set texture2d can readable. Only readable texture2d can use getPixel.
      * @param isReadable readable or not
      */
      public readable: boolean;
      /**
      * @brief Set whether this is a color texture
      * @param isColorTexture is color texture
      */
      public isColorTexture: boolean;
      public maxTextureSize: TextureResizeLevel;
      public handle: number;
      /**
      * @brief Allocate GPU memory for the texture
      * @param image image data
      */
      public storage(image: Image): void;
      public syncResource(): void;
      /**
      * @brief get pixel value at position (x, y)
      * @param x horizontal value, left to right, range is [0, width)
      * @param y vertical value, top to bottom, range is [0, height)
      * @return Vector4f pixel, (r, g, b, a) each element range is [0,1]
      */
      public getPixel(x: number, y: number): Vector4f;
      public setPixels(pixels: Vector): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of texture 2D array
    */
    class Texture2DArray extends Texture {
      constructor();
      public imageProvider: ImageProvider;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Texture2DArrayDeprecated extends Texture {
      constructor();
      public index: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum Texture2DAssetFormat {
      unknown,
      png,
      jpeg,
      etc2,
      tga,
      hdr,
    }
    namespace Texture2DAssetFormat {
      let RTTI: RTTIDescriptor;
    }
    class Texture2DImporter extends AssetImporter {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Texture2DPlatformSetting extends AssetPlatformSetting {
      constructor();
      public textureFormat: Texture2DAssetFormat;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of Texture 3D
    */
    class Texture3D extends Texture {
      constructor();
      /**
      * Get image data
      */
      public image: Image;
      /**
      * @brief get texture3DProvider
      * @return SharePtr<Texture3DProvider>&
      */
      public tex3DProvider: ImageProvider;
      public handle: number;
      /**
      * Allocate GPU memory for the texture
      */
      public storage(image: Image): void;
      /**
      * Get image data
      */
      public getImage(): Image;
      /**
      * @brief set the pixels, this method can be called from script
      * @param pixels a vector contains pixels that each pixel is actually a Vector4f.
      *               The value of each component is in [0 ~ 1]
      */
      public setPixels(pixels: Vector): void;
      /**
      * @brief get pixel value at position (x, y)
      * @param x horizontal value, left to right, range is [0, width)
      * @param y vertical value, top to bottom, range is [0, height)
      * @param z depth value, front to back, range is [0, depth)
      * @return Vector4f pixel, (r, g, b, a) each element range is [0,1]
      */
      public getPixel(x: number, y: number, z: number): Vector4f;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief  AmazingEngine TextureAnimationAffector
    */
    class TextureAnimationAffector extends Affector {
      constructor();
      /**
      * @brief AMGAffectorTextureAnimationType Getter
      * @return AMGAffectorTextureAnimationType affector texture animation type
      */
      public type: AffectorTextureAnimationType;
      public timeStep: number;
      public useTimeStep: boolean;
      /**
      * @brief TextureCoordsStart Getter
      * @return unsigned short coord start
      */
      public coordStart: number;
      /**
      * @brief TextureCoordsEnd Getter
      * @return unsigned short
      */
      public coordEnd: number;
      /**
      * @brief StartRandom Getter
      * @return bool is start random
      */
      public isStartRandom: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /*!
    *@class TextureAtlas
    *@brief 
    */
    class TextureAtlas extends AObject {
      constructor();
      public texUri: string;
      public frames: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief TextureCube class
    */
    class TextureCube extends Texture {
      constructor();
      /**
      * @brief Get image provider object
      * @return image data provider
      */
      public imageProvider: ImageProvider;
      public coefficients: FloatVector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TextureDelegate extends Texture {
      constructor();
      public internalTexture: Texture;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /*!
    *@class TextureFrame
    *@brief 
    */
    class TextureFrame extends AObject {
      constructor();
      public pixelRect: Rect;
      public rotated: boolean;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief General option for texture generation
    */
    class TextureOption extends AObject {
      constructor();
      public axis: Vector3f;
      public squareOrigin: Vector3f;
      public squareU: Vector3f;
      public squareV: Vector3f;
      public type: MeshUVType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TextureRenderTarget extends RenderTarget {
      constructor();
      public texture: RenderTexture;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum TextureResizeLevel {
      32,
      64,
      128,
      256,
      512,
      1024,
      2048,
      4096,
      8192,
      16384,
      OFF,
    }
    namespace TextureResizeLevel {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief AmazingEngine TextureRotationAffector
    */
    class TextureRotationAffector extends Affector {
      constructor();
      /**
      * @brief AmazingEngine useOwnRotationSpeed Getter
      * @return bool useOwnRotationSpeed: true/false
      */
      public isUseOwnRotationSpeed: boolean;
      /**
      * @brief RotationSpeed Setter
      * @param dynRotationSpeed  RotationSpeed
      */
      public rotationSpeed: Value;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TextureSequence extends AObject {
      constructor();
      public assettype: TexSeqAssetType;
      public lazyload: boolean;
      public cache: boolean;
      public atlases: Vector;
      public memoryLimit: number;
      public preload: boolean;
      public indexAction: Map;
      public preloadCount: number;
      public handle: number;
      public getFrameCount(): number;
      public onLoadEnd(): void;
      public setTexture(index: number, texture: Texture): void;
      public releaseUnusedTextures(idx: number): void;
      public getRandomIndex(): number;
      public getRandomIndexs(start: number, end: number): Vector;
      public getShuffleIndexs(start: number, end: number): Vector;
      public updateLoop(loop: UInt32Vector): void;
      public preloadTex(curIndex: number, assetMgr: AssetManager): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Enum class of texture type
    */
    enum TextureType {
      /**
      * @brief Texture2D
      */
      TEXTURE2D,
      /**
      * @brief Texture2DArray
      */
      TEXTURE2DARRAY,
      /**
      * @brief Texture3D
      */
      TEXTURE3D,
      /**
      * @brief TextureCube
      */
      TEXTURECUBE,
      /**
      * @brief TextureCubeArray
      */
      TEXTURECUBEARRAY,
      /**
      * @brief Render Texture
      */
      TEXTURERENDERING,
      TEXTUREEXTERNAL,
    }
    namespace TextureType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief type of time interpolation
    * in physics simulation, all variables are computed discretely. So when you want to get its value in specific moment,
    * you need do time interpolation. NO means return a nearest result. INTERPOLATION return a interpolation result by the
    * previous frame. EXTRAPOLATION return a extrapolation result by the next frame.
    */
    enum TimeInterpolateType {
      /**
      * @brief no time interpolation
      */
      NO,
      /**
      * @brief time interpolation
      */
      INTERPOLATE,
      /**
      * @brief time extrapolation
      */
      EXTRAPOLATE,
    }
    namespace TimeInterpolateType {
      let RTTI: RTTIDescriptor;
    }
    class TimeRangeComponent extends Component {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TimeRangeSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TimerSystem extends System {
      constructor();
      public handle: number;
      public addTimer(timerId: number, timerType: BEFTimerType, milliSeconds: number): void;
      public removeTimer(timerId: number, timerType: BEFTimerType, milliSeconds: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Touch data of Amazing Engine.
    */
    class Touch extends AObject {
      constructor();
      /**
      * @brief The point of the first finger.
      */
      public point: Vector2f;
      /**
      * @brief The touch finger arrays.
      */
      public points: Vector;
      /**
      * @brief Id of The first finger.
      */
      public fingerId: number;
      /**
      * @brief Finger id array.
      */
      public fingerIds: Vector;
      /**
      * @brief Touch pressure of The first finger.
      */
      public pressure: number;
      /**
      * @brief Touch perssure array.
      */
      public pressures: Vector;
      /**
      * @brief The touch phase of the touch event.
      */
      public type: TouchPhase;
      /**
      * @brief The count of fingers.
      */
      public count: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief touch event type
    */
    enum TouchEventType {
      BEGAN,
      MOVED,
      ENDED,
      CANCELED,
    }
    namespace TouchEventType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Device touch phase
    */
    enum TouchPhase {
      /**
      * A finger touched the screen.
      */
      BEGIN,
      /**
      * A finger moved on the screen.
      */
      MOVE,
      /**
      * A finger was lifted from the screen. This is the final phase of a touch.
      */
      END,
      /**
      * The system cancelled tracking for the touch.
      */
      CANCEL,
    }
    namespace TouchPhase {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief TouchPointer
    */
    class TouchPointer extends AObject {
      constructor();
      /**
      * @brief pointerId: The id of this pointer.
      * On android, this will be between 0 and pointerCount
      * On ios, the value is a hash value.
      */
      public pointerId: number;
      /**
      * @brief evt: The Touch Type
      */
      public type: TouchType;
      /**
      * @brief x: the horizontal coordinate[0, 1] on screen associated with
      * this touch pointer
      */
      public x: number;
      /**
      * @brief y: the vertical coordinate[0, 1] on screen associated with
      * this touch pointer
      */
      public y: number;
      /**
      * @brief force: the current pressure of this touch pointer
      * Thre pressure generally ranges from 0 (no pressure at all) to
      * 1 (normal pressure)
      */
      public force: number;
      /**
      * @brief majorRaidus: the scaled value of the approximate size for
      * this touch pointer
      */
      public size: number;
      /**
      * @brief timestamp: the time about when the touch pointer created
      */
      public time: number;
      /**
      * @brief pointerCount: the count of the touch pointers that exist
      */
      public count: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Touch Sample Type
    */
    enum TouchSampleType {
      TOUCH_SAMPLE_ALL,
      TOUCH_SAMPLE_NEAREST,
      TOUCH_SAMPLE_UNIFORM,
    }
    namespace TouchSampleType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Touch Type
    */
    enum TouchType {
      TOUCH_BEGAN,
      TOUCH_MOVED,
      TOUCH_STATIONARY,
      TOUCH_ENDED,
      TOUCH_CANCELED,
    }
    namespace TouchType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief data type of the AniamzTrack
    */
    enum TrackDataType {
      FLOAT,
      VEC2,
      VEC3,
      VEC4,
      QUAT,
      /**
      * scale.xyz,quat.xyzw,pos.xyz
      */
      SRT_VEC,
    }
    namespace TrackDataType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief The Tracking Mode
    */
    enum TrackingMode {
      Rotation,
      Surface,
      World,
    }
    namespace TrackingMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief The type of the Slam Algorithm
    */
    enum TrackingType {
      Nail,
      ARKit,
    }
    namespace TrackingType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Trail Texture Mode
    */
    enum TrailTextureMode {
      /**
      * @brief Map the texture once along the entire length of the trail.
      */
      Stretch,
      /**
      * @brief Map the texture once along the entire time of the trai.
      */
      Distribute,
      /**
      * @brief Map the texture once along the entire length of the trail, assuming all vertices are evenly spaced.
      */
      DistributePerSegment,
      /**
      * @brief Repeat the texture along the trail, repeating at a rate of once per trail segment.
      */
      RepeatPerSegment,
    }
    namespace TrailTextureMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Transform.
    */
    class Transform extends Component {
      constructor();
      public localPosition: Vector3f;
      /**
      * @brief Get local scale.
      * @return Vector3f local scale.
      */
      public localScale: Vector3f;
      /**
      * @brief Gets the local rotation.
      * @return Quaternionf local rotation.
      */
      public localOrientation: Quaternionf;
      /**
      * @brief Get local matrix.
      * @return Matrix4x4f local matrix.
      */
      public localMatrix: Matrix4x4f;
      /**
      * @brief Sets the local euler angles.
      * @param eulerAngles local euler angle.
      */
      public localEulerAngle: Vector3f;
      /**
      * @brief Gets the world position.
      * @return Vector3f world position.
      */
      public worldPosition: Vector3f;
      /**
      * @brief Gets the Rotation in world space.
      * @return Quaternionf world orientation.
      */
      public worldOrientation: Quaternionf;
      /**
      * @brief Get world scale.
      * @return Vector3f world scale.
      */
      public worldScale: Vector3f;
      /**
      * @brief Sets the world euler angles.
      * @param eulerAngles world euler angle.
      */
      public worldEulerAngle: Vector3f;
      /**
      * @brief Set parent transform.
      * @param parent parent transform.
      */
      public parent: Transform;
      public children: Vector;
      /**
      * @brief Set right vector in world space.
      * @param right right vector in world space.
      */
      public right: Vector3f;
      /**
      * @brief Set up vector in world space.
      * @param up up vector in world space.
      */
      public up: Vector3f;
      /**
      * @brief Set forward vector in world space.
      * @param forward forward vector in world space.
      */
      public forward: Vector3f;
      public mobility: Mobility;
      public handle: number;
      /**
      * @brief Add child transform.
      * @return bool
      */
      public addTransform(childTrans: Transform): boolean;
      /**
      * @brief Remove child transform.
      * @return bool
      */
      public removeTransform(childTrans: Transform): boolean;
      /**
      * @brief Gets the world position.
      * @return Vector3f world position.
      */
      public getWorldPosition(): Vector3f;
      /**
      * @brief Set world position.
      * @param pos world position.
      */
      public setWorldPosition(worldPos: Vector3f): void;
      /**
      * @brief Get world scale.
      * @return Vector3f world scale.
      */
      public getWorldScale(): Vector3f;
      /**
      * @brief Set world scale.
      * @param scale world scale.
      */
      public setWorldScale(worldScale: Vector3f): void;
      /**
      * @brief Gets the Rotation in world space.
      * @return Quaternionf world orientation.
      */
      public getWorldOrientation(): Quaternionf;
      /**
      * @brief Sets the Rotation in world space.
      * @param orientation world orientation.
      */
      public setWorldOrientation(worldOrientation: Quaternionf): void;
      /**
      * @brief Set world matrix.
      * @param worldMat world matrix.
      */
      public setWorldMatrix(worldMat: Matrix4x4f): void;
      /**
      * @brief Get world matrix.
      * @return Matrix4x4f world matrix.
      */
      public getWorldMatrix(): Matrix4x4f;
      /**
      * @brief Rotates the transform so the forward vector points at /target/'s current position.
      * @param target Object to point towards.
      * @param up Vector specifying the upward direction. Make sure up vector not collinear with (target - eyepos)
      */
      public lookAt(target: Vector3f, up: Vector3f): void;
      /**
      * @brief Get world to local matrix.
      * @return Matrix4x4f matrix that converts a point from World To Local space
      */
      public getWorldToLocalMatrix(): Matrix4x4f;
      public setWorldTransform(worldPos: Vector3f, worldScale: Vector3f, worldOrientation: Quaternionf): void;
      public TransformPoint(inPoint: Vector3f): Vector3f;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TransformSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TranslateAction extends BaseAction {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Most basic 3D triangular mesh class
    * Vertex data is stored plainly in MeshVertices structure
    * Triangles are grouped in sub-meshes; Each sub mesh can have
    * a different material
    */
    class TriMesh extends AObject {
      constructor();
      public vertices: Vec3Vector;
      public normals: Vec3Vector;
      public texCoords: Vec2Vector;
      public indices: Int32Vector;
      public handle: number;
      public getVertexCount(): number;
      public getTriangleCount(): number;
      public getBoundingBox(): AABB;
      public getVolume(): number;
      public clone(): TriMesh;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class TweenSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief vertical or horizontal typesetting
    */
    enum TypeSettingKind {
      /**
      * horizontal typesetting
      */
      HORIZONTAL,
      /**
      * vertical typesetting
      */
      VERTICAL,
    }
    namespace TypeSettingKind {
      let RTTI: RTTIDescriptor;
    }
    enum TypesettingAlign {
      LEFT,
      CENTER,
      RIGHT,
      UP,
      DOWN,
    }
    namespace TypesettingAlign {
      let RTTI: RTTIDescriptor;
    }
    enum TypesettingAlignVertical {
      DEFAULT,
      UP,
      CENTER,
      DOWN,
    }
    namespace TypesettingAlignVertical {
      let RTTI: RTTIDescriptor;
    }
    enum TypesettingDirect {
      LEFT2RIGHT,
      RIGHT2LEFT,
    }
    namespace TypesettingDirect {
      let RTTI: RTTIDescriptor;
    }
    enum TypesettingKind {
      HORIZONTAL,
      VERTICAL,
    }
    namespace TypesettingKind {
      let RTTI: RTTIDescriptor;
    }
    class UIInteractionSystem extends System {
      constructor();
      public activeScriptComp: ScriptComponent;
      public currentCharLimit: any;
      public handle: number;
      public registerText(textId: number): void;
      public unregisterText(textId: number): void;
      public setText(textId: number, text: string): void;
      public showInputKeyboard(nArg1: number, nArg2: number, nArg3: string): void;
      public hideInputKeyboard(nArg1: number, nArg2: number, nArg3: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum UIKeyboardEvent {
      KeyboardHide,
      KeyboardInput,
    }
    namespace UIKeyboardEvent {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Uniform Base Class, include the type & value.
    */
    class Uniform extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Uniform Auto Binding, No use.
    */
    class UniformAutoBinding extends Uniform {
      constructor();
      /**
      * @brief get binding Type of current UniformAutoBinding.
      * @return AMGUniformBinding m_autoBindingType
      */
      public bindingType: UniformBinding;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Uniform binding, No Use.
    */
    enum UniformBinding {
      NONE,
      RENDER_WIDTH,
      RENDER_HEIGHT,
      SIM_TIME,
      SIM_SIN_TIME,
      CAMERA_WORLD_POS,
      CAMERA_NEAR_FAR,
      MODEL_MATRIX,
      MODEL_VIEW_MATRIX,
      MODEL_VIEW_PROJECTION_MATRIX,
      VIEW_MATRIX,
      INV_VIEW_MATRIX,
      PROJECTION_MATRIX,
      NORMAL_MATRIX,
      NORMAL_WORLD_MATRIX,
      BONE_MATRIXES,
    }
    namespace UniformBinding {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Uniform Buffer class
    */
    class UniformBuffer extends Buffer {
      constructor();
      public handle: number;
      /**
      * @brief function wrap for the previous function to avoid template in method bind
      * @return true if succeeded
      */
      public load(data: StructData): boolean;
      /**
      * @brief function wrap for the previous function to avoid template in method bind
      * @param size new size of wrap
      */
      public resize(size: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of UniformMat3, the value is mat3.
    */
    class UniformMat3 extends Uniform {
      constructor();
      /**
      * @brief set mat3 value
      * @param val m_value
      */
      public value: Matrix3x3f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of UniformMat4, the value is mat4.
    */
    class UniformMat4 extends Uniform {
      constructor();
      /**
      * @brief set mat4 value
      * @param val m_value
      */
      public value: Matrix4x4f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of UniformReal, the value is Real.
    */
    class UniformReal extends Uniform {
      constructor();
      /**
      * @brief set RealValue to Uniform
      * @param val m_value
      */
      public value: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of UniformRealArray, the value is RealArray.
    */
    class UniformRealArray extends Uniform {
      constructor();
      /**
      * @brief set Real Array value
      * @param val m_value
      */
      public value: FloatVector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of UniformSampler, the value is Texture.
    */
    class UniformSampler extends Uniform {
      constructor();
      /**
      * @brief set uniform's value
      * @param tex m_texture
      */
      public texture: Texture;
      /**
      * @brief get Texture Filter Mode
      * @return AMGFilterMode m_filterMode
      */
      public filter: FilterMode;
      /**
      * @brief get Texture Wrap Mode
      * @return AMGWrapMode m_wrapMode
      */
      public wrapMode: WrapMode;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum UniformType {
      REAL,
      VEC2,
      VEC3,
      VEC4,
      MAT3,
      MAt4,
      REAL_ARRAY,
      VEC2_ARRAY,
      VEC3_ARRAY,
      VEC4_ARRAY,
      SAMPLER,
    }
    namespace UniformType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Class of UniformVec2, the value is vec2.
    */
    class UniformVec2 extends Uniform {
      constructor();
      /**
      * @brief set vec2 value
      * @param val m_value
      */
      public value: Vector2f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of UniformVec2Array, the value is Vec2Array.
    */
    class UniformVec2Array extends Uniform {
      constructor();
      /**
      * @brief set vec2 array value
      * @param val m_value
      */
      public value: Vec2Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of UniformVec3, the value is vec3.
    */
    class UniformVec3 extends Uniform {
      constructor();
      /**
      * @brief set vec3 value
      * @param val m_value
      */
      public value: Vector3f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of UniformVec3Array, the value is Vec3Array.
    */
    class UniformVec3Array extends Uniform {
      constructor();
      /**
      * @brief set vec3 array value
      * @param val m_value
      */
      public value: Vec3Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of UniformVec4, the value is vec4.
    */
    class UniformVec4 extends Uniform {
      constructor();
      /**
      * @brief set vec4 value
      * @param val m_value
      */
      public value: Vector4f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Class of UniformVec4Array, the value is Vec4Array.
    */
    class UniformVec4Array extends Uniform {
      constructor();
      /**
      * @brief set vec4 array value
      * @param val m_value
      */
      public value: Vec4Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class UserEventHandleSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class VECodecFrameReader extends IVideoFrameReader {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class VEConfig extends AObject {
      constructor();
      public handle: number;
      public getConfig(keyStr: string): string;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum VFContextEvent {
      AFTER_POINTCACHE_UPDATE,
    }
    namespace VFContextEvent {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Import VF for texture 3d
    */
    class VFProvider extends ImageProvider {
      constructor();
      public handle: number;
      /**
      * @brief set VF image uri
      * @param uri uri
      */
      public setImageUri(uri: string): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum VFXBlendMode {
      VFXAddtive,
      VFXAlpha,
      VFXAlphaPremultipy,
      VFXOpaque,
    }
    namespace VFXBlendMode {
      let RTTI: RTTIDescriptor;
    }
    class VFXContextBlock extends AObject {
      constructor();
      /**
      * @brief context type
      */
      public type: ContextType;
      /**
      * @brief unique index
      */
      public index: number;
      /**
      * @brief uniform can be modified
      *
      */
      public exposeProperties: PropertySheet;
      /**
      * @brief
      *
      */
      public inCtxID: number;
      /**
      * @brief the index in siblings, to solve the order of gpu events
      *
      */
      public siblingCtxID: number;
      /**
      * @brief
      *
      */
      public shaders: Vector;
      public blendMode: VFXBlendMode;
      public materials: Vector;
      public depthTestMode: boolean;
      public depthWriteMode: boolean;
      public SemanticsVertexAttribMap: Map;
      /**
      * @brief m_externalUniform_order
      */
      public orderedUniform: Vector;
      /**
      * @brief m_layoutBuffers deprecated
      */
      public layoutBuffers: Vector;
      /**
      * @brief bytes of ssbo
      */
      public attributeSize: number;
      /**
      * @brief sort pass index
      */
      public sortPassIndices: Vector;
      /**
      * @brief mesh
      */
      public mesh: Mesh;
      /**
      * @brief AUSL profile
      */
      public keywordPrograms: Vector;
      public binaryPrograms: Vector;
      /**
      * @brief pointcache map index
      */
      public attributeMapIndices: Vector;
      /**
      * @brief cast shadow
      */
      public castShadow: boolean;
      /**
      * @brief bounding box
      */
      public boundingBox: AABB;
      public handle: number;
      public sendEvent(m_event: VFXEventType): void;
      public setExternalBuffer(uniformName: string, size: number, value: FloatVector): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief VFXContextBlock class
    */
    class VFXEffectBlock extends Component {
      constructor();
      public profile: VFXProfile;
      public isPlaying: boolean;
      public cameraEntity: Entity;
      public enableParticleCount: boolean;
      public aliveParticleCounts: Int32Vector;
      public handle: number;
      public reset(): void;
      public play(): void;
      public pause(): void;
      public stop(): void;
      public getCtxBlock(i: number): VFXContextBlock;
      public getCtxBlockWithID(index: number): VFXContextBlock;
      public setSystemSeed(seed: number): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum VFXEventType {
      VFXOnPlay,
      VFXOnStop,
      VFXOnBurst,
    }
    namespace VFXEventType {
      let RTTI: RTTIDescriptor;
    }
    class VFXProfile extends AObject {
      constructor();
      public ctxBlocks: Vector;
      public pointCaches: Vector;
      public attributeMapVec: Vector;
      public useInstancing: boolean;
      public handle: number;
      public getCtxBlock(i: number): VFXContextBlock;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum VFXProfileEvent {
      PROFILE_DIRTY,
    }
    namespace VFXProfileEvent {
      let RTTI: RTTIDescriptor;
    }
    class VFXRendererSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Value extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Amazing curve interpolation enum type
    */
    enum ValueCurveInterpolationType {
      /**
      * @brief interpolate with linear
      */
      LINEAR,
      /**
      * @brief interpolate with spline
      */
      SPLINE,
      /**
      * @brief do not interpolate
      */
      IMMEDIATE,
    }
    namespace ValueCurveInterpolationType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Curved type of value
    */
    class ValueCurved extends Value {
      constructor();
      /**
      * Get interpolation type
      */
      public interpolationType: ValueCurvedInterpolationType;
      public controlPoints: Vector;
      /**
      * Query if Curve value has dirtied
      */
      public dirty: boolean;
      public handle: number;
      /**
      * Get the value
      */
      public getValue(x: number): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Enum of Value Curved Interpolation Type
    */
    enum ValueCurvedInterpolationType {
      LINEAR,
      SPLINE,
      CATMULL,
    }
    namespace ValueCurvedInterpolationType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Fixed type of value
    */
    class ValueFixed extends Value {
      constructor();
      /**
      * Set the value
      */
      public value: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Oscillate type of value
    */
    class ValueOscillate extends Value {
      constructor();
      /**
      * Get oscillation type
      */
      public oscillationType: ValueOscillationType;
      /**
      * Set frequency
      */
      public frequency: number;
      /**
      * Set phase
      */
      public phase: number;
      /**
      * Set phase
      */
      public base: number;
      /**
      * Set amplitude
      */
      public amplitude: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Enum of Value Oscillation Type
    */
    enum ValueOscillationType {
      SINE,
      SQUARE,
    }
    namespace ValueOscillationType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief Random type of value
    */
    class ValueRandom extends Value {
      constructor();
      /**
      * Get minimum value
      */
      public min: number;
      /**
      * Get maximum value
      */
      public max: number;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Vec2Value extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Vec2 curve value
    */
    class Vec2ValueCurved extends Vec2Value {
      constructor();
      public iType: ValueCurveInterpolationType;
      public cpList: Vector;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class Vec4Value extends AObject {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Vec4 curve value
    * Use two Vec2ValueCurved for implementing Vec4ValueCurved
    */
    class Vec4ValueCurved extends Vec4Value {
      constructor();
      public vec2CurveX: Vec2ValueCurved;
      public vec2CurveY: Vec2ValueCurved;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Vec4 fixed value
    */
    class Vec4ValueFixed extends Vec4Value {
      constructor();
      public Vec4Value: Vector4f;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief class for the description of vertex attribute
    */
    class VertexAttribDesc extends AObject {
      constructor();
      /**
      * @brief get the type of attribute
      * @return AMGVertexAttribType type of attribute
      */
      public semantic: VertexAttribType;
      /**
      * @brief set the index of attribute binding
      * @param index index of attribute binding
      */
      public bindingIndex: number;
      /**
      * @brief set the offset of attribute
      * @param offset type offset value
      */
      public offset: number;
      /**
      * @brief set the count number of component
      * @param uint32_t count number
      */
      public componentCount: number;
      /**
      * @brief get the name of vertex attrib binding
      * @return Name attrib binding name
      */
      public name: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum VertexAttribType {
      /**
      * !< position
      */
      POSITION,
      /**
      * !< normal
      */
      NORMAL,
      /**
      * !< tangent
      */
      TANGENT,
      /**
      * !< color, 0-1
      */
      COLOR,
      /**
      * !< indices
      */
      INDICES,
      /**
      * !< weight
      */
      WEIGHT,
      /**
      * !< texcoord0
      */
      TEXCOORD0,
      /**
      * !< texcoord1
      */
      TEXCOORD1,
      /**
      * !< texcoord2
      */
      TEXCOORD2,
      /**
      * !< texcoord3
      */
      TEXCOORD3,
      /**
      * !< texcoord4
      */
      TEXCOORD4,
      /**
      * !< texcoord5
      */
      TEXCOORD5,
      /**
      * !< texcoord6
      */
      TEXCOORD6,
      /**
      * !< texcoord7
      */
      TEXCOORD7,
      /**
      * !< texcoord3D 0
      */
      TEXCOORD3D0,
      /**
      * !< texcoord3D 1
      */
      TEXCOORD3D1,
      /**
      * !< texcoord3D 2
      */
      TEXCOORD3D2,
      /**
      * !< texcoord3D 3
      */
      TEXCOORD3D3,
      /**
      * !< binormal
      */
      BINORMAL,
      /**
      * !< color1
      */
      COLOR1,
      /**
      * !< color2
      */
      COLOR2,
      /**
      * !< color3
      */
      COLOR3,
      /**
      * !< position offset
      */
      POSITION_OFFSET,
      /**
      * !< normal offset
      */
      NORMAL_OFFSET,
      /**
      * !< tangent offset
      */
      TANGENT_OFFSET,
      /**
      * !< binormal offset
      */
      BINORMAL_OFFSET,
      /**
      * !< user define0
      */
      USER_DEFINE0,
      /**
      * !< user define1
      */
      USER_DEFINE1,
      /**
      * !< user define2
      */
      USER_DEFINE2,
      /**
      * !< user define3
      */
      USER_DEFINE3,
      /**
      * !< UNKONW, must be at the end of enum
      */
      UNKOWN,
    }
    namespace VertexAttribType {
      let RTTI: RTTIDescriptor;
    }
    class VertexBuffer extends Buffer {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Video animation component
    */
    class VideoAnimSeq extends Component {
      constructor();
      /**
      * @brief get the relative path of the resource file (only for Video)
      * @return const std::string& relative path
      */
      public videoFilename: string;
      /**
      * @brief get Texture Sampler Name
      * @return const std::string& Texture Sampler name
      */
      public texName: string;
      /**
      * @brief get playback mode
      * @return AMGPlayMode playback mode
      */
      public playmode: PlayMode;
      /**
      * @brief get the number of cycles
      * @return float Cycles
      */
      public loopCount: number;
      /**
      * @brief get Play speed
      * @return float Play speed
      */
      public speed: number;
      /**
      * @brief get whether to play automatically
      * @return bool whether to play automatically
      */
      public autoplay: boolean;
      /**
      * @brief Set whether to enable alpha blend.
      * @param enableAlphaBlend true to indicate yes, otherwise no.
      */
      public enableAlphaBlend: boolean;
      public enableFixedSeekMode: boolean;
      public handle: number;
      /**
      * @brief play
      */
      public play(): void;
      /**
      * @brief pause
      */
      public pause(): void;
      /**
      * @brief Stop, the animation will reset to the initial state, frame 0
      */
      public stop(): void;
      /**
      * @brief seek to a frame
      * @param index index
      */
      public seek(index: number): void;
      /**
      * @brief seek to a certain time
      * @param localTime time
      */
      public seekToTime(localTime: number): void;
      /**
      * @brief The animation is reset to the initial state, frame 0
      */
      public resetAnim(): void;
      /**
      * @brief get total frame count
      * @return int32_t frame count
      */
      public getFrameCount(): number;
      public getDuration(): number;
      public getFrameIndex(): number;
      public getLocalTime(): number;
      public getVideoSize(): Vector2f;
      public isPlaying(): boolean;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief Video anim sequence key info
    */
    class VideoAnimSeqKeyInfo extends AObject {
      constructor();
      /**
      * @brief anim sequence event type
      */
      public type: AnimSeqEventType;
      /**
      * @brief video anim sequence component
      */
      public animSeqCom: VideoAnimSeq;
      /**
      * < key index
      */
      public keyIndex: number;
      /**
      * < key name
      */
      public keyName: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class VideoAnimSeqSystem extends System {
      constructor();
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class VideoAsset extends AObject {
      constructor();
      public loadConfig: Map;
      public processMaterials: Map;
      public settings: Map;
      public controller: VideoController;
      public handle: number;
      public initController(): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class VideoController extends AObject {
      constructor();
      public scene: Scene;
      public handle: number;
      public videoInfo(): VideoInfo;
      public seekFrame(timestamp: number): Texture;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class VideoInfo extends AObject {
      constructor();
      public width: number;
      public height: number;
      public duration: number;
      public bitRate: number;
      public frameRate: number;
      public videoCodec: string;
      public mediaFormat: string;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    class VideoPlayer extends AObject {
      constructor();
      public loop: boolean;
      public speed: number;
      public volume: number;
      public handle: number;
      public init(): boolean;
      public destroy(): void;
      public play(): void;
      public pause(): void;
      public resume(): void;
      public stop(): void;
      public getState(): VideoState;
      public seek(pos: number): boolean;
      public getFrame(): Texture2D;
      public setVideoSource(filePath: string): void;
      public getVideoSource(): string;
      public getFrameKey(): string;
      public size(): Vector2f;
      public length(): number;
      public currentTime(): number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum VideoState {
      VideoPlaying,
      VideoPaused,
      Err,
    }
    namespace VideoState {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief ViewTracker Component: if a entity with a camera component binds to this component,
    * the pose of this entity will be updated by this component
    */
    class ViewTracker extends Component {
      constructor();
      /**
      * @brief Obtain the type of the ar tracking algorithm that being used
      * @return AMGTrackingType
      */
      public trackingType: TrackingType;
      /**
      * @brief Get the tracking mode
      * @param AMGTrackingMode The tracking mode
      */
      public trackingMode: TrackingMode;
      /**
      * @brief Get the Unit of AR World
      * @return AMGARUnit The AR World Unit
      */
      public arUnit: ARUnit;
      /**
      * @brief Get whether this ViewTracker supports multi touch
      * @return bool support true, otherwith false
      */
      public multiTouch: boolean;
      /**
      * @brief Get the name of Algorithm node
      * @return name of Agorithm node
      */
      public algNode: string;
      public handle: number;
      /**
      * @brief Get the Slam Handler Handle
      * @return SlamHandler* Slam Handler Handle
      */
      public getSlamHandler(): SlamHandler;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief viewer event type
    */
    enum ViewerEventType {}
    namespace ViewerEventType {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief viewport state
    */
    class ViewportState extends AObject {
      constructor();
      /**
      * @brief get rect
      * @return const Rect& rect
      */
      public rect: Rect;
      /**
      * @brief rect name
      */
      public rectName: string;
      /**
      * @brief set min depth
      * @param depth float
      */
      public minDepth: number;
      /**
      * @brief min depth name
      */
      public minDepthName: string;
      /**
      * @brief set max depth
      * @param depth float
      */
      public maxDepth: number;
      /**
      * @brief max depth name
      */
      public maxDepthName: string;
      /**
      * @brief get value type
      * @return AMGPortValueType
      */
      public portValueType: PortValueType;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    /**
    * @brief AmazingEngine VortexAffector
    *
    */
    class VortexAffector extends Affector {
      constructor();
      /**
      * @brief RotationSpeed Getter
      * @return Value* RotationSpeed
      */
      public rotationSpeed: Value;
      public handle: number;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
    enum WrapMode {
      REPEAT,
      CLAMP,
      Mirror,
    }
    namespace WrapMode {
      let RTTI: RTTIDescriptor;
    }
    /**
    * @brief XShader
    */
    class XShader extends AObject {
      constructor();
      /**
      * @brief Set propertyies of this shader.
      * @param props PropertySheet.
      */
      public properties: PropertySheet;
      public renderQueue: number;
      /**
      * @brief Set passes.
      * @param passes Passes vector.
      */
      public passes: Vector;
      /**
      * @brief Get customized shadow map static model pass.
      * @return SharePtr<Pass>& default pass.
      */
      public shadowMapStaticPass: Pass;
      /**
      * @brief Get customized shadow map dynamic model pass.
      * @return SharePtr<Pass>& default pass.
      */
      public shadowMapDynamicPass: Pass;
      public fallbackShader: XShader;
      public handle: number;
      /**
      * @brief Add a pass at last.
      * @param pass Pass.
      */
      public addPass(pass: Pass): void;
      public eq(obj: AObject): boolean;
      public equals(obj: AObject): boolean;
      public release(): void;
    }
  }
}
declare namespace effect {
  namespace Amaz {
    class AEAlgorithmResult extends AObject {
      public getARScanInfo(index: number): ARScanInfoInterface;
      public getARScanInfoCount(): number;
      public getActionDetectCount(): number;
      public getActionDetectInfo(index: number): ActionDetectInfoInterface;
      public getActionRecognitionCount(): number;
      public getActionRecognitionInfo(index: number): ActionRecognitionInfoInterface;
      public getActionRecognitionIsExecuted(): boolean;
      public getAfterEffectInfo(): AfterEffectInfoInterface;
      public getAlgorithmInfo(algorithmType: string, graphName: string, nodeName: string, index: number): AObject;
      public getAlgorithmInfoByName(graphName: string, nodeName: string, index: number, outputIndex: number): AObject;
      public getAlgorithmInfoCount(graphName: string, nodeName: string, algorithmType: string, outputIndex: number): number;
      public getAlgorithmParam(key: string): Variant;
      public getApolloFace3dInfoClass(index: number): ApolloFace3DInfoClassInterface;
      public getApolloFace3dInfoClassCount(): number;
      public getAudioAvatarInfo(): AudioAvatarInfoInterface;
      public getAvacapInfo(index: number): AvacapInfoInterface;
      public getAvacapInfoCount(): number;
      public getAvatar3DFusionInfo(index: number): Avatar3DFusionInfoInterface;
      public getAvatar3DFusionInfoCount(): number;
      public getAvatar3DFusionInfoTracking(): boolean;
      public getAvatar3DInfo(index: number, graphName: string, nodeName: string): Avatar3DInfoInterface;
      public getAvatar3DInfoCount(graphName: string, nodeName: string): number;
      public getAvatar3DInfoTracking(): boolean;
      public getAvatar3DIsExecuted(graphName: string, nodeName: string): boolean;
      public getAvatarDriveCount(): number;
      public getAvatarDriveInfo(index: number): AvatarDriveInfoInterface;
      public getBGMangaInfo(): MangaInfoInterface;
      public getBeautyGanInfo(index: number): MegaClassicGanInfoInterface;
      public getBeautyGanInfoCount(): number;
      public getBgInfo(): MattingResultInterface;
      public getBigGanInfo(index: number): MegaClassicGanInfoInterface;
      public getBigGanInfoCount(): number;
      public getBinocularFaceCount(): number;
      public getBlingInfo(): BlingResultInterface;
      public getBlitImage(graphName: string, nodeName: string): BachImageInterface;
      public getBlockGanInfo(index: number): BlockGanInfoInterface;
      public getBlockGanInfoCount(): number;
      public getBuildingNormalInfo(): BuildingNormalInfoInterface;
      public getBuildingSegInfo(): BuildingSegInfoInterface;
      public getCarSegConfig(): CarSegConfigInterface;
      public getCarSegInfo(index: number): CarSegInfoInterface;
      public getCarSegInfoCount(): number;
      public getCarSeriesCount(): number;
      public getCarSeriesInfo(index: number): CarSeriesInfoInterface;
      public getCatFace(index: number): CatFaceInterface;
      public getCatFaceCount(): number;
      public getChromaKeyingInfo(): ChromaKeyingInfoInterface;
      public getClothClassInfo(index: number): ClothClassInfoInterface;
      public getClothClassInfoCount(): number;
      public getClothesSegInfo(): ClothesSegInfoInterface;
      public getColorMappingInfo(): ColorMappingInfoInterface;
      public getCompleteFaceVerifyCount(): number;
      public getCompleteFaceVerifyInfo(index: number): FaceVerifyInfoInterface;
      public getContentRecommendInfo(index: number): ContentRecommendInfoInterface;
      public getContentRecommendInfoCount(): number;
      public getDeepInpaintInfo(): DeepInpaintInfoInterface;
      public getDepthEstimationInfo(graphName: string, nodeName: string, outputIndex: number): DepthEstimationInfoInterface;
      public getDynGestInfo(index: number): DynGestInfoInterface;
      public getEarSegInfo(index: number): EarSegInfoInterface;
      public getEarSegInfoCount(): number;
      public getEnigmaInfo(index: number): EnigmaInfoInterface;
      public getEnigmaInfoCount(): number;
      public getEnigmaInfoFactor(): number;
      public getFaceAttributeCount(): number;
      public getFaceAttributeInfo(index: number): FaceAttributeInterface;
      public getFaceBaseInfo(index: number): Face106Interface;
      public getFaceBeautifyCount(): number;
      public getFaceBeautifyInfo(index: number): FaceBeautifyInfoInterface;
      public getFaceClustingInfo(): FaceClustingInfoInterface;
      public getFaceCount(): number;
      public getFaceExtraInfo(index: number): FaceExtraInterface;
      public getFaceFaceMask(index: number): FaceFaceMaskInterface;
      public getFaceFittingCount(): number;
      public getFaceFittingCount1256(): number;
      public getFaceGanInfo(index: number): FaceGanInfoInterface;
      public getFaceGanInfoCount(): number;
      public getFaceLightInfo(index: number): FaceLightInfoInterface;
      public getFaceLightInfoCount(): number;
      public getFaceMaskInfo(index: number): FaceMaskInfoInterface;
      public getFaceMaskInfoCount(): number;
      public getFaceMeshConfig(): FaceMeshConfigInterface;
      public getFaceMeshConfig1256(): FaceMeshConfigInterface;
      public getFaceMeshInfo(index: number): FaceMeshInfoInterface;
      public getFaceMeshInfo1256(index: number): FaceMeshInfoInterface;
      public getFaceMouthMask(index: number): FaceMouthMaskInterface;
      public getFaceNewLandmarkInfo(index: number): FaceNewLandmarkInfoInterface;
      public getFaceNewLandmarkInfoCount(): number;
      public getFaceOcclusion(index: number): FaceOcclusionInterface;
      public getFacePartBeautyInfo(index: number): FacePartBeautyInfoInterface;
      public getFacePartBeautyInfoConfig(): FacePartBeautyConfigInterface;
      public getFacePartBeautyInfoCount(): number;
      public getFacePetInfo(index: number): FacePetInfoInterface;
      public getFacePetInfoCount(): number;
      public getFaceReenactInfo(index: number): FaceReenactInfoInterface;
      public getFaceReenactInfoCount(): number;
      public getFaceSmoothCPUInfo(): FaceSmoothCPUInfoInterface;
      public getFaceTeethMask(index: number): FaceTeethMaskInterface;
      public getFaceVRInfo(index: number): FaceVRInfoInterface;
      public getFaceVerifyCount(): number;
      public getFaceVerifyInfo(index: number): FaceVerifyInfoInterface;
      public getFemaleGanInfo(): FemaleGanInfoInterface;
      public getFindContourCount(): number;
      public getFindContourInfo(index: number): FindContourInfoInterface;
      public getFoodComicsInfo(): FoodComicsInfoInterface;
      public getFootCount(): number;
      public getFootInfo(index: number): FootInfoInterface;
      public getFootMaskInfo(): FootMaskInfoInterface;
      public getForeheadSegInfo(index: number): ForeheadSegInfoInterface;
      public getForeheadSegInfoCount(): number;
      public getFreidInfo(index: number): FreidInfoInterface;
      public getFreidInfoCount(): number;
      public getGazeEstimationCount(): number;
      public getGazeEstimationInfo(index: number): GazeEstimationInfoInterface;
      public getGenderGanInfo(arg0: number, arg1: string): MegaClassicGanInfoInterface;
      public getGroundSegInfo(): GroundSegResultInterface;
      public getHAvatarInfo(index: number): HAvatarInfoInterface;
      public getHAvatarInfoCount(): number;
      public getHairFlowInfo(): HairFlowInfoInterface;
      public getHairGerInfo(index: number): HairGerInfoInterface;
      public getHairGerInfoCount(): number;
      public getHairInfo(): HairResultInterface;
      public getHandCount(): number;
      public getHandInfo(index: number): HandInfoInterface;
      public getHandMaskInfo(): HandMaskInfoInterface;
      public getHandObjectSegInfo(): HandObjectSegInfoInterface;
      public getHandTVCount(): number;
      public getHandTVInfo(index: number): HandTVInfoInterface;
      public getHdrNetInfo(): HdrNetInfoInterface;
      public getHeadFittingInfo(index: number): HeadFittingInfoInterface;
      public getHeadFittingInfoCount(): number;
      public getHeadSegInfo(index: number): HeadSegInfoInterface;
      public getHeadSegInfoCount(): number;
      public getHumanParsingInfo(): HumanParsingInfoInterface;
      public getIDreamInfo(index: number): IDreamInfoInterface;
      public getIndoorSegInfo(): IndoorSegInfoInterface;
      public getInteractiveMattingInfo(): InteractiveMattingInfoInterface;
      public getJointInfo(): JointInfoInterface;
      public getJointV2Info(): JointV2InfoInterface;
      public getKiraInfo(): KiraResultInterface;
      public getLaughGanInfo(index: number): MegaClassicGanInfoInterface;
      public getLaughGanInfoCount(): number;
      public getLensGeneralInfo(graphName: string, nodeName: string, index: number): BachMapInterface;
      public getLicensePlateInfo(index: number): LicensePlateInfoInterface;
      public getLicensePlateInfoCount(): number;
      public getMangaInfo(index: number): MangaInfoInterface;
      public getMangaInfoCount(): number;
      public getMug(index: number): MugResultInterface;
      public getMugCount(): number;
      public getNHClassificationInfo(graphName: string, nodeName: string, index: number): NHClassificationInfoInterface;
      public getNHClassificationInfoCount(graphName: string, nodeName: string): number;
      public getNHImageInfo(graphName: string, nodeName: string, index: number): NHImageInfoInterface;
      public getNHImageInfoCount(graphName: string, nodeName: string): number;
      public getNHImageTfmCount(graphName: string, nodeName: string): number;
      public getNHImageTfmInfo(graphName: string, nodeName: string, index: number): NHImageTransformInterface;
      public getNHImageWithTfmCount(graphName: string, nodeName: string): number;
      public getNHImageWithTfmInfo(graphName: string, nodeName: string, index: number): NHImageWithTfmInterface;
      public getNHInputTensorCount(graphName: string, nodeName: string): number;
      public getNHInputTensorInfo(graphName: string, nodeName: string, index: number): NHTensorInfoInterface;
      public getNHMulImageInfo(graphName: string, nodeName: string, index: number): NHMulImageInfoInterface;
      public getNHMulImageInfoCount(graphName: string, nodeName: string): number;
      public getNHOutputTensorCount(graphName: string, nodeName: string): number;
      public getNHOutputTensorInfo(graphName: string, nodeName: string, index: number): NHTensorInfoInterface;
      public getNailInfo(): NailInfoInterface;
      public getNailKeyPointInfo(index: number): NailKeyPointInfoInterface;
      public getNailKeyPointInfoCount(): number;
      public getNaviAvatarDriveInfo(): NaviAvatarDriveInfoInterface;
      public getObjectDetectInfo(index: number): ObjectDetectInfoInterface;
      public getObjectDetectInfoCount(): number;
      public getObjectDetectType(): ObjectType;
      public getObjectDetection2Info(index: number): ObjectDetection2InfoInterface;
      public getObjectDetection2InfoCount(): number;
      public getObjectTrackAccuracy(): number;
      public getObjectTrackInfo(index: number): ObjectTrackInfoInterface;
      public getObjectTrackInfoCount(): number;
      public getObjectTrackObjectId(): number;
      public getObjectTrackProjection(): Matrix4x4f;
      public getObjectTrackStatus(): number;
      public getObjectTrackTransform(): Matrix4x4f;
      public getOilPaintInfo(): OilPaintInfoInterface;
      public getOldGanInfo(index: number): MegaClassicGanInfoInterface;
      public getOldGanInfoCount(): number;
      public getOutputTexture(graphName: string, nodeName: string, index: number, outputIndex: number): BachTextureInterface;
      public getPetMattingInfo(): PetMattingInfoInterface;
      public getPictureArInfo(): PictureArInfoInterface;
      public getRelationRecogInfo(index: number): RelationRecogInfoInterface;
      public getRelationRecogInfoCount(): number;
      public getRgbd2MeshInfo(): Rgbd2MeshInfoInterface;
      public getSaliencySegResult(): SaliencySegInfoInterface;
      public getSceneLightInfo(): SceneLightInfoInterface;
      public getSceneNormalInfo(): SceneNormalInfoInterface;
      public getSceneRecogInfo(index: number): SceneRecogInfoInterface;
      public getSceneRecogInfoChoose(): number;
      public getSceneRecogInfoCount(): number;
      public getScriptInfo(graphName: string, nodeName: string): ScriptInfoInterface;
      public getSkeletonCount(): number;
      public getSkeletonInfo(index: number): SkeletonInfoInterface;
      public getSkeletonIsExecuted(): boolean;
      public getSkeletonPose3DInfo(index: number): SkeletonPose3DInfoInterface;
      public getSkeletonPose3DInfoCount(): number;
      public getSkinSegInfo(): SkinSegInfoInterface;
      public getSkinUnifiedCount(): number;
      public getSkinUnifiedInfo(index: number): SkinUnifiedInfoInterface;
      public getSkyInfo(): SkyResultInterface;
      public getSlamCircle(): SlamCircleInterface;
      public getSlamInfo(): SlamResultInterface;
      public getSlamInfoByName(nodeName: string): SlamResultInterface;
      public getSlamVideoInfo(): SlamVideoResultInterface;
      public getSwapLiveInfo(index: number): SwapLiveInfoInterface;
      public getSwapperMeBaseInfo(): SwapperMeBaseInfoInterface;
      public getSwapperMeFaceInfo(index: number): SwapperMeFaceInfoInterface;
      public getTeethCount(): number;
      public getTeethInfo(index: number): TeethInfoInterface;
      public getTrackingArInfo(): TrackingArInfoInterface;
      public getUpperbody3DInfo(index: number): Upperbody3DInfoInterface;
      public getUpperbody3DInfoCount(): number;
      public getVideoMattingInfo(): MattingResultInterface;
      public getVideoSRInfoCount(graphName: string, nodeName: string): number;
      public getVideoSRTexture(graphName: string, nodeName: string, index: number): VideoSRTextureInterface;
      public getWatchTryonCount(): number;
      public getWatchTryonInfo(index: number): WatchTryonInfoInterface;
      public isObjectTrackMirrored(): boolean;
    }
    enum AEPersonKeyPointType {
      kLeftAnkle = 13,
      kLeftEar = 17,
      kLeftElbow = 6,
      kLeftEye = 15,
      kLeftHand = 19,
      kLeftHip = 11,
      kLeftKnee = 12,
      kLeftShoulder = 5,
      kLeftWrist = 7,
      kNeck = 1,
      kNose = 0,
      kRightAnkle = 10,
      kRightEar = 16,
      kRightElbow = 3,
      kRightEye = 14,
      kRightHand = 18,
      kRightHip = 8,
      kRightKnee = 9,
      kRightShoulder = 2,
      kRightWrist = 4,
    }
    namespace AEPersonKeyPointType {
      let RTTI: RTTIDescriptor;
    }
    class ARScanInfoInterface {
      constructor();
      public scannable_name: string;
      public status: number;
      public target_area: FloatVector;
    }
    class ActionDetectInfoInterface {
      constructor();
      public ID: number;
      public index: number;
      public sequenceResult: number;
      public staticResult: number;
    }
    class ActionRecognitionInfoInterface {
      constructor();
      public actionLabel: number;
      public actionScore: number;
      public isValid: boolean;
    }
    class AfterEffectInfoInterface {
      constructor();
      public face_score: number;
      public meaningless_score: number;
      public portrait_score: number;
      public quality_score: number;
      public score: number;
      public sharepness_score: number;
      public time: number;
    }
    class ApolloFace3DInfoClassInterface {
      constructor();
      public ID: number;
      public landmarks3d: Vec3Vector;
      public mvp: FloatVector;
      public normals: Vec3Vector;
      public params: FloatVector;
      public tangents: Vec4Vector;
      public triangles: UInt16Vector;
      public uvs: Vec2Vector;
      public vertexes: Vec3Vector;
    }
    class AudioAvatarInfoInterface {
      constructor();
      public blendShape: FloatVector;
      public rotation: Vector3f;
      public translation: Vector3f;
    }
    class AvacapInfoInterface {
      constructor();
      public alpha: FloatVector;
      public beta: FloatVector;
      public expLen: number;
      public faceCount: number;
      public faceID: number;
      public faceLen: number;
      public idLen: number;
      public meshTriFace: Vector3f;
      public meshv: Vec3Vector;
      public mv: Matrix4x4f;
      public mvp: Matrix4x4f;
      public proj: Matrix4x4f;
      public rot: Matrix3x3f;
      public trans: Vector3f;
      public vertexLen: number;
    }
    class Avatar3DFusionInfoInterface {
      constructor();
      public detected: boolean;
      public focal_length: number;
      public imageHeight: number;
      public imageWidth: number;
      public joints: Vec3Vector;
      public left_hand_prob: number;
      public quaternion: QuatVector;
      public right_hand_prob: number;
      public root: Vector3f;
      public tracking_id: number;
      public valid: Int8Vector;
    }
    class Avatar3DInfoInterface {
      constructor();
      public detected: boolean;
      public focal_length: number;
      public imageHeight: number;
      public imageWidth: number;
      public joints: Vec3Vector;
      public quaternion: QuatVector;
      public root: Vector3f;
      public tracking_id: number;
      public valid: Int8Vector;
    }
    class AvatarDriveInfoInterface {
      constructor();
      public ID: number;
      public action: number;
      public affine_mat: Matrix3x3f;
      public alpha: FloatVector;
      public beta: FloatVector;
      public height: number;
      public landmarks: Vec2Vector;
      public mv: Matrix4x4f;
      public mvp: Matrix4x4f;
      public rot: Vector3f;
      public succ: number;
      public width: number;
    }
    class BachImageInterface {
      constructor();
      public height: number;
      public image: Image;
      public width: number;
    }
    class BachMapInterface {
      constructor();
      public data: Map;
      public get(key: string): Variant;
    }
    class BachTextureInterface {
      constructor();
      public affine: Matrix3x3f;
      public height: number;
      public texId: number;
      public texture: Texture2D;
      public width: number;
    }
    class BachVectorInterface {
      constructor();
      public get(index: number): Variant;
      public size(): number;
    }
    enum BehaviorWhenTrackerDisappear {
      ALIGN_VISIBILITY_WITH_TRACKER = 0,
      RESET_TO_ORIGIN = 2,
      STAY_PREVIOUS_FRAME = 1,
    }
    namespace BehaviorWhenTrackerDisappear {
      let RTTI: RTTIDescriptor;
    }
    class BlingResultInterface {
      constructor();
      public points: Vec3Vector;
    }
    class BlockGanInfoInterface {
      constructor();
      public channel: number;
      public count: number;
      public faceCount: number;
      public height: number;
      public mask: UInt8Vector;
      public mask_image: Image;
      public matrix: FloatVector;
      public type: number;
      public uid: number;
      public width: number;
    }
    class BuildingNormalInfoInterface {
      constructor();
      public hangBoxesAngle: number;
      public hangBoxesCenterX: number;
      public hangBoxesCenterY: number;
      public hangBoxesNormal: FloatVector;
      public hangBoxesSizeHeight: number;
      public hangBoxesSizeWidth: number;
      public numBoxes: number;
      public objectCls: number;
      public polygon: Vec2Vector;
      public polygonCenterX: number;
      public polygonCenterY: number;
    }
    class BuildingSegInfoInterface {
      constructor();
      public height: number;
      public mask: Image;
      public mask_data: UInt8Vector;
      public shiftX: number;
      public shiftY: number;
      public width: number;
    }
    enum CalibrationType {
      UNKNOW = 0xff,
      V1 = 0,
      V2 = 1,
      V3 = 2,
      V4 = 3,
      V5 = 4,
      V6 = 5,
    }
    namespace CalibrationType {
      let RTTI: RTTIDescriptor;
    }
    enum CaptureType {
      CAT = 2,
      DOG = 3,
      FACE_PLACEHOLDER = 4,
      HUMAN = 0,
      HUMAN_EXT = 1,
      UNKNOW = 0xff,
    }
    namespace CaptureType {
      let RTTI: RTTIDescriptor;
    }
    enum CaptureVersion {
      CVPOINTS = 1,
      SOLVEPNP = 0,
    }
    namespace CaptureVersion {
      let RTTI: RTTIDescriptor;
    }
    class CarSegConfigInterface {
      constructor();
      public alphaTextureId: number;
      public realH: number;
      public realW: number;
      public rotateType: number;
    }
    class CarSegInfoInterface {
      constructor();
      public bounding_box: FloatVector;
      public brand_bounding_box: FloatVector;
      public car_Id: number;
      public car_prob: number;
      public color: number;
      public direction: number;
      public is_new: boolean;
      public landmarks: Vec2Vector;
      public left_seg_border: number;
      public seg_data: UInt8Vector;
      public seg_height: number;
      public seg_width: number;
      public segmented_car: Image;
      public up_seg_border: number;
      public valid_landmarks: boolean;
      public valid_segmentation: boolean;
    }
    class CarSeriesInfoInterface {
      constructor();
      public box: FloatVector;
      public car_id: number;
      public car_series_prob: number;
      public is_new: boolean;
      public series_id: number;
      public series_name: string;
    }
    class CatFaceInterface {
      constructor();
      public ID: number;
      public action: number;
      public pitch: number;
      public points_array: Vec2Vector;
      public rect: Rect;
      public roll: number;
      public score: number;
      public yaw: number;
    }
    class ChromaKeyingInfoInterface {
      constructor();
      public color_b: number;
      public color_g: number;
      public color_h: number;
      public color_r: number;
      public height: number;
      public keying_similar: number;
      public mask: UInt8Vector;
      public maskImage: Image;
      public width: number;
    }
    class ClothClassInfoInterface {
      constructor();
      public probs: FloatVector;
      public score: number;
      public trackID: number;
      public type: number;
      public vertices: Vec2Vector;
      public x0: number;
      public x1: number;
      public y0: number;
      public y1: number;
    }
    class ClothGanInfoInterface {
      constructor();
      public affineMatrix: Matrix4x4f;
      public height: number;
      public image: Image;
      public image_height: number;
      public image_width: number;
      public width: number;
    }
    class ClothesSegInfoInterface {
      constructor();
      public alphaMask: Image;
      public bottom: number;
      public height: number;
      public left: number;
      public mask_data: UInt8Vector;
      public right: number;
      public shiftX: number;
      public shiftY: number;
      public top: number;
      public width: number;
    }
    class ColorMappingInfoInterface {
      constructor();
      public height: number;
      public lutImage: Image;
      public width: number;
    }
    class ContentRecommendInfoInterface {
      constructor();
    }
    class DeepInpaintInfoInterface {
      constructor();
      public height: number;
      public image_height: number;
      public image_width: number;
      public mask_image: Image;
      public width: number;
    }
    class DepthEstimationInfoInterface {
      constructor();
      public depthMask: UInt8Vector;
      public height: number;
      public image: Image;
      public width: number;
    }
    class DynGestInfoInterface {
      constructor();
      public action: number;
      public action_score: number;
    }
    class EarSegInfoInterface {
      constructor();
      public alpha0: UInt8Vector;
      public alpha1: UInt8Vector;
      public centerX: FloatVector;
      public centerY: FloatVector;
      public cls: Int32Vector;
      public earHeight: Int8Vector;
      public earWidth: Int8Vector;
      public faceID: number;
      public mask0: Image;
      public mask1: Image;
      public maskChannel: number;
      public maskHeight: number;
      public maskWidth: number;
      public matrix0: DoubleVector;
      public matrix1: DoubleVector;
      public yaw: number;
    }
    class EnigmaInfoInterface {
      constructor();
      public points: Vec2Vector;
      public text: string;
      public type: number;
    }
    enum EntityRotateType {
      ROTATE_AROUND_XYZ_AXIS = 2,
      ROTATE_AROUND_Z_AXIS = 1,
      ROTATE_DISABLE = 0,
    }
    namespace EntityRotateType {
      let RTTI: RTTIDescriptor;
    }
    class EyeFittingInfoInterface {
      constructor();
      public cameraParam: FloatVector;
      public faceId: number;
      public fovy: number;
      public leftLandmarks: Vec3Vector;
      public leftMVP: Matrix4x4f;
      public leftModel: Matrix4x4f;
      public leftNormals: Vec3Vector;
      public leftRvec: Vector3f;
      public leftTangents: Vec3Vector;
      public leftTvec: Vector3f;
      public leftVertexes: Vec3Vector;
      public rightLandmarks: Vec3Vector;
      public rightMVP: Matrix4x4f;
      public rightModel: Matrix4x4f;
      public rightNormals: Vec3Vector;
      public rightRvec: Vector3f;
      public rightTangents: Vec3Vector;
      public rightTvec: Vector3f;
      public rightVertexes: Vec3Vector;
      public triangles: UInt16Vector;
      public uvs: Vec2Vector;
    }
    class Face106Interface {
      constructor();
      public ID: number;
      public eye_dist: number;
      public pitch: number;
      public points_array: Vec2Vector;
      public rect: Rect;
      public roll: number;
      public score: number;
      public tracking_cnt: number;
      public visibility_array: FloatVector;
      public yaw: number;
      public hasAction(action: number): boolean;
    }
    enum FaceAction {
      BROW_JUMP = 0x00000020,
      EYE_BLINK = 0x00000002,
      EYE_BLINK_LEFT = 0x00000080,
      EYE_BLINK_RIGHT = 0x00000100,
      HEAD_PITCH = 0x00000010,
      HEAD_YAW = 0x00000008,
      MOUTH_AH = 0x00000004,
      MOUTH_POUT = 0x00000040,
      SIDE_NOD = 0x00000200,
    }
    namespace FaceAction {
      let RTTI: RTTIDescriptor;
    }
    enum FaceAttrExpression {
      ANGRY = 0,
      DISGUST = 1,
      FEAR = 2,
      HAPPY = 3,
      NEUTRAL = 6,
      NUM_EXPRESSION = 7,
      SAD = 4,
      SURPRISE = 5,
      UNKNOWN = -1,
    }
    namespace FaceAttrExpression {
      let RTTI: RTTIDescriptor;
    }
    enum FaceAttrGender {
      FEMALE = 0x00000002,
      MALE = 0x00000001,
      UNKNOWN = -1,
    }
    namespace FaceAttrGender {
      let RTTI: RTTIDescriptor;
    }
    class FaceAttributeInterface {
      constructor();
      public age: number;
      public attractive: number;
      public boyProb: number;
      public exp_probs: FloatVector;
      public exp_type: FaceAttrExpression;
      public gender: FaceAttrGender;
      public happyScore: number;
      public quality: number;
    }
    class FaceBeautifyInfoInterface {
      constructor();
      public height: number;
      public image: Image;
      public region: Rect;
      public width: number;
    }
    class FaceClustingInfoInterface {
      constructor();
      public is_valid: boolean;
    }
    class FaceExtraInterface {
      constructor();
      public eye_count: number;
      public eye_left: Vec2Vector;
      public eye_right: Vec2Vector;
      public eyebrow_count: number;
      public eyebrow_left: Vec2Vector;
      public eyebrow_right: Vec2Vector;
      public iris_count: number;
      public left_iris: Vec2Vector;
      public lips: Vec2Vector;
      public lips_count: number;
      public right_iris: Vec2Vector;
    }
    class FaceFaceMaskInterface {
      constructor();
      public ID: number;
      public face_mask: UInt8Vector;
      public face_mask_size: number;
      public image: Image;
      public warp_mat: FloatVector;
    }
    class FaceFittingInfoInterface {
      constructor();
      public getFaceFittingCount(): number;
      public getFaceFittingCount1256(): number;
      public getFaceMeshConfig(): FaceMeshConfigInterface;
      public getFaceMeshConfig1256(): FaceMeshConfigInterface;
      public getFaceMeshInfo(index: number): FaceMeshInfoInterface;
      public getFaceMeshInfo1256(index: number): FaceMeshInfoInterface;
    }
    class FaceGanInfoInterface {
      constructor();
      public affine: Matrix4x4f;
      public data: Image;
      public doubleRate: number;
      public faceID: number;
      public image_height: number;
      public image_width: number;
      public objectType: FaceGanObjectType;
      public outChannel: number;
      public outHeight: number;
      public outWidth: number;
      public plumpRate: number;
      public rect: Rect;
    }
    enum FaceGanObjectType {
      LEFT_CLASS_ONLY = 7,
      LEFT_DOUBLE = 1,
      LEFT_DOUBLE_PLUMP = 3,
      LEFT_PLUMP = 2,
      RIGHT_CLASS_ONLY = 8,
      RIGHT_DOUBLE = 4,
      RIGHT_DOUBLE_PLUMP = 6,
      RIGHT_PLUMP = 5,
      UNDEFINED = 0,
    }
    namespace FaceGanObjectType {
      let RTTI: RTTIDescriptor;
    }
    class FaceInfoInterface {
      constructor();
      public getBinocularFaceCount(): number;
      public getFaceBaseInfo(index: number): Face106Interface;
      public getFaceCount(): number;
      public getFaceExtraInfo(index: number): FaceExtraInterface;
      public getFaceFaceMask(index: number): FaceFaceMaskInterface;
      public getFaceMouthMask(index: number): FaceMouthMaskInterface;
      public getFaceOcclusion(index: number): FaceOcclusionInterface;
      public getFaceTeethMask(index: number): FaceTeethMaskInterface;
      public getFaceVRInfo(index: number): FaceVRInfoInterface;
    }
    class FaceLightInfoInterface {
      constructor();
      public SH_Light_RGB: FloatVector;
      public face_id: number;
      public has_lighting: boolean;
    }
    class FaceMaskInfoInterface {
      constructor();
      public alpha: UInt8Vector;
      public bboxes: Rect;
      public height: number;
      public image: Image;
      public kpts: Vec2Vector;
      public kpts3D: Vec3Vector;
      public mask_count: number;
      public rotation: Vec3Vector;
      public rotationStatus: number;
      public translate: Vec3Vector;
      public width: number;
    }
    class FaceMeshConfigInterface {
      constructor();
      public flist: UInt16Vector;
      public uvs: Vec2Vector;
    }
    class FaceMeshInfoInterface {
      constructor();
      public ID: number;
      public bitangents: Vec3Vector;
      public landmarks: Vec3Vector;
      public modelMatrix: Matrix4x4f;
      public mvp: Matrix4x4f;
      public normals: Vec3Vector;
      public param: FloatVector;
      public rvec: Vector3f;
      public scale: number;
      public tangents: Vec3Vector;
      public tvec: Vector3f;
      public vertexes: Vec3Vector;
    }
    class FaceMouthMaskInterface {
      constructor();
      public ID: number;
      public face_mask: UInt8Vector;
      public face_mask_size: number;
      public image: Image;
      public warp_mat: FloatVector;
    }
    class FaceNewLandmarkInfoInterface {
      constructor();
      public faceID: number;
      public points: Vec2Vector;
    }
    class FaceOcclusionInterface {
      constructor();
      public id: number;
      public prob: number;
    }
    class FacePartBeautyConfigInterface {
      constructor();
      public distance: number;
      public faceChange: number;
      public faceNum: number;
      public faceNum0: number;
      public faceNum1: number;
      public together: number;
    }
    class FacePartBeautyInfoInterface {
      constructor();
      public beauty_id: number;
      public beauty_score: Int32Vector;
      public features: FloatVector;
    }
    class FacePetInfoInterface {
      constructor();
      public Id: number;
      public action: number;
      public ear_type: number;
      public face_pet_type: FacePetType;
      public pitch: number;
      public points_array: Vec2Vector;
      public rect: Rect;
      public roll: number;
      public score: number;
      public yaw: number;
    }
    enum FacePetType {
      CAT = 1,
      DOG = 2,
      HUMAN = 3,
      OTHERS = 99,
    }
    namespace FacePetType {
      let RTTI: RTTIDescriptor;
    }
    class FaceReenactInfoInterface {
      constructor();
      public dataType: number;
      public image: Image;
      public imageChannel: number;
      public imageHeight: number;
      public imageWidth: number;
      public mvp: Matrix4x4f;
      public rawData: UInt8Vector;
    }
    class FaceSmoothCPUInfoInterface {
      constructor();
      public height: number;
      public texture: Image;
      public width: number;
    }
    class FaceTeethMaskInterface {
      constructor();
      public ID: number;
      public face_mask: UInt8Vector;
      public face_mask_size: number;
      public image: Image;
      public warp_mat: FloatVector;
    }
    class FaceVRInfoInterface {
      constructor();
      public corrspond_id: number;
      public left_id: number;
      public right_id: number;
    }
    class FaceVerifyInfoInterface {
      constructor();
      public ID: number;
      public features: FloatVector;
      public rect: Rect;
    }
    class FemaleGanInfoInterface {
      constructor();
      public affine: Matrix4x4f;
      public cropImage: Image;
      public cropImgAlignment: number;
      public cropImgChannels: number;
      public cropImgData: UInt8Vector;
      public cropImgHeight: number;
      public cropImgStride: number;
      public cropImgWidth: number;
      public faceId: number;
      public height: number;
      public outputImage: Image;
      public outputImgAlignment: number;
      public outputImgChannels: number;
      public outputImgData: UInt8Vector;
      public outputImgHeight: number;
      public outputImgStride: number;
      public outputImgWidth: number;
      public shouldDraw: boolean;
      public width: number;
    }
    class FindContourInfoInterface {
      constructor();
      public contours: Vec2Vector;
      public height: number;
      public hierarchy: Int32Vector;
      public width: number;
    }
    class FoodComicsInfoInterface {
      constructor();
      public faceCount: number;
      public height: number;
      public mask: UInt8Vector;
      public mask_image: Image;
      public matrix: FloatVector;
      public width: number;
    }
    class FootInfoInterface {
      constructor();
      public box: Rect;
      public footId: number;
      public foot_prob: number;
      public is_left: boolean;
      public key_points_is_detect: UInt8Vector;
      public key_points_xy: Vec2Vector;
      public left_prob: number;
      public segment: UInt8Vector;
      public segment_box: Rect;
      public transMat: Matrix4x4f;
      public u_model: Matrix4x4f;
    }
    class FootMaskInfoInterface {
      constructor();
      public foot_image: Image;
      public foot_mask: UInt8Vector;
      public leg_image: Image;
      public leg_mask: UInt8Vector;
      public mask: UInt8Vector;
      public mask2: UInt8Vector;
      public mask_height: number;
      public mask_image: Image;
      public mask_image2: Image;
      public mask_width: number;
      public trousers_image: Image;
      public trousers_mask: UInt8Vector;
    }
    class ForeheadSegInfoInterface {
      constructor();
      public face_id: number;
      public image: Image;
      public image_height: number;
      public image_width: number;
      public mask_height: number;
      public mask_width: number;
      public mvp_matrix: Matrix4x4f;
    }
    class FreidInfoInterface {
      constructor();
      public faceid: number;
      public trackid: number;
    }
    class GazeEstimationInfoInterface {
      constructor();
      public face_id: number;
      public head_r: FloatVector;
      public head_t: FloatVector;
      public leye_gaze: FloatVector;
      public leye_gaze2d: FloatVector;
      public leye_pos: FloatVector;
      public leye_pos2d: FloatVector;
      public mid_gaze: FloatVector;
      public reye_gaze: FloatVector;
      public reye_gaze2d: FloatVector;
      public reye_pos: FloatVector;
      public reye_pos2d: FloatVector;
      public valid: boolean;
    }
    class GraphicsInfoInterface {
      constructor();
      public data: UInt8Vector;
      public height: number;
      public id: number;
      public image: Image;
      public matrix: Matrix4x4f;
      public width: number;
    }
    class GroundSegResultInterface {
      constructor();
      public groundMask: Image;
      public height: number;
      public mask_data: UInt8Vector;
      public srcImageHeight: number;
      public srcImageWidth: number;
      public width: number;
    }
    class HAvatarInfoInterface {
      constructor();
      public ID: number;
      public action: HandAction;
      public handProb: number;
      public kpt2d: Vec2Vector;
      public kpt3d: Vec3Vector;
      public leftProb: number;
      public quaternion: QuatVector;
      public rect: Rect;
      public root: Vector3f;
    }
    class HairFlowInfoInterface {
      constructor();
      public do_inpaint: boolean;
      public height: number;
      public mask: UInt8Vector;
      public maskImage: Image;
      public maxX: number;
      public maxY: number;
      public minX: number;
      public minY: number;
      public motion: UInt8Vector;
      public motionImage: Image;
      public width: number;
    }
    class HairGerInfoInterface {
      constructor();
      public channelId: number;
      public height: number;
      public image: Image;
      public reflector: number;
      public width: number;
    }
    class HairResultInterface {
      constructor();
      public height: number;
      public mAlphac: number;
      public mAlphal: number;
      public mAlphas: number;
      public mask: Image;
      public mask_data: UInt8Vector;
      public new_rect: Rect;
      public rect: Rect;
      public reflection: number;
      public rotateType: number;
      public width: number;
    }
    enum HandAction {
      AVENGERS = 46,
      BEG = 17,
      BIG_V = 15,
      CABBAGE = 20,
      DOUBLE_FINGER_UP = 13,
      FIST = 11,
      FOUR = 22,
      HAND_OPEN = 5,
      HEART_A = 0,
      HEART_B = 1,
      HEART_C = 2,
      HEART_D = 3,
      HOLDFACE = 26,
      INDEX_FINGER_UP = 12,
      MAX_COUNT = 47,
      NAMASTE = 9,
      NARUTO1 = 34,
      NARUTO10 = 42,
      NARUTO11 = 43,
      NARUTO12 = 44,
      NARUTO2 = 35,
      NARUTO3 = 36,
      NARUTO4 = 37,
      NARUTO5 = 38,
      NARUTO7 = 39,
      NARUTO8 = 40,
      NARUTO9 = 41,
      OK = 4,
      PALM_DOWN = 32,
      PHONECALL = 16,
      PISTOL = 23,
      PISTOL2 = 33,
      PLAM_UP = 10,
      PRAY = 29,
      QIGONG = 30,
      ROCK = 8,
      ROCK2 = 24,
      SALUTE = 27,
      SLIDE = 31,
      SPIDERMAN = 45,
      SPREAD = 28,
      SWEAR = 25,
      THANKS = 18,
      THREE = 21,
      THUMB_DOWN = 7,
      THUMB_UP = 6,
      UNDETECT = 99,
      UNKNOWN = 19,
      VICTORY = 14,
    }
    namespace HandAction {
      let RTTI: RTTIDescriptor;
    }
    class HandInfoInterface {
      constructor();
      public ID: number;
      public action: HandAction;
      public forefinger_r_trans: Matrix4x4f;
      public hand_count_for_ring: number;
      public image: Image;
      public key_points_3d: Vec3Vector;
      public key_points_3d_is_detect: UInt8Vector;
      public key_points_extension_is_detect: UInt8Vector;
      public key_points_extension_xy: Vec2Vector;
      public key_points_is_detect: UInt8Vector;
      public key_points_xy: Vec2Vector;
      public left_prob: number;
      public little_finger_r_trans: Matrix4x4f;
      public mask_height: number;
      public mask_width: number;
      public middle_finger_r_trans: Matrix4x4f;
      public rect: Rect;
      public ring_finger_r_trans: Matrix4x4f;
      public ring_r_trans: Matrix4x4f;
      public ring_render_mode: number;
      public ring_rt_trans: Matrix4x4f;
      public ringv2_occluder_mode: UInt8Vector;
      public ringv2_render_mode: number;
      public rot_angle: number;
      public rot_angle_bothhand: number;
      public scale: number;
      public score: number;
      public segment_data: UInt8Vector;
      public segment_height: number;
      public segment_width: number;
      public seq_action: number;
      public thumb_r_trans: Matrix4x4f;
    }
    class HandMaskInfoInterface {
      constructor();
      public mask: UInt8Vector;
      public mask_height: number;
      public mask_image: Image;
      public mask_width: number;
    }
    class HandObjectSegInfoInterface {
      constructor();
      public height: number;
      public mask_image: Image;
      public width: number;
    }
    class HandTVInfoInterface {
      constructor();
      public ID: number;
      public action: HandTVAction;
      public acton_score: number;
      public key_points_extension_is_detect: UInt8Vector;
      public key_points_extension_xy: Vec2Vector;
      public key_points_is_detect: UInt8Vector;
      public key_points_xy: Vec2Vector;
      public person_id: number;
      public rect: Rect;
      public rot_angle: number;
      public rot_angle_bothhand: number;
      public score: number;
      public segment_data: UInt8Vector;
      public segment_height: number;
      public segment_width: number;
    }
    class HdrNetInfoInterface {
      constructor();
      public ccm: FloatVector;
      public ccm_bias: FloatVector;
      public channel_mix_bias: number;
      public channel_mix_weight: FloatVector;
      public grid: FloatVector;
      public shifts: FloatVector;
      public slopes: FloatVector;
    }
    class HeadFittingInfoInterface {
      constructor();
      public ID: number;
      public bitangents: Vec3Vector;
      public landmarks2D: Vec2Vector;
      public modelMatrix: Matrix4x4f;
      public mvp: Matrix4x4f;
      public normals: Vec3Vector;
      public project2D: Vec2Vector;
      public projectMatrix: Matrix4x4f;
      public pupil_dist: number;
      public tangents: Vec3Vector;
      public triangle: UInt16Vector;
      public uv: Vec2Vector;
      public valid: boolean;
      public vertexes: Vec3Vector;
      public viewMatrix: Matrix4x4f;
    }
    class HeadSegInfoInterface {
      constructor();
      public alpha: Image;
      public cameraMatrix: DoubleVector;
      public channel: number;
      public face_id: number;
      public height: number;
      public matrix: DoubleVector;
      public srcHeight: number;
      public srcWidth: number;
      public width: number;
      public xScale: number;
      public yScale: number;
    }
    class HumanParsingInfoInterface {
      constructor();
      public height: number;
      public image_height: number;
      public image_width: number;
      public width: number;
      public Convert2Images(index: number): Image;
    }
    class IDreamInfoInterface {
      constructor();
      public affine: Matrix4x4f;
      public height: number;
      public image: Image;
      public image_height: number;
      public image_width: number;
      public width: number;
    }
    class IndoorSegInfoInterface {
      constructor();
      public height: number;
      public width: number;
      public getMask(index: number): Image;
    }
    class InteractiveMattingInfoInterface {
      constructor();
      public alphaMask: Image;
      public bottom: number;
      public height: number;
      public left: number;
      public right: number;
      public top: number;
      public width: number;
    }
    class JointInfoInterface {
      constructor();
      public jointNum: number;
      public key_points_r: FloatVector;
      public key_points_type: UInt32Vector;
      public key_points_xy: Vec2Vector;
    }
    class JointV2InfoInterface {
      constructor();
      public key_points_detected: UInt8Vector;
      public key_points_xy: Vec2Vector;
      public number: number;
    }
    class KiraResultInterface {
      constructor();
      public channels: number;
      public height: number;
      public mask: Image;
      public pointNum: number;
      public points: Vec3Vector;
      public width: number;
    }
    class LicensePlateInfoInterface {
      constructor();
      public brand_id: number;
      public points_array: Vec2Vector;
    }
    class MangaInfoInterface {
      constructor();
      public affine: Matrix4x4f;
      public channels: number;
      public data: UInt8Vector;
      public height: number;
      public image: Image;
      public image_height: number;
      public image_width: number;
      public matrix: FloatVector;
      public type: number;
      public width: number;
    }
    class MattingResultInterface {
      constructor();
      public bgMask: Image;
      public height: number;
      public mask_data: UInt8Vector;
      public resultRect: Rect;
      public take_this: SnapShotRet;
      public width: number;
    }
    class MegaClassicGanInfoInterface {
      constructor();
      public affine: Matrix4x4f;
      public affineMatrix: Matrix4x4f;
      public alphaImage: Image;
      public faceCount: number;
      public faceID: number;
      public faceId: number;
      public gpuMatrix: Matrix4x4f;
      public height: number;
      public id: number;
      public image: Image;
      public imageHeight: number;
      public imageWidth: number;
      public image_data: UInt8Vector;
      public image_height: number;
      public image_width: number;
      public invalidDegree: number;
      public valid: number;
      public width: number;
    }
    class MugResultInterface {
      constructor();
      public ID: number;
      public mug_region: Rect;
      public points: Vec2Vector;
      public prob: number;
    }
    class NHClassificationInfoInterface {
      constructor();
      public numClasses: number;
      public exceedThresh(idx: number): number;
      public getConfidence(idx: number): number;
      public getId(idx: number): number;
      public getLabel(id: number): string;
      public getThresh(id: number): number;
    }
    class NHImageInfoInterface {
      constructor();
      public dataType: number;
      public floatData: FloatVector;
      public image: Image;
      public imageChannel: number;
      public imageHeight: number;
      public imageWidth: number;
      public step: number;
    }
    class NHImageTransformInterface {
      constructor();
      public affine: Matrix3x3f;
      public mvp: Matrix4x4f;
    }
    class NHImageWithTfmInterface {
      constructor();
      public image: NHImageInfoInterface;
      public tfm: NHImageTransformInterface;
    }
    class NHMulImageInfoInterface {
      constructor();
      public getImageInfo(index: number): NHImageInfoInterface;
    }
    class NHTensorInfoInterface {
      constructor();
      public batch: number;
      public channel: number;
      public dataFormat: number;
      public dataType: number;
      public fraction: number;
      public height: number;
      public name: string;
      public width: number;
    }
    class NailInfoInterface {
      constructor();
      public alpha_data: UInt8Vector;
      public alpha_image: Image;
      public height: number;
      public rtNum: number;
      public width: number;
    }
    class NailKeyPointInfoInterface {
      constructor();
      public cls: number;
      public kpts: Vec2Vector;
      public nailRect: Rect;
    }
    class NaviAvatarDriveInfoInterface {
      constructor();
      public blendshapeWeights: FloatVector;
      public modelView: Matrix4x4f;
    }
    class ObjectDetectInfoInterface {
      constructor();
      public Id: number;
      public rect: Rect;
      public score: number;
    }
    class ObjectDetection2InfoInterface {
      constructor();
      public IRLabel: number;
      public label: number;
      public objId: number;
      public prob: number;
      public rect: Rect;
    }
    class ObjectTrackInfoInterface {
      constructor();
      public centerX: number;
      public centerY: number;
      public height: number;
      public rotateAngle: number;
      public width: number;
    }
    class ObjectTrackingInfoInterface {
      constructor();
      public centerX: number;
      public centerY: number;
      public height: number;
      public rotateAngle: number;
      public timestamp: number;
      public trackingStatus: number;
      public width: number;
    }
    enum ObjectType {
      DET_DUMPLINGS = 0x00000002,
      DET_FEAST = 0x00000004,
      DET_RED = 0x00000001,
    }
    namespace ObjectType {
      let RTTI: RTTIDescriptor;
    }
    class OilPaintInfoInterface {
      constructor();
      public height: number;
      public mask: UInt8Vector;
      public mask_image: Image;
      public width: number;
    }
    class PetMattingInfoInterface {
      constructor();
      public mask0: Image;
      public mask1: Image;
      public maskCount: number;
      public maskHeight: number;
      public maskWidth: number;
    }
    class PictureArInfoInterface {
      constructor();
      public affineMat: boolean;
      public affineMatIsValid: boolean;
      public anchorMatch: Vec2Vector;
      public anchorMatchIsValid: boolean;
      public frameScore: number;
      public frameScoreIsValid: boolean;
      public isDetcting: boolean;
      public mapMatch: Vec2Vector;
      public mapMatchIsValid: boolean;
      public rotation: number;
      public rotationIsValid: boolean;
      public scale: number;
      public scaleIsValid: boolean;
      public sourcePoints: Vec2Vector;
      public targetPoints: Vec2Vector;
    }
    class RelationRecogInfoInterface {
      constructor();
    }
    class Rgbd2MeshInfoInterface {
      constructor();
      public height: number;
      public i_len: number;
      public indices: UInt16Vector;
      public mask_image: Image;
      public mesh_score: number;
      public texture: UInt8Vector;
      public v_len: number;
      public vertex: FloatVector;
      public width: number;
    }
    class SaliencySegInfoInterface {
      constructor();
      public bboxcenterX: number;
      public bboxcenterY: number;
      public bboxheight: number;
      public bboxrotateAngle: number;
      public bboxwidth: number;
      public input: Image;
      public mask: Image;
      public modelIndex: number;
      public realH: number;
      public realW: number;
    }
    class SceneLightInfoInterface {
      constructor();
      public SH_Light_RGB: FloatVector;
    }
    class SceneNormalInfoInterface {
      constructor();
      public height: number;
      public mask: Image;
      public mask_data: UInt8Vector;
      public width: number;
    }
    class SceneRecogInfoInterface {
      constructor();
      public name: string;
      public prob: number;
      public satisfied: boolean;
    }
    class SceneRecogV3InfoInterface {
      constructor();
      public confidence: number;
      public id: number;
      public name: string;
      public satisfied: boolean;
      public thres: number;
    }
    class ScriptInfoInterface {
      public outputMap: Map;
      public data(): Map;
      public get(key: string): Variant;
    }
    class SkeletonInfoInterface {
      constructor();
      public ID: number;
      public image_orientation: number;
      public key_points_detected: UInt8Vector;
      public key_points_score: FloatVector;
      public key_points_xy: Vec2Vector;
      public orientation: number;
      public rect: Rect;
    }
    class SkeletonPose3DInfoInterface {
      constructor();
      public detected: boolean;
      public fused3d: Vec3Vector;
      public pose3d: Vec3Vector;
      public skeleton2d_detecteds: Int8Vector;
      public skeleton2d_points: Vec2Vector;
    }
    class SkinSegInfoInterface {
      constructor();
      public data: Image;
      public height: number;
      public mask_data: UInt8Vector;
      public reflector: number;
      public width: number;
    }
    class SkinUnifiedInfoInterface {
      constructor();
      public height: number;
      public image: Image;
      public image_height: number;
      public image_width: number;
      public matrix: FloatVector;
      public width: number;
    }
    class SkyResultInterface {
      constructor();
      public channel: number;
      public height: number;
      public mask_data: UInt8Vector;
      public skyMask: Image;
      public width: number;
    }
    class SlamCircleInterface {
      constructor();
      public ID: number;
      public hasEllipse: boolean;
      public normal: Vector3f;
      public position: Vector3f;
      public radius: number;
    }
    class SlamHitResultInterface {
      constructor();
    }
    class SlamResultInterface {
      constructor();
      public colorCorrection: Vector4f;
      public depthImage: Image;
      public depthRangeMax: number;
      public depthRangeMin: number;
      public depths: FloatVector;
      public enable: boolean;
      public featurePoints: FloatVector;
      public fusionState: number;
      public hangboxDepths: Vec3Vector;
      public mapData: string;
      public planeDetected: number;
      public planeTransform: Matrix4x4f;
      public planeUpdate: boolean;
      public planesAnchor: Vector;
      public projection: Matrix4x4f;
      public sizeOfFeaturePoints: number;
      public trackStatus: number;
      public trackingStateReason: number;
      public view: Matrix4x4f;
      public withDepth: boolean;
    }
    class SlamTouchInfoInterface {
      constructor();
      public touchDirty: boolean;
      public touchX: number;
      public touchY: number;
      public worldTransform: Matrix4x4f;
    }
    class SlamTrackableInfoInterface {
      constructor();
      public boundary: Vector3f[];
      public center: Vector3f;
      public normal: Vector3f;
      public offset: number;
      public trackId: string;
    }
    class SlamVideoResultInterface {
      constructor();
      public frameDepths: FloatVector;
      public frameSize: number;
      public frameTrackStatus: Int32Vector;
      public frameValidPointSizes: Int32Vector;
      public frameViews: Matrix4x4f;
      public projection: Matrix4x4f;
    }
    enum SnapShotRet {
      Disable = 0,
      FalseState = 1,
      TrueState = 2,
    }
    namespace SnapShotRet {
      let RTTI: RTTIDescriptor;
    }
    class SwapLiveInfoInterface {
      constructor();
      public affine: Matrix4x4f;
      public height: number;
      public image: Image;
      public image_height: number;
      public image_width: number;
      public valid: number;
      public width: number;
    }
    class SwapperMeBaseInfoInterface {
      constructor();
      public checkMode: boolean;
      public checkResult: Int32Vector;
      public faceCount: number;
      public image: Image;
    }
    class SwapperMeFaceInfoInterface {
      constructor();
      public points_array: Vec2Vector;
    }
    class TeethInfoInterface {
      constructor();
      public face_count: number;
      public face_id: number;
      public image_height: number;
      public image_width: number;
      public teeth_pts: Vec2Vector;
    }
    enum TrackerPhase {
      Added = 0,
      Removed = 2,
      Update = 1,
    }
    namespace TrackerPhase {
      let RTTI: RTTIDescriptor;
    }
    enum TrackerType {
      Face = 2,
      Image = 3,
      Object = 4,
      Plane = 1,
      Point = 5,
      Unkown = 0,
    }
    namespace TrackerType {
      let RTTI: RTTIDescriptor;
    }
    class TrackingArInfoInterface {
      constructor();
      public accuracy: number;
      public isMirrored: boolean;
      public objectId: number;
      public planeImg: Image;
      public planeImgHeight: number;
      public planeImgWidth: number;
      public pose: Matrix4x4f;
      public projection: Matrix4x4f;
      public status: number;
    }
    class Upperbody3DInfoInterface {
      constructor();
      public pose3d: Vec3Vector;
    }
    class VideoSRTextureInterface {
      constructor();
      public height: number;
      public texId: number;
      public texture: Texture2D;
      public width: number;
    }
    class WatchTryonInfoInterface {
      constructor();
      public isLeft: boolean;
      public modelViewMatrix: Matrix4x4f;
      public triangles: UInt16Vector;
      public vertices: Vec3Vector;
    }
    enum HandTVAction {
      HEART_A = 0,
      HEART_B = 1,
      HEART_C = 2,
      HEART_D = 3,
      OK = 4,
      HAND_OPEN = 5,
      THUMB_UP = 6,
      THUMB_DOWN = 7,
      ROCK = 8,
      NAMASTE = 9,
      PLAM_UP = 10,
      FIST = 11,
      INDEX_FINGER_UP = 12,
      DOUBLE_FINGER_UP = 13,
      VICTORY = 14,
      BIG_V = 15,
      PHONECALL = 16,
      BEG = 17,
      THANKS = 18,
      UNKNOWN = 19,
      UNDETECT = 99,
    }
    namespace HandTVAction {
      let RTTI: RTTIDescriptor;
    }
  }
}